#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>

int main( int argc, char ** argv )
{
	fprintf( stdout,
		"#ifndef F_NOTIFY\n"
		"#define F_NOTIFY 0x%x\n"
		"#define DN_ACCESS 0x%x\n"
		"#define DN_MODIFY 0x%x\n"
		"#define DN_CREATE 0x%x\n"
		"#define DN_DELETE 0x%x\n"
		"#define DN_RENAME 0x%x\n"
		"#define DN_ATTRIB 0x%x\n"
		"#define DN_MULTISHOT 0x%x\n"
		"#endif\n",
		F_NOTIFY, DN_ACCESS, DN_MODIFY, DN_CREATE,
		DN_DELETE, DN_RENAME, DN_ATTRIB, DN_MULTISHOT );
	return 0;
}

