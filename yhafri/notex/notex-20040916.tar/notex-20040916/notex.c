#include <signal.h>
#include <unistd.h>
#include <dirent.h>
#include <alloca.h>
#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

#include "fnotify.h"

#define SIGXYZ (SIGRTMIN+23)
#define DN_FLAGS DN_MODIFY|DN_CREATE|DN_DELETE|DN_RENAME|DN_ATTRIB|DN_MULTISHOT

#define cwrite(fd,str) write(fd,str,sizeof str - 1)

int writeDebug = 0, pid;

struct DirList {
	struct DirList * next;
	char * name;
	int fd;
};

struct FileList {
	struct FileList * next;
	struct DirList * dir;
	char * name, * cmd;
	time_t mtime;
};

void swrite( int fd, char * str )
{
	int length;
	if( str && fd >= 0 ) {
		length = strlen( str );
		if( length > 0 )
			write( fd, str , length );
	}
}

void write3( int fd, char * str1, char * str2, char * str3 )
{
	int length;
	char * buf;

	if( !str1 )
		str1 = "";
	if( !str2 )
		str2 = "";
	if( !str3 )
		str3 = "";
	length = strlen( str1 );
	length += strlen( str2 );
	length += strlen( str3 );

	if( length > 0 ) {
		buf = alloca( length + 1 );
		strcpy( buf, str1 );
		strcat( buf, str2 );
		strcat( buf, str3 );
		write( fd, buf, length );
	}
}

int myperror( char * str )
{
	write3( 2, str, "", " returned error\n" );
	return 1;
}

void debug( char * str )
{
	if( writeDebug )
		swrite( 1, str );
}

void debug3( char * str1, char * str2, char * str3 )
{
	if( writeDebug )
		write3( 1, str1, str2, str3 );
}

void set_notification( struct DirList * thisDir )
{
	int result;

	result = fcntl( thisDir -> fd, F_SETOWN, pid );
	if( result == -1 ) {
		debug3( "fcntl(F_SETOWN)", " returned error\n", "" );
		return;
	}
	result = fcntl( thisDir -> fd, F_SETSIG, SIGXYZ );
	if( result == -1 ) {
		debug3( "fcntl(F_SETSIG)", " returned error\n", "" );
		return;
	}
	result = fcntl( thisDir -> fd, F_NOTIFY, DN_FLAGS );
	if( result == -1 ) {
		debug3( "fcntl(F_NOTIFY)", " returned error\n", "" );
		return;
	}
	write3( 1, "notification set on ", thisDir -> name, "\n" );
}

void set_notifications( struct DirList * dirList )
{
	struct DirList * thisDir;

	if( dirList == NULL )
		return;

	for( thisDir = dirList; thisDir != NULL; thisDir = thisDir -> next )
		set_notification( thisDir );
}

int main( int argc, char ** argv )
{
	sigset_t sigSet;
	siginfo_t info;
	int result, length;
	DIR * dir;
	struct dirent * dirEnt;
	struct stat statBuf;
	char * buf, * cmd, * tmp, * slash, * dirName;
	struct FileList * fileList, * thisFile;
	struct DirList * dirList, * thisDir;

	result = 0;
	fileList = NULL;
	dirList = NULL;
	pid = getpid();

	if( argc > 1 ) {
		result = chdir( argv[ 1 ] );
		if( result == -1 )
			return myperror( "chdir" );
	}

	dir = opendir( "." );

	if( dir == NULL )
		return myperror( "opendir" );

	tmp = alloca( FILENAME_MAX + 1 );

	while( ( dirEnt = readdir( dir ) ) != NULL ) {
		length = strlen( dirEnt -> d_name );
		debug3( "=== scanning ", dirEnt -> d_name, " ===\n" );
		if( dirEnt -> d_name[0] == '.' && ( length == 1 ||
			( length == 2 && dirEnt -> d_name[1] == '.' ) ) )
			continue;
		result = stat( dirEnt -> d_name, &statBuf );
		if( result == -1 ) {
			write3( 2, "cannot stat ", dirEnt -> d_name, "\n" );
			continue;
		}
		if( ! S_ISDIR( statBuf.st_mode ) )
			continue;
		buf = alloca( length + 6 );
		thisFile = alloca( sizeof( struct FileList ) );
		thisFile -> next = fileList;
		fileList = thisFile;
		strncpy( buf, dirEnt -> d_name, length + 1 );
		cmd = buf + length;
		thisFile -> cmd = buf;
		thisFile -> name = NULL;
		dirName = NULL;
		strncpy( cmd, "/file", 6 );

		while( 1 ) {
			result = lstat( buf, &statBuf );
			if( result == -1 ) {
				write3( 2, "cannot stat ", buf, "\n" );
				break;
			}

			if( ! S_ISLNK( statBuf.st_mode ) )
				break;

			length = readlink( buf, tmp, FILENAME_MAX );
			if( result == -1 ) {
				write3( 2, "error resolving symlink ", buf, "\n" );
				break;
			}
			tmp[ length ] = '\0';
			debug3( " link=", buf, "\n" );
			debug3( "deref=", tmp, "\n" );
			buf = tmp;
		}
		if( result == -1 )
			continue;
		if( S_ISDIR( statBuf.st_mode ) ) {
			length = strlen( buf );
			thisFile -> name = NULL;
			dirName = alloca( length + 1 );
			strncpy( dirName, buf, length + 1 );
		}
		else {
			thisFile -> mtime = statBuf.st_mtime;
			length = strlen( buf );
			thisFile -> name = alloca( length + 1 );
			strncpy( thisFile -> name, buf, length + 1 );
			dirName = buf;
			slash = NULL;
			while( *buf != '\0' ) {
				if( *buf == '/' )
					slash = buf;
				buf++;
			}
			if( slash == NULL )
				dirName = ".";
			else
				*slash = '\0';
		}
		for( thisDir = dirList; thisDir != NULL; thisDir = thisDir -> next ) {
			debug3( "thisDir.name=", thisDir -> name, "\n" );
			debug3( "dirName=", dirName, "\n" );
			if( strcmp( thisDir -> name, dirName ) == 0 )
				break;
		}
		if( thisDir == NULL ) {
			debug3( dirName, " not", " found in dirList\n" );
			thisDir = alloca( sizeof( struct DirList ) );
			thisDir -> next = dirList;
			length = strlen( dirName ) + 1;
			thisDir -> name = alloca( length );
			strncpy( thisDir -> name, dirName, length );
			dirList = thisDir;
		}
		else {
			debug3( dirName, " found in dirList\n", "" );
		}
		thisFile -> dir = thisDir;

		result = open( dirName, O_RDONLY );
		if( result == -1 ) {
			write3( 2, "error opening ", buf, "\n" );
		}
		thisDir -> fd = result;
		strncpy( cmd, "/run", 5 );
		debug3( "file=", thisFile -> name ? thisFile -> name : "NULL", "\n" );
		debug3( " dir=", thisFile -> dir -> name ? thisFile -> dir -> name : "NULL", "\n" );
		debug3( " cmd=", thisFile -> cmd ? thisFile -> cmd : "NULL", "\n" );
	}

	set_notifications( dirList );

	if( sigemptyset( &sigSet ) == -1 )
		return myperror( "sigemptyset" );
		
	result += sigaddset( &sigSet, SIGXYZ );
	result += sigaddset( &sigSet, SIGIO );
	result += sigaddset( &sigSet, SIGQUIT );
	result += sigaddset( &sigSet, SIGINT );
	result += sigaddset( &sigSet, SIGTERM );

	if( result < 0 )
		return myperror( "sigaddset" );

	if( sigprocmask( SIG_BLOCK, &sigSet, 0 ) == -1 )
		return myperror( "sigprocmask" );

	while( 1 ) {
		result = sigwaitinfo( &sigSet, &info );
		if( result == -1 )
			return myperror( "sigwaitinfo" );
		if( result == SIGIO )
			debug( "SIGIO received\n" );
		else if( result == SIGXYZ ) {
			debug( "SIGRTMIN+x received\n" );
			for( thisFile = fileList; thisFile != NULL; thisFile = thisFile -> next ) {
				if( thisFile -> dir -> fd != info.si_fd )
					continue;
				if( ! thisFile -> name )
					continue;
				result = stat( thisFile -> name, &statBuf );
				if( result == -1 ) {
					write3( 2, "cannot stat ", thisFile -> name, "\n" );
					continue;
				}
				if( statBuf.st_mtime <= thisFile -> mtime )
					continue;
				thisFile -> mtime = statBuf.st_mtime;

				write3( 1, thisFile -> name, "", " has changed\n" );

				if( ! thisFile -> cmd )
					continue;

				write3( 1, "calling ", thisFile -> cmd, "\n" );
				system( thisFile -> cmd );
			}
		}
		else if( result == SIGQUIT || result == SIGINT || result == SIGTERM ) {
			debug( "QUIT, INT or TERM received\n" );
			return 0;
		}
	}
	return 0;
}
