%%%
%%% edupe.erl - Program for finding duplicate files
%%%
%%% This is free software; you can redistribute it and/or modify it under
%%% the terms of the GNU Library General Public License as published by
%%% the Free Software Foundation; either version 2 of the License, or
%%% (at your option) any later version.
%%%
%%% This program is distributed in the hope that it will be useful, but
%%% WITHOUT ANY WARRANTY; without even the implied warranty of
%%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
%%% General Public License for more details.
%%%
%%% You should have received a copy of the GNU Library General Public
%%% License along with this program; if not, write to the Free Software
%%% Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
%%%
%%% sloutri@iit.edu and wilbjor@iit.edu
%%%
%%% To compile, you need Erlang(http://www.erlang.org) installed, then run
%%  $ erlc edupe.erl
%%%        
%%% usage:  erl -noshell -run edupe start /path/to/directory -s erlang halt


-module(edupe).
-export([start/1]).

start(Dir) -> 
  crypto:start(),
  io:format("Generating File List~n"),
  FileListing = generate_file_listing(Dir),
  io:format("Finding Dupes~n"),
  find_dupes(FileListing),
  crypto:stop().

% generates file listing recursively with size of each file        
generate_file_listing(Dir) ->
  case file:list_dir(Dir) of
    {ok, FileListing} -> add_file_size(Dir, FileListing,[]);
    _ -> io:format("Unable to read directory: ~s~n", [Dir]), []
  end.

% add file size, and recurse if directory
add_file_size(_, [], FileListingWithType) -> FileListingWithType;
add_file_size(Dir, [H | T], FileListingWithType) ->
  case file:read_link_info(Dir ++ "/" ++ H) of 
    {ok, {_,Size,FileType,_,_,_,_,_,_,_,_,_,_,_}} ->
      case FileType of
        regular -> add_file_size(Dir, T, [{Dir ++ "/" ++ H, Size} | FileListingWithType]);
        directory -> add_file_size(Dir, T, generate_file_listing(Dir ++ "/" ++ H) ++ FileListingWithType);
        _ -> add_file_size(Dir, T, FileListingWithType)
      end;
    _ ->
      io:format("Could not read file: ~s", [Dir ++ "/" ++ H]),
      add_file_size(Dir, T, FileListingWithType)
  end.

% find dupes by first sorted by size, then checking hashes of files with same size
find_dupes(TupleList) -> find_dupes1(lists:sort(fun({_,L}, {_,R}) -> L =< R end, TupleList)).
find_dupes1([]) -> ok;
find_dupes1([_ | []]) -> ok;
find_dupes1(List) ->
  [_ | [{Filename2, Size2} | T]] = List,
  {CheckList, List2} = split_list(List),
  case length(CheckList) > 1 of
    false -> find_dupes([{Filename2, Size2} | T]);
    true ->
      HashList = add_hashes(CheckList),
      find_dupe_hash(HashList),
      find_dupes1(List2)
  end.

% find if files have same hash, if so, they are a duplicate
find_dupe_hash(TupleList) -> find_dupe_hash(lists:sort(fun({_,_,L}, {_,_,R}) -> L =< R end, TupleList), -1).
find_dupe_hash([], _) -> ok;
find_dupe_hash([_ | []], _) -> ok;
find_dupe_hash([{Filename, Size, Hash} | [{Filename2, Size2, Hash2} | T]], LastHash) ->
  case Hash == Hash2 of
    false -> ok;
    true ->
      if  
        Hash =/= LastHash -> io:format(":: size=~w~n~s~n~s~n", [Size, Filename, Filename2]);
	true -> io:format("~s~n", [Filename2])
      end
  end,
  find_dupe_hash([{Filename2, Size2, Hash2} | T], Hash).

% split the list where the file size changes
split_list(List) -> {_,Size} = hd(List), split_list(List, [], Size).
split_list([], List1, _) -> {List1, []};
split_list([{Filename, Size} | T], List1, LastSize) ->
  if 
    Size == LastSize -> split_list(T, [{Filename, Size} | List1], Size);
    true -> {List1, [{Filename, Size} | T]}
  end.

% get hashes of a file list
add_hashes(List) -> add_hashes(List, []).
add_hashes([], NewList) -> NewList;
add_hashes([{Filename, Size} | T], NewList) ->
  case get_hash(Filename, Size) of
    {ok, Hash} -> add_hashes(T, [{Filename, Size, Hash} | NewList]);
    {error, _} -> add_hashes(T, NewList)
  end.

% gets hash of a file, if file > 512bytes, only get first and last 256 bytes
% in order to increase speed, accuracy is minimally affected
get_hash(_, 0) -> {ok,crypto:md5([])};
get_hash(Filename, Size) ->
  case file:open( Filename, [read]) of
    {ok,File} ->
      if 
        Size < 512 -> {ok,[Chunk1]} = file:pread( File, [{0,Size}]), Chunk2=[];
        true -> {ok,[Chunk1,Chunk2]} = file:pread( File, [{0,256},{Size-256,256}])
      end,
      Hash = crypto:md5(lists:append(Chunk1,check_eof(Chunk2))),
      file:close(File),
      {ok, Hash};
    _ -> {error, nofile}
  end.

% if filesize changes between time we got listing and when we goto get a hash
% the pread in get_hash will get an eof which is bad for list:append
check_eof(F) ->
  if 
    F == eof -> [];
    true -> F
  end.

%% just a debug function to print the file listing  
%print_file_listing([]) -> ok;
%print_file_listing([{FileName, Size} | T]) ->
%  io:format("~s::~w~n", [FileName, Size]),
%  print_file_listing(T).
