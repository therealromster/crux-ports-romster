/*
  GEFAttr.c:  Attribute object of GEF.

  Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
 */
#include <stdio.h>

#include <gef/GEFAttr.h>

void
GEFAttr_Init(GEFAttr_t* attrs) {
    attrs->Abort = NULL;
    attrs->AssertionViolation = NULL;
    attrs->PreconditionViolation = NULL;
    attrs->PostconditionViolation = NULL;
    attrs->PreInvariantViolation = NULL;
    attrs->PostInvariantViolation = NULL;
    attrs->UnhandledException = NULL;
    attrs->Exit = NULL;
#ifdef GEF_POSIX
    attrs->OSSignalToException = NULL;
#endif
    attrs->Error = NULL;
    attrs->OutOfMemory = NULL;
    attrs->UserCatch = NULL;
    attrs->Delete = NULL;
}


void
GEFAttr_SetAbort(GEFAttr_t* attrs, void (*callBack)(int)) {
    attrs->Abort = callBack;
}

void
GEFAttr_SetAssertionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int)) {
    attrs->AssertionViolation = callBack;
}

void
GEFAttr_SetPreconditionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int)) {
    attrs->PreconditionViolation = callBack;
}

void
GEFAttr_SetPostconditionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int)) {
    attrs->PostconditionViolation = callBack;
}

void
GEFAttr_SetPreInvariantViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int)) {
    attrs->PreInvariantViolation = callBack;
}

void
GEFAttr_SetPostInvariantViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int)) {
    attrs->PostInvariantViolation = callBack;
}

void
GEFAttr_SetUnhandledException(GEFAttr_t* attrs, void (*callBack)(void*)) {
    attrs->UnhandledException = callBack;
}

void
GEFAttr_SetExit(GEFAttr_t* attrs, void (*callBack)(int)) {
    attrs->Exit = callBack;
}

void
GEFAttr_SetOutOfMemory(GEFAttr_t* attrs, void (*callBack)(void)) {
    attrs->OutOfMemory = callBack;
}

#ifdef GEF_POSIX
void
GEFAttr_SetOSSignalToException(GEFAttr_t* attrs, void* (*callBack)(int)) {
    attrs->OSSignalToException = callBack;
}
#endif

void
GEFAttr_SetError(GEFAttr_t* attrs, void (*callBack)(const char* fmt, ...)) {
    attrs->Error = callBack;
}

void
GEFAttr_SetUserCatch(GEFAttr_t* attrs, void (*callBack)(void*, void*)) {
    attrs->UserCatch = callBack;
}

void
GEFAttr_SetDelete(GEFAttr_t* attrs, void (*callBack)(void**)) {
    attrs->Delete = callBack;
}

