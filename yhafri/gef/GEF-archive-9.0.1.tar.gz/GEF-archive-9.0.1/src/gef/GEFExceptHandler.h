/*
  GEF: A General Exception-Handling Facility, which also support "Programming
  by Contract."

  Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
 */
#ifndef GEF_EXCEPT_HANDLER_H
#define GEF_EXCEPT_HANDLER_H

#ifdef GEF_POSIX
#include <signal.h>
#endif
#include <stdarg.h>
#include <setjmp.h>
#include <gef/GEFAttr.h>

#ifndef sig_atomic_t
#define sig_atomic_t int
#endif

typedef enum {
    GEF_ASSERT_LEVEL_NONE = 0,
    GEF_ASSERT_LEVEL_PRE,
    GEF_ASSERT_LEVEL_POST,
    GEF_ASSERT_LEVEL_INVARIANTS,
    GEF_ASSERT_LEVEL_TOTAL
} GEFAssertLevel_t;

typedef enum {
  GEF_EXCEPT_INIT = 0, /* Must be zero - Return from setjmp */
  GEF_EXCEPT_PREINVARIANTS,
  GEF_EXCEPT_POSTINVARIANTS,
  GEF_EXCEPT_PRECONDS,
  GEF_EXCEPT_TRY,
  GEF_EXCEPT_RETRY,
  GEF_EXCEPT_FINALLY,
  GEF_EXCEPT_CATCH,
  GEF_EXCEPT_POSTCONDS,
  GEF_EXCEPT_SUCCESS,
  GEF_EXCEPT_FAILURE,
  GEF_EXCEPT_INVALID,
  GEF_EXCEPT_DONE,
  GEF_EXCEPT_NUMBER
} GEFStateID_t;

typedef struct {
   GEFStateID_t id;
   char* name;
} GEFState_t;

typedef struct {
   jmp_buf env;
   int numberOfAttempts;
   int isFinallyEnabled;
   void* exceptionID;
   GEFStateID_t current;
   GEFStateID_t previous;
#ifdef GEF_POSIX
   sigset_t mask;
#endif
   GEFAssertLevel_t previousAssertLevel;
} GEFCheckPoint_t;

/* These exception values are reserved by GEF. Do not mix exception values with these values! */
/* You may redefine these values via the appropriate call-back functions. */
#define GEF_EXCEPTION_FAILURE                                  0
#define GEF_EXCEPTION_UNHANDLED                     1
#define GEF_EXCEPTION_NO_MEMORY                      2
/* The next define is an alias for NO_MEMORY */
#define GEF_EXCEPTION_INSUFFICIENT_MEMORY                      2
#define GEF_EXCEPTION_ASSERTION_VIOLATION 3
#define GEF_EXCEPTION_PRECONDITION_VIOLATION 4
#define GEF_EXCEPTION_POSTCONDITION_VIOLATION 5
#define GEF_EXCEPTION_PREINVARIANT_VIOLATION 6
#define GEF_EXCEPTION_POSTINVARIANT_VIOLATION 7
#define GEF_EXCEPTION_BREAK_WITHIN_NON_VOLATILE_TRY_BLOCK 8
#define GEF_EXCEPTION_RETRY_WITHIN_NON_VOLATILE_TRY_BLOCK 9
#define GEF_EXCEPTION_LAST 9

typedef struct {
   const char* programName;
   int enabled;
   int debug;
   GEFAssertLevel_t assertLevel;
   int jump;
   GEFState_t states[GEF_EXCEPT_NUMBER];
   GEFState_t stateTransitions[GEF_EXCEPT_NUMBER][GEF_EXCEPT_NUMBER][GEF_ASSERT_LEVEL_TOTAL];
   GEFCheckPoint_t* stack;
   size_t ssize;
   size_t sp;
   int inCriticalSection;
   void (*Abort)(int);
   void (*AssertionViolation)(const char*, const char*, const char*, int);
   void (*PreconditionViolation)(const char*, const char*, const char*, int);
   void (*PostconditionViolation)(const char*, const char*, const char*, int);
   void (*PreInvariantViolation)(const char*, const char*, const char*, int);
   void (*PostInvariantViolation)(const char*, const char*, const char*, int);
   void (*UnhandledException)(void*);
   void (*Exit)(int);
   void* (*OSSignalToException)(int);
   void (*Error)(const char* format, ...);
   void (*OutOfMemory)(void);
   void (*UserCatch)(void* userData, void* exceptionID);
   int (*ProcessID)(void);
   void (*Delete)(void** exceptionID);
#ifdef GEF_POSIX
   int supportAsyncSignals;
   sigset_t mask;
   sigset_t signalMask;
#endif
} *GEFExceptionHandler_t;


extern
int
GEFExceptionHandler_IsEnabled(GEFExceptionHandler_t eh);

extern
int
GEFExceptionHandler_Enable(GEFExceptionHandler_t eh);

extern
int
GEFExceptionHandler_Disable(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_SetDebug(GEFExceptionHandler_t eh, int value);

extern
void
GEFExceptionHandler_SetAssertions(GEFExceptionHandler_t eh, int value);

extern
void
GEFExceptionHandler_EnablePreconditions(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_EnablePostconditions(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_EnableInvariants(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_DisablePreconditions(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_DisablePostconditions(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_DisableInvariants(GEFExceptionHandler_t eh);

extern
int
GEFExceptionHandler_GetAssertions(GEFExceptionHandler_t eh);

extern
int
GEFExceptionHandler_IsPreconditionsEnabled(GEFExceptionHandler_t eh);


extern
int
GEFExceptionHandler_IsPostconditionsEnabled(GEFExceptionHandler_t eh);


extern
int
GEFExceptionHandler_IsInvariantsEnabled(GEFExceptionHandler_t eh);

#ifdef GEF_POSIX
extern
void
GEFExceptionHandler_SetAsyncSupport(GEFExceptionHandler_t eh, int value);
#endif

#ifdef GEF_POSIX
extern
int
GEFExceptionHandler_GetAsyncSupport(GEFExceptionHandler_t eh);
#endif

extern
int
GEFExceptionHandler_StackDepth(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_GrowStack(GEFExceptionHandler_t eh);

#ifdef GEF_POSIX
extern
void
GEFExceptionHandler_SetSignals(GEFExceptionHandler_t eh, sigset_t signalSet);
#endif

extern
void
GEFExceptionHandler_SetAssertionLevel(GEFExceptionHandler_t eh, int assert_level);

extern
GEFExceptionHandler_t
GEFExceptionHandler_New(GEFAttr_t attrs);

extern
GEFStateID_t
GEFExceptionHandler_NextState(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_Break(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_Delete(GEFExceptionHandler_t* eh);

extern
void
GEFExceptionHandler_Retry(GEFExceptionHandler_t eh);

extern
GEFCheckPoint_t*
GEFExceptionHandler_CheckPoint(GEFExceptionHandler_t eh, int max, int fin);

extern
void*
GEFExceptionHandler_GetException(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_RaiseException(GEFExceptionHandler_t eh, void* id);

extern
void
GEFExceptionHandler_BeginCriticalSection(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_EndCriticalSection(GEFExceptionHandler_t eh);

extern
void
GEFExceptionHandler_InsufficientMemory(GEFExceptionHandler_t eh);

#endif /* GEF_EXCEPT_HANDLER - General Exception Handler */
