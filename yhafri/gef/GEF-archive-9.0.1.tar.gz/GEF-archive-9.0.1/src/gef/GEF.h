/*
GEF: A General Exception-Handling Facility, which also supports

Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Library General Public License for more details.

You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA.
*/
#ifndef GEF_H
#define GEF_H

#include <stdlib.h>
#include <gef/GEFAttr.h>
#include <gef/GEFExceptHandler.h>

#ifdef GEF_POSIX
typedef void (*GEFSignalHandler_t)(int);
#endif

extern
GEFExceptionHandler_t
GEFGetExceptionHandler(void);
/*
Effects: Returns the exception handler for the currently executing thread.
*/

#ifdef GEF_POSIX
extern
GEFSignalHandler_t
GEFSignal(int signum, GEFSignalHandler_t h);
/*
Effects: Registers the signal handler, <h>, for signal, <signum>.
*/
#endif

extern
void
GEFBeginCriticalSection(GEFExceptionHandler_t eh);
/*
Effects: Instructs the OS to postpone its delivery of signals that <eh> is
responsible for handling.
*/

extern
void
GEFEndCriticalSection(GEFExceptionHandler_t eh);
/*
Effects: Instructs the OS to deliver any pending signals that <eh> is responsible
for handling.
*/


#ifdef GEF_POSIX
extern
void
GEFInitializeSignals(sigset_t);
/*
Effects: Initialize the General Exception Facility, where <signalSet> is the set of
OS signals that GEF will handle for the process.
*/
#endif

extern
void
GEFInitialize(int*, char***);
/*
Effects: Initialize the General Exception Facility.
*/

extern
void
GEFInitializeThread(GEFAttr_t attrs);
/*
Effects: Creates and initializes the exception handler, accodring to the
configuration, <attrs>,  for the currently running thread, and stores the
exception handler in the thread's private data area. Each thread must call
this function prior to using the GEF facilities, even in a single-threaded
program.
*/

extern
void
GEFAssert(int expressionValue, const char* expressionString, const char* fileName, const char* function, int lineNumber);
/*
Effects: If 'expressionValue' is non-zero (true), throws the reserved exception, 
GEF_EXCEPTION_ASSERTION;  otherwise returns.
*/

extern
void
GEFAlwaysAssert(int expressionValue, const char* expressionString, const char* fileName, const char* function, int lineNumber);
/*
Effects: If 'expressionValue' is non-zero (true), throws the reserved exception, 
GEF_EXCEPTION_ASSERTION;  otherwise returns.  Executes regardless of assertion level.
*/

extern
void
GEFAssertPrecondition(int expressionValue, const char* expressionString, const char* fileName, const char* function, int lineNumber);
/*
Effects: If 'expressionValue' is non-zero (true), throws the reserved exception, 
GEF_EXCEPTION_PRECONDITION;  otherwise returns.
*/


extern
void
GEFAssertPostcondition(int expressionValue, const char* expressionString, const char* fileName, const char* function, int lineNumber);
/*
Effects: If 'expressionValue' is non-zero (true), throws the reserved exception, 
GEF_EXCEPTION_POSTCONDITION;  otherwise returns.
*/

extern
void
GEFAssertInvariant(int expressionValue, const char* expressionString, const char* fileName, const char* function, int lineNumber, int _gefstate);
/*
Effects: If 'expressionValue' is non-zero (true), throws the reserved exception, 
GEF_EXCEPTION_INVARIANT;  otherwise returns.
*/

extern
void
GEFRaiseException(void*);
/*
Effects: Transfers control to the most recent checkpoint of an exception handler.
*/

extern
int
GEFStackDepth(void);
/*
Effects: Returns the depth of the checkpoint stack of the currently executing
thread.
*/

extern
void
GEFExecuteUserCatch(void* exception, void* data);
/*
Effects: If the exception handler of the currently executing thread does not
specify a user-defined call-back function, then the function does nothing;
otherwise, it calls the user-defined call-back, specifying <data> as the first
argument and <exception> as the second argument.
*/

#ifdef GEF_POSIX
extern
void
GEFCatchSignal(int signo);
/*
Effects: Catches all OS signals and converts them into GEF exceptions.
*/
#endif

extern
void
GEFSetDebug(int value);
/*
Effects: Turns on debugging for the GEF facility. It prints a trace of its actions to
the standard error stream.
*/

#ifdef GEF_POSIX
extern
void
GEFSetAsyncSupport(int value);
/*
Effects: If <value> is non-zero (true), turns on support for asynchronous
signals; otherwise turns off support for asynchronous signals.
Caveat: In this implementation, GEF requires that pthread_getspecific is async-
safe. However, Posix does not require the function to be async safe. 
Consequently, use async support with caution.  Fortunately, the function,
<pthread_getspecific>, is safe for several major UNIX operating systems.
Also note that, in some operating systems, support OS signals can introduce a
significant amount of overhead, causing the relative performance of handling
exceptions to decrease by a significant factor.  Results will vary between
operating systems.
*/
#endif

#ifdef GEF_POSIX
extern
int
GEFGetAsyncSupport(void);
/*
Effects: Returns non-zero (true), if asynchronous OS signal support is on;
otherwise returns 0 (false).
*/
#endif

#define gef_throw(e) { void* _ex = e; GEFRaiseException(_ex); }
/*
  Effects: Transfers control to the most recent checkpoint of the currently
  executing thread and passes <e> as the exception.
 */

#define gef_retry \
if (_isgefenabled) { \
    GEFExceptionHandler_Retry(_gefeh); \
} else { \
    gef_throw((void*) GEF_EXCEPTION_RETRY_WITHIN_NON_VOLATILE_TRY_BLOCK); \
}
/*
Effects:A keyword macro, <gef_retry>, which transfers the control of the
  currently executing thread to the most recent checkpoint of <_gefeh>.
 */

#define gef_break \
if (_isgefenabled) { \
    GEFExceptionHandler_Break(_gefeh); \
} else { \
    gef_throw((void*) GEF_EXCEPTION_BREAK_WITHIN_NON_VOLATILE_TRY_BLOCK); \
}
/*
  Effects: Terminates the exception-handler so that control passes to the first
  statement which appears outside of the scope of the currently executing
  exception block.
 */

#define gef_begin_critical_section \
GEFBeginCriticalSection(_gefeh)
/*
  Effects: A keyword macro which prevents the OS from delivering the signals
  that <_gefeh> handles.
 */

#define gef_end_critical_section \
GEFEndCriticalSection(_gefeh)
/*
  Effects: A keyword macro which allows the OS to deliver the pending signals
  that <_gefeh> handles.
 */

#define gef_depth \
GEFStackDepth()
/*
  Effects: Returns the depth of the checkpoint stack in the exception handler of
  the currently executing thread.
 */

#ifdef GEF_POSIX
#define gef_enable_async_support \
GEFSetAsyncSupport(1)
/*
  Effects: A keyword macro for enabling support for asynchronous OS signals.
 */
#endif

#ifdef GEF_POSIX
#define gef_disable_async_support \
GEFSetAsyncSupport(0)
/*
  Effects: A keyword macro for disabling support for asynchronous OS signals.
 */
#endif

#ifdef GEF_POSIX
#define gef_is_async_support_enabled \
GEFGetAsyncSupport()

/* Deprecated - Use gef_is_async_support_enabled! */
#define gef_async_support_is_enabled \
GEFGetAsyncSupport()
/*
  Effects: A keyword macro predicate for determining whether async support is
  enabled.
 */
#endif

#define gef_enable_assertions \
 GEFSetAssertions(1)
/*
   Effects: A keyword macro predicate for enabling support for assertion
   statements.
*/

#define gef_disable_assertions \
GEFSetAssertions(0)
/*
   Effects: A keyword macro for disabling support for assertion statements.
*/

#define gef_enable_preconditions \
GEFEnablePreconditions()

#define gef_disable_preconditions \
GEFDisablePreconditions()

#define gef_enable_postconditions \
GEFEnablePostconditions()

#define gef_disable_postconditions \
GEFDisablePostconditions()

#define gef_enable_invariants \
GEFEnableInvariants()

#define gef_disable_invariants \
GEFDisableInvariants()


#define gef_is_assertions_support_enabled \
GEFGetAssertions()

/* Deprecated - Use gef_is_assertions_support_enabled. */
#define gef_assertions_support_is_enabled \
GEFGetAssertions()
/*
   Effects: A keyword macro predicate for determining whether assertion support
   is enabled.
*/

#define gef_enable \
GEFEnable()

#define gef_disable \
GEFDisable()

#define gef_is_enabled \
GEFIsEnabled()

#define gef_enable_debug \
GEFSetDebug(1)
/*
  Effects: A keyword macro for enabling debugging.
 */

#define gef_disable_debug \
GEFSetDebug(0)
/*
  Effects: A keyword macro for disabling debugging.
 */

#if defined GEF_DOS
#ifdef WIN32
#ifdef __LCC__ /* It's lcc-win32! */

#ifndef __func__
#define __func__ __func__
#endif

#else

#define __func__ "<Undefined-Function-Name>"

#endif
#endif

#elif defined GEF_LINUX
    /* Do nothing */
#elif defined GEF_SOLARIS
    /* Do nothing */
#else
#define __func__ "<Undefined>"
#endif

#ifndef NDEBUG
#define gef_assert(exp) {\
    int _boolexp = (exp);\
    const char* _expString = #exp;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssert(_boolexp, _expString, _filename, _funcname, _linenum);\
}
#else
#define gef_assert(exp)
#endif

#ifndef NDEBUG
#define gef_assert_implication(exp1, exp2) {\
    int _boolexp = (!(exp1)) || (exp2);\
    const char* _expString = #exp1 " implies " #exp2;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssert(_boolexp, _expString, _filename, _funcname, _linenum);\
}
#else
#define gef_assert_implication(exp)
#endif

#define gef_volatile_assert(exp) {\
    int _boolexp = (exp);\
    const char* _expString = #exp;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAlwaysAssert(_boolexp, _expString, _filename, _funcname, _linenum);\
}

#define gef_volatile_assert_implication(exp1, exp2) {\
    int _boolexp = (!(exp1)) || (exp2);\
    const char* _expString = #exp1 " implies " #exp2;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAlwaysAssert(_boolexp, _expString, _filename, _funcname, _linenum);\
}

#define gef_assert_precondition(exp) {\
    int _boolexp = (exp);\
    const char* _expString = #exp;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertPrecondition(_boolexp, _expString, _filename, _funcname, _linenum);\
}

#define gef_assert_precondition_implication(exp1, exp2) {\
    int _boolexp = (!(exp1)) || (exp2);\
    const char* _expString = #exp1 " implies " #exp2;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertPrecondition(_boolexp, _expString, _filename, _funcname, _linenum);\
} 

#define gef_assert_postcondition(exp) {\
    int _boolexp = (exp);\
    const char* _expString = #exp;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertPostcondition(_boolexp, _expString, _filename, _funcname, _linenum);\
}

#define gef_assert_postcondition_implication(exp1, exp2) {\
    int _boolexp = (!(exp1)) || (exp2);\
    const char* _expString = #exp1 " implies " #exp2;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertPostcondition(_boolexp, _expString, _filename, _funcname, _linenum);\
}

#define gef_assert_invariant(exp) {\
    int _boolexp = (exp);\
    const char* _expString = #exp;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertInvariant(_boolexp, _expString, _filename, _funcname, _linenum, _gefstate);\
}

#define gef_assert_invariant_implication(exp1, exp2) {\
    int _boolexp = (!(exp1)) || (exp2);\
    const char* _expString = #exp1 " implies " #exp2;\
    const char* _filename = __FILE__;\
    const char* _funcname =__func__;\
    int _linenum = __LINE__;\
    GEFAssertInvariant(_boolexp, _expString, _filename, _funcname, _linenum, _gefstate);\
}

extern
void
GEFPrintSignalMask(void);

extern
const char*
GEFProgramName(void);

#ifdef NDEBUG
#define gef_try \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = NULL;\
   const int _isgefenabled = 0;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#else
#define gef_try \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   int _isgefenabled = GEFExceptionHandler_IsEnabled(_gefeh);\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

#define gef_volatile_try \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

#define gef_volatile_try_with_preconditions \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_preconditions \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#endif

#define gef_volatile_try_with_postconditions \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_postconditions \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

#define gef_volatile_try_with_invariants \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_invariants \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 1);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception.
*/

#ifdef NDEBUG
#define gef_try_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = NULL;\
   const int _isgefenabled = 0;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#else
#define gef_try_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   int _isgefenabled = GEFExceptionHandler_IsEnabled(_gefeh);\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif
/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception.
*/

#define gef_volatile_try_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif

#define gef_volatile_try_with_preconditions_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_preconditions_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif

#define gef_volatile_try_with_postconditions_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_postconditions_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif

#define gef_volatile_try_with_invariants_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_try_with_invariants_without_finalize \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, 0, 0);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif

#ifdef NDEBUG
#define gef_repeat_try(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = NULL;\
   const int _isgefenabled = 0;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#else
#define gef_repeat_try(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   int _isgefenabled = GEFExceptionHandler_IsEnabled(_gefeh);\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception. However, upon failure of a try block, this code will repeat
  the block automatically until it is successful, or until the number of attempts
  reaches <n>. After <n> attempts, the code transfers control to the catch block,
  if any. If no catch block exists for the current exception block, then GEF
  transfers control to the checkpoint which is on the top of the exception handler
  stack of the currently executing thread.
*/
#define gef_volatile_repeat_try(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

#define gef_volatile_repeat_try_with_preconditions(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_with_preconditions(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#endif

#define gef_volatile_repeat_try_with_postconditions(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_with_postconditions(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

#define gef_volatile_repeat_try_with_invariants(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_invariants(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 1);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               {
#endif

/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception. However, upon failure of a try block, this code will repeat
  the block automatically until it is successful, or until the number of attempts
  reaches <n>. After <n> attempts, the code transfers control to the catch block,
  if any. If no catch block exists for the current exception block, then GEF
  transfers control to the checkpoint which is on the top of the exception handler
  stack of the currently executing thread.
*/

#ifdef NDEBUG
#define gef_repeat_try_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = NULL;\
   const int _isgefenabled = 0;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#else
#define gef_repeat_try_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   int _isgefenabled = GEFExceptionHandler_IsEnabled(_gefeh);\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#endif
/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception. However, upon failure of a try block, this code will repeat
  the block automatically until it is successful, or until the number of attempts
  reaches <n>. After <n> attempts, the code transfers control to the catch block,
  if any. If no catch block exists for the current exception block, then GEF
  transfers control to the checkpoint which is on the top of the exception handler
  stack of the currently executing thread.
*/


#define gef_volatile_repeat_try_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#endif

#define gef_volatile_repeat_try_with_preconditions_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_with_preconditions_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnablePreconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#endif

#define gef_volatile_repeat_try_with_postconditions_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_with_postconditions_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnablePostconditions(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#endif

#define gef_volatile_repeat_try_with_invariants_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFFALSE;\
   const int _gef_previous_async_state = GEFFALSE;\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

#ifdef GEF_POSIX
#define gef_posix_repeat_try_with_invariants_without_finalize(n) \
{  GEFStateID_t _gefstate;\
   GEFExceptionHandler_t _gefeh = GEFGetExceptionHandler();\
   const int _isgefenabled = GEFTRUE;\
   const int _isgef_posix_semantics = GEFTRUE;\
   int _gef_previous_async_state = GEFExceptionHandler_GetAsyncSupport(_gefeh);\
   GEFCheckPoint_t* _gefcp;\
   if (_isgefenabled) {\
      GEFExceptionHandler_SetAsyncSupport(_gefeh, 1);\
      _gefcp = GEFExceptionHandler_CheckPoint(_gefeh, n, 0);\
      GEFExceptionHandler_EnableInvariants(_gefeh);\
      _gefstate = setjmp(_gefcp->env);\
   } else _gefstate = GEF_EXCEPT_TRY;\
   do {\
      switch(_gefstate) {\
         case GEF_EXCEPT_TRY:\
            if (_isgefenabled) GEFExceptionHandler_EndCriticalSection(_gefeh);\
            else _gefstate = GEF_EXCEPT_DONE;\
            {\
               {
#endif

/*
  Effects: Introduces preamble code that creates a checkpoint and prepares to
  handle an exception. However, upon failure of a try block, this code will repeat
  the block automatically until it is successful, or until the number of attempts
  reaches <n>. After <n> attempts, the code transfers control to the catch block,
  if any. If no catch block exists for the current exception block, then GEF
  transfers control to the checkpoint which is on the top of the exception handler
  stack of the currently executing thread.
*/

#ifdef NDEBUG
#define gef_invariants \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
               else _gefstate = GEF_EXCEPT_FINALLY;\
            }\
	    break;\
	 case GEF_EXCEPT_PREINVARIANTS:\
	 case GEF_EXCEPT_POSTINVARIANTS:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_DONE;\
	    {\
	       if (_isgefenabled)\
               {
#else
#define gef_invariants \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
	    break;\
	 case GEF_EXCEPT_PREINVARIANTS:\
	 case GEF_EXCEPT_POSTINVARIANTS:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_DONE;\
	    {\
	       if (_isgefenabled)\
               {
#endif

/*
   Effects: Introduces body code into an exception block which handles invariant
   statements. GEF executes all of the statements in this block before entering the
   preconditions block and after exiting the postconditions block.
*/

#define gef_preconditions \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
	    break;\
	 case GEF_EXCEPT_PRECONDS:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_DONE;\
	    {\
	       if (_isgefenabled)\
               {

/*
   Effects: Introduces body code into an exception block which handles
   precondition statements.
*/

#define gef_postconditions \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
	    break;\
	 case GEF_EXCEPT_POSTCONDS:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_DONE;\
	    {\
	       if (_isgefenabled)\
               {

/*
   Effects: Introduces body code into an exception block which handles
   postconditions statements.
*/

#define gef_finalize \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
            break;\
         case GEF_EXCEPT_FINALLY:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_DONE;\
            {\
               {

/*
  Effects: Introduces body code into an exception block which handles the final
  actions that an exception-handler must perform.
 */

#define gef_catch(e) \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
            break;\
         case GEF_EXCEPT_CATCH:\
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               void* e = GEFExceptionHandler_GetException(_gefeh);\
               {

/*
  Effects: Introduces body code into an exception block which catches all
  exceptions.
*/

#define gef_catch_with(e, userData)\
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
            break;\
         case GEF_EXCEPT_CATCH: \
            if (!_isgefenabled) _gefstate = GEF_EXCEPT_FINALLY;\
            {\
               void* e = GEFExceptionHandler_GetException(_gefeh);\
               _gefeh->UserCatch(userData, e);\
               {

/*
  Effects: Introduces body code into an exception block which catches all
  exceptions, but transfers control to a user-defined call-back.
*/

#ifdef GEF_POSIX
#define gef_end \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
            break;\
         case GEF_EXCEPT_SUCCESS:\
            if (!_isgefenabled) { gef_throw((void*) GEF_EXCEPTION_FAILURE); }\
            else _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            break;\
         default:\
            if (!_isgefenabled) {\
	       if (_gefstate == GEF_EXCEPT_FINALLY) {\
		   _gefstate = GEF_EXCEPT_DONE;\
	       } else { gef_throw((void*) GEF_EXCEPTION_FAILURE); }\
	    } else { _gefstate = GEFExceptionHandler_NextState(_gefeh); }\
            break;\
      }\
   } while (_gefstate != GEF_EXCEPT_DONE);\
   if (_isgefenabled) {\
      GEFExceptionHandler_EndCriticalSection(_gefeh);\
      if (_isgef_posix_semantics) {\
         if (!_gef_previous_async_state) {\
            GEFExceptionHandler_SetAsyncSupport(_gefeh, 0);\
         }\
      }\
   }\
}
#else
#define gef_end \
               }\
               if (_isgefenabled) _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            }\
            break;\
         case GEF_EXCEPT_SUCCESS:\
            if (!_isgefenabled) { gef_throw((void*) GEF_EXCEPTION_FAILURE);}\
            else _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            break;\
         default:\
            if (!_isgefenabled) {\
	       if (_gefstate == GEF_EXCEPT_FINALLY) {\
		   _gefstate = GEF_EXCEPT_DONE;\
	       } else { gef_throw((void*) GEF_EXCEPTION_FAILURE);}\
	    } else _gefstate = GEFExceptionHandler_NextState(_gefeh);\
            break;\
      }\
   } while (_gefstate != GEF_EXCEPT_DONE);\
   if (_isgefenabled) {\
      GEFExceptionHandler_EndCriticalSection(_gefeh);\
   }\
}
#endif
/*
  Effects: Introduces code which concludes an exception block.
 */

extern void* gef_malloc(size_t size);
extern void* gef_calloc(size_t nmemb, size_t size);
extern void gef_free(void** ptr);
extern void gef_realloc(void** ptr, size_t size);

#define GEFTRUE  1
#define GEFFALSE 0

#ifdef assert
#undef assert
#define assert(expr) gef_assert(expr)
#else
#define assert(expr) gef_assert(expr)
#endif

#endif /* GEF - General Exception Facility */
