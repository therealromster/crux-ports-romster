/*
  GEF: A General Exception-Handling Facility, which also support "Programming
  by Contract."

  Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place - Suite 330,
  Boston, MA  02111-1307, USA.
 */
#ifndef GEFATTR_H
#define GEFATTR_H

typedef struct {
   void (*Abort)(int);
   void (*AssertionViolation)(const char*, const char*, const char*, int);
   void (*PreconditionViolation)(const char*, const char*, const char*, int);
   void (*PostconditionViolation)(const char*, const char*, const char*, int);
   void (*PreInvariantViolation)(const char*, const char*, const char*, int);
   void (*PostInvariantViolation)(const char*, const char*, const char*, int);
   void (*UnhandledException)(void*);
   void (*Exit)(int);
#ifdef GEF_POSIX
   void* (*OSSignalToException)(int);
#endif
   void (*Error)(const char* format, ...);
   void (*OutOfMemory)(void);
   void (*UserCatch)(void* userData, void* exceptionID);
   void (*Delete)(void** exceptionID);
} GEFAttr_t;

extern
void
GEFAttr_Init(GEFAttr_t* attrs);

extern
void
GEFAttr_SetAbort(GEFAttr_t* attrs, void (*callBack)(int));

extern
void
GEFAttr_SetAssertionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int));


extern
void
GEFAttr_SetPreconditionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int));

extern
void
GEFAttr_SetPostconditionViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int));

extern
void
GEFAttr_SetPreInvariantViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int));

extern
void
GEFAttr_SetPostInvariantViolation(GEFAttr_t* attrs, void (*callBack)(const char*, const char*, const char*, int));

extern
void
GEFAttr_SetUnhandledException(GEFAttr_t* attrs, void (*callBack)(void*));

extern
void
GEFAttr_SetExit(GEFAttr_t* attrs, void (*callBack)(int));

extern
void
GEFAttr_SetOutOfMemory(GEFAttr_t* attrs, void (*callBack)(void));

extern
void
GEFAttr_SetOSSignalToException(GEFAttr_t* attrs, void* (*callBack)(int));

extern
void
GEFAttr_SetError(GEFAttr_t* attrs, void (*callBack)(const char* fmt, ...));

extern
void
GEFAttr_SetUserCatch(GEFAttr_t* attrs, void (*callBack)(void*, void*));

extern
void
GEFAttr_SetDelete(GEFAttr_t* attrs, void (*callBack)(void**));

#endif /* GEFATTR_H */
