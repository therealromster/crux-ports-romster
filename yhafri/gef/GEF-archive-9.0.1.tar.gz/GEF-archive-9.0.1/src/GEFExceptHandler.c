/*
    GEFExceptHandler.c:  Implements the exception context data type.

    Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the
    Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA  02111-1307, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#ifdef GEF_POSIX
#include <sys/types.h>
#include <unistd.h>
#endif

#include <gef/GEF.h>
#include <gef/GEFExceptHandler.h>

extern const char* GEFProgramName(void);

static int GEFInitialStackSize = 64;

static
void
Error(const char* format, ...) {
/*
    Description: This routine is the default error reporting routine.  It accepts a
    printf-compatible format string.
*/
    va_list args;
    va_start(args, format);
    fprintf(stderr, "\n[%s] ", __FILE__);
    vfprintf(stderr, format, args);
    va_end(args);
}

static
void
Exit(int code) {
    exit(code);
}

static
void
Abort(int exceptionID) {
/*
    Description: This routine is the default process or thread termination routine. 
    GEF uses this routine to terminate an errant program or thread.
*/
#ifdef GEF_POSIX
    kill(getpid(), SIGABRT);
#else
    exit(exceptionID);
#endif
}

static
void
AssertionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    GEFRaiseException((void*) GEF_EXCEPTION_ASSERTION_VIOLATION);
}

static
void
PreconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    GEFRaiseException((void*) GEF_EXCEPTION_PRECONDITION_VIOLATION);
}

static
void
PostconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    GEFRaiseException((void*) GEF_EXCEPTION_POSTCONDITION_VIOLATION);
}

static
void
PreInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    GEFRaiseException((void*) GEF_EXCEPTION_PREINVARIANT_VIOLATION);
}

static
void
PostInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    GEFRaiseException((void*) GEF_EXCEPTION_POSTINVARIANT_VIOLATION);
}

static
void
UnhandledException(void* exceptionID) {
#ifdef GEF_POSIX
    fprintf(stderr, "Unhandled exception occurred, while executing in process, %d.\n\007", (int) getpid());
#else
    fprintf(stderr, "Unhandled exception occurred!\n");
#endif
    GEFRaiseException((void*) GEF_EXCEPTION_UNHANDLED);
}

static
void
OutOfMemory(void) {
#ifdef GEF_POSIX
    fprintf(stderr, "GEF: Insufficient memory condition occurred, while in process %d!\n", (int) getpid());
#else
    fprintf(stderr, "GEF: Insufficient memory condition occurred!\n");
#endif
    GEFRaiseException((void*) GEF_EXCEPTION_NO_MEMORY);
}

static
void*
OSSignalToException(int signum) {
/*
    Description: Converts a user-defined signal into an operating system signal, if
    possible.  By default, the routine returns the same signal number that it receives.
*/
    return((void*) signum);
}

static
void
UserCatch(void* userData, void* exceptionID) {
}

static
void
GEFExceptionHandler_UnhandledException(GEFExceptionHandler_t eh, void* id) {
/*
    Description: Raises the unhandled-exception exception.
*/
    eh->UnhandledException(id);
#ifdef GEF_LINUX
    eh->Exit((int) id);
    Exit((int) id);
#else
    eh->Abort((int) id);
    Abort((int) id);
#endif
}

static
void
NoActiveCheckPoints(GEFExceptionHandler_t eh) {
    eh->Error("While executing in application/process, %s/%d, no active check points available.\n\007",
        eh->programName,
        eh->ProcessID());
    eh->Abort(GEF_EXCEPTION_FAILURE);
}

static
void
CheckUnhandledException(GEFExceptionHandler_t eh, void* id) {
    if (eh == NULL) GEFExceptionHandler_UnhandledException(eh, id);
    if (eh->sp == 0) {
        GEFExceptionHandler_EndCriticalSection(eh);
        GEFExceptionHandler_UnhandledException(eh, id);
    }
}

int
GEFExceptionHandler_IsEnabled(GEFExceptionHandler_t eh) {
    return(eh->enabled != 0);
}

int
GEFExceptionHandler_Enable(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    eh->enabled = 1;
    GEFExceptionHandler_EndCriticalSection(eh);
    return(eh->enabled);
}

int
GEFExceptionHandler_Disable(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    eh->enabled = 0;
    GEFExceptionHandler_BeginCriticalSection(eh);
    return(eh->enabled);
}

void
GEFExceptionHandler_SetDebug(GEFExceptionHandler_t eh, int value) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    eh->debug = (value ? 1 : 0);
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_SetAssertions(GEFExceptionHandler_t eh, int value) {
    /* This function is deprecated. However, keep for a while for backward compatibility. */
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (value) {
        GEFExceptionHandler_EnableInvariants(eh);
    } else GEFExceptionHandler_DisablePreconditions(eh);
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_EnablePreconditions(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel < GEF_ASSERT_LEVEL_PRE) {
        eh->assertLevel = GEF_ASSERT_LEVEL_PRE;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_EnablePostconditions(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel < GEF_ASSERT_LEVEL_POST) {
        eh->assertLevel = GEF_ASSERT_LEVEL_POST;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_EnableInvariants(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel < GEF_ASSERT_LEVEL_INVARIANTS) {
        eh->assertLevel = GEF_ASSERT_LEVEL_INVARIANTS;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_DisablePreconditions(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel > GEF_ASSERT_LEVEL_NONE) {
        eh->assertLevel = GEF_ASSERT_LEVEL_NONE;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_DisablePostconditions(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel > GEF_ASSERT_LEVEL_PRE) {
        eh->assertLevel = GEF_ASSERT_LEVEL_PRE;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_DisableInvariants(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->assertLevel > GEF_ASSERT_LEVEL_POST) {
        eh->assertLevel = GEF_ASSERT_LEVEL_POST;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

int
GEFExceptionHandler_GetAssertions(GEFExceptionHandler_t eh) {
    return(eh->assertLevel == GEF_ASSERT_LEVEL_INVARIANTS);
}

int
GEFExceptionHandler_IsPreconditionsEnabled(GEFExceptionHandler_t eh) {
    return(eh->assertLevel >= GEF_ASSERT_LEVEL_PRE);
}

int
GEFExceptionHandler_IsPostconditionsEnabled(GEFExceptionHandler_t eh) {
    return(eh->assertLevel >= GEF_ASSERT_LEVEL_POST);
}

int
GEFExceptionHandler_IsInvariantsEnabled(GEFExceptionHandler_t eh) {
    return(eh->assertLevel >= GEF_ASSERT_LEVEL_INVARIANTS);
}

#ifdef GEF_POSIX
void
GEFExceptionHandler_SetAsyncSupport(GEFExceptionHandler_t eh, int value) {
    eh->supportAsyncSignals = (value ? 1 : 0);
}
#endif

#ifdef GEF_POSIX
int
GEFExceptionHandler_GetAsyncSupport(GEFExceptionHandler_t eh) {
    return(eh->supportAsyncSignals);
}
#endif

void
GEFExceptionHandler_BeginCriticalSection(GEFExceptionHandler_t eh) {
#ifdef GEF_POSIX
    sigset_t mask;
    if (eh->supportAsyncSignals) {
        if (!eh->inCriticalSection) {
            if (eh->sp > 0) {
#ifdef GEF_PTHREADS
                if (pthread_sigmask(SIG_BLOCK, &eh->signalMask, NULL) < 0) {
                    eh->Error("GEFExceptionHandler_BeginCriticalSection--pthread_sigmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#else
                if (sigprocmask(SIG_BLOCK, &eh->signalMask, NULL) < 0) {
                    eh->Error("GEFExceptionHandler_BeginCriticalSection--sigprocmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#endif
            } else {
#ifdef GEF_PTHREADS
                if (pthread_sigmask(SIG_BLOCK, NULL, &mask) < 0) {
                    eh->Error("In GEFExceptionHandler_BeginCriticalSection--pthread_sigmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
                if (pthread_sigmask(SIG_BLOCK, &eh->signalMask, NULL) < 0) {
                    eh->Error("In GEFExceptionHandler_BeginCriticalSection--pthread_sigmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#else
                if (sigprocmask(SIG_BLOCK, NULL, &mask) < 0) {
                    eh->Error("In GEFExceptionHandler_BeginCriticalSection--sigprocmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
                if (sigprocmask(SIG_BLOCK, &eh->signalMask, NULL) < 0) {
                    eh->Error("In GEFExceptionHandler_BeginCriticalSection--sigprocmask(SIG_BLOCK, ...):  Failed!\n");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#endif
                eh->mask = mask;
            }
            eh->inCriticalSection = 1;
        }
    }
#endif
}

void
GEFExceptionHandler_EndCriticalSection(GEFExceptionHandler_t eh) {
    int sp;
    GEFCheckPoint_t* env;
#ifdef GEF_POSIX
    sigset_t* mask;
    if (eh->supportAsyncSignals) {
        if (eh->inCriticalSection) {
            if (eh->sp > 0) {
                sp = eh->sp - 1;
                env = &eh->stack[sp];
                switch(env->current) {
                case GEF_EXCEPT_TRY:
                case GEF_EXCEPT_DONE:
                    eh->inCriticalSection = 0;
#ifdef GEF_PTHREADS
                    if (pthread_sigmask(SIG_SETMASK, &env->mask, NULL) < 0) {
                        eh->Error("In GEFExceptionHandler_EndCriticalSection--pthread_sigmask(SIG_SETMASK, ...):  Failed!");
                        eh->Abort(GEF_EXCEPTION_FAILURE);
                        Abort(GEF_EXCEPTION_FAILURE);
                    }
#else
                    if (sigprocmask(SIG_SETMASK, &env->mask, NULL) < 0) {
                        eh->Error("In GEFExceptionHandler_EndCriticalSection--sigprocmask(SIG_SETMASK, ...):  Failed!");
                        eh->Abort(GEF_EXCEPTION_FAILURE);
                        Abort(GEF_EXCEPTION_FAILURE);
                    }
#endif
                    break;
                default: break;
                }
            } else {
#ifdef GEF_PTHREADS
                if (pthread_sigmask(SIG_SETMASK, &eh->mask, NULL) < 0) {
                    eh->Error("In GEFExceptionHandler_EndCriticalSection--pthread_sigmask(SIG_SETMASK, ...):  Failed!");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#else
                if (sigprocmask(SIG_SETMASK, &eh->mask, NULL) < 0) {
                    eh->Error("In GEFExceptionHandler_EndCriticalSection--sigprocmask(SIG_SETMASK, ...):  Failed!");
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                }
#endif
            }
        }
    }
#endif
}

void
GEFExceptionHandler_RaiseException(GEFExceptionHandler_t eh, void* id) {
    int sp;
    GEFCheckPoint_t* env;
    CheckUnhandledException(eh, id);
    GEFExceptionHandler_BeginCriticalSection(eh);
    sp = eh->sp - 1;
    env = &eh->stack[sp];
    eh->Delete(&env->exceptionID);
    env->exceptionID = id;
    switch(env->current) {
    case GEF_EXCEPT_TRY:
    case GEF_EXCEPT_FINALLY:
    case GEF_EXCEPT_POSTINVARIANTS:
    case GEF_EXCEPT_POSTCONDS:
        env->previous = env->current;
        env->current = GEF_EXCEPT_CATCH;
        longjmp(env->env, env->current);
        break;
    case GEF_EXCEPT_CATCH:
        env->previous = env->current;
        env->current = GEF_EXCEPT_CATCH;
        longjmp(env->env, env->current);
        break;
    default:
        env->previous = env->current;
        env->current = GEF_EXCEPT_FAILURE;
        longjmp(env->env, env->current);
        break;
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

static
int
ProcessID() {
#ifdef GEF_POSIX
    return((int) getpid());
#else
    return(0);
#endif
}

static
void
Delete(void** exceptionID) {
    *exceptionID = NULL;
}

static
void
Init(GEFExceptionHandler_t eh) {
    eh->programName = NULL;
    eh->enabled = 1;
    eh->debug = 0;
    eh->assertLevel = GEF_ASSERT_LEVEL_PRE;
    eh->jump = 0;
#ifdef GEF_POSIX
    eh->supportAsyncSignals = 0;
#endif
    eh->stack = NULL;
    eh->ssize = 0;
    eh->sp = 0;
#ifdef GEF_POSIX
    sigemptyset(&eh->signalMask);
    sigemptyset(&eh->mask);
    if (eh->supportAsyncSignals) {
#ifdef GEF_PTHREADS
        pthread_sigmask(SIG_BLOCK, NULL, &eh->mask);
#else
        sigprocmask(SIG_BLOCK, NULL, &eh->mask);
#endif
    }
    eh->inCriticalSection = 0;
#endif
    eh->Abort = Abort;
    eh->AssertionViolation = AssertionViolation;
    eh->PreconditionViolation = PreconditionViolation;
    eh->PostconditionViolation = PostconditionViolation;
    eh->PreInvariantViolation = PreInvariantViolation;
    eh->PostInvariantViolation = PostInvariantViolation;
    eh->UnhandledException = UnhandledException;
    eh->Error = Error;
    eh->Exit = Exit;
#ifdef GEF_POSIX
    eh->OSSignalToException = OSSignalToException;
#endif
    eh->OutOfMemory = OutOfMemory;
    eh->UserCatch = UserCatch;
    eh->ProcessID = ProcessID;
    eh->Delete = Delete;
    eh->states[GEF_EXCEPT_PREINVARIANTS].id = GEF_EXCEPT_PREINVARIANTS;
    eh->states[GEF_EXCEPT_PREINVARIANTS].name = "Pre-Invariants";
    eh->states[GEF_EXCEPT_POSTINVARIANTS].id = GEF_EXCEPT_POSTINVARIANTS;
    eh->states[GEF_EXCEPT_POSTINVARIANTS].name = "Post-Invariants";
    eh->states[GEF_EXCEPT_PRECONDS].id = GEF_EXCEPT_PRECONDS;
    eh->states[GEF_EXCEPT_PRECONDS].name = "Preconditions";
    eh->states[GEF_EXCEPT_TRY].id = GEF_EXCEPT_TRY;
    eh->states[GEF_EXCEPT_TRY].name = "Try";
    eh->states[GEF_EXCEPT_FINALLY].id = GEF_EXCEPT_FINALLY;
    eh->states[GEF_EXCEPT_FINALLY].name = "Finally";
    eh->states[GEF_EXCEPT_CATCH].id = GEF_EXCEPT_CATCH;
    eh->states[GEF_EXCEPT_CATCH].name = "Catch";
    eh->states[GEF_EXCEPT_POSTCONDS].id = GEF_EXCEPT_POSTCONDS;
    eh->states[GEF_EXCEPT_POSTCONDS].name = "Postconditions";
    eh->states[GEF_EXCEPT_SUCCESS].id = GEF_EXCEPT_SUCCESS;
    eh->states[GEF_EXCEPT_SUCCESS].name = "Success";
    eh->states[GEF_EXCEPT_DONE].id = GEF_EXCEPT_DONE;
    eh->states[GEF_EXCEPT_DONE].name = "End";
    eh->states[GEF_EXCEPT_FAILURE].id = GEF_EXCEPT_FAILURE;
    eh->states[GEF_EXCEPT_FAILURE].name = "Failure";
    eh->states[GEF_EXCEPT_INVALID].id = GEF_EXCEPT_INVALID;
    eh->states[GEF_EXCEPT_INVALID].name = "Invalid";
}

void
GEFExceptionHandler_GrowStack(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
    if (eh->stack == (GEFCheckPoint_t*) NULL) {
        eh->stack = (GEFCheckPoint_t*) malloc(sizeof(GEFCheckPoint_t) * GEFInitialStackSize);
        if (eh->stack == (GEFCheckPoint_t*) NULL) {
            eh->Error("GEF: While executing in application/process, %s/%d, could not initialize exception handler--aborting!\n", eh->programName, eh->ProcessID());
            eh->Abort(GEF_EXCEPTION_NO_MEMORY);
            Abort(GEF_EXCEPTION_NO_MEMORY);
        } else {
            eh->ssize = GEFInitialStackSize;
            eh->sp = 0;
        }
    } else {
        size_t newsize = eh->ssize * 2;
        size_t numOfBytes = sizeof(GEFCheckPoint_t) * newsize;
        GEFCheckPoint_t* newstack = (GEFCheckPoint_t*) realloc(eh->stack, numOfBytes);
        if (newstack != (GEFCheckPoint_t*) NULL) {
            eh->stack = newstack;
            eh->ssize = newsize;
        } else {
            eh->OutOfMemory();
            OutOfMemory();
        }
    }
    GEFExceptionHandler_EndCriticalSection(eh);
}

static
void
InitInit(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_INIT;
    GEFStateID_t previous = GEF_EXCEPT_INVALID;
    GEFStateID_t next;
    GEFAssertLevel_t level;

    level = GEF_ASSERT_LEVEL_NONE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_PRE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_PRECONDS];
    level = GEF_ASSERT_LEVEL_POST;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_PRECONDS];
    level = GEF_ASSERT_LEVEL_INVARIANTS;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_PRECONDS];
}

static
void
InitPreconditions(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_PRECONDS;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    int i;
    int j;
    static GEFStateID_t next_state[] = {
        GEF_EXCEPT_TRY, /* Level: None */
        GEF_EXCEPT_TRY, /* Level: Preconditions */
        GEF_EXCEPT_TRY, /* Level: Postconditions */
        GEF_EXCEPT_PREINVARIANTS  /* Level: Invariants */
    };
    size_t next_state_quantity = sizeof(next_state) / sizeof(next_state[0]);

    previous = GEF_EXCEPT_INIT;
    for (j = 0; j < next_state_quantity && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state[j]];
    }
}

static
void
InitPostconditions(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_POSTCONDS;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    int i;
    int j;
    static GEFStateID_t next_state[] = {
        GEF_EXCEPT_SUCCESS, /* Level: None */
        GEF_EXCEPT_SUCCESS, /* Level: Preconditions */
        GEF_EXCEPT_SUCCESS, /* Level: Postconditions */
        GEF_EXCEPT_SUCCESS  /* Level: Invariants */
    };
    size_t next_state_quantity = sizeof(next_state) / sizeof(next_state[0]);
    static GEFStateID_t next_state2[] = {
        GEF_EXCEPT_SUCCESS, /* Level: None */
        GEF_EXCEPT_SUCCESS, /* Level: Preconditions */
        GEF_EXCEPT_SUCCESS, /* Level: Postconditions */
        GEF_EXCEPT_SUCCESS  /* Level: Invariants */
    };
    size_t next_state_quantity2 = sizeof(next_state2) / sizeof(next_state2[0]);

    previous = GEF_EXCEPT_POSTINVARIANTS;
    for (j = 0; j < next_state_quantity && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state[j]];
    }

    previous = GEF_EXCEPT_FINALLY;
    for (j = 0; j < next_state_quantity2 && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state2[j]];
    }
}

static
void
InitPreInvariants(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_PREINVARIANTS;
    GEFStateID_t previous = GEF_EXCEPT_INIT;
    GEFAssertLevel_t level;

    level = GEF_ASSERT_LEVEL_NONE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_PRE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_POST;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_INVARIANTS;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];

    previous = GEF_EXCEPT_PRECONDS;

    level = GEF_ASSERT_LEVEL_NONE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_PRE;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_POST;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
    level = GEF_ASSERT_LEVEL_INVARIANTS;
    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_TRY];
}

static
void
InitTry(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_TRY;
    GEFStateID_t next = GEF_EXCEPT_FINALLY;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    static GEFStateID_t previous_state[] = {
        GEF_EXCEPT_INIT,
        GEF_EXCEPT_PREINVARIANTS,
        GEF_EXCEPT_PRECONDS,
        GEF_EXCEPT_CATCH,
        GEF_EXCEPT_TRY
    };
    size_t previous_state_quantity = sizeof(previous_state) / sizeof(previous_state[0]);
    int i;

    for (i = 0; i < previous_state_quantity; i++) {
        previous = previous_state[i];
        for (level = 0; level < GEF_ASSERT_LEVEL_TOTAL; level++) {
            eh->stateTransitions[current][previous][level] = eh->states[next];
        }
    }
}

static
void
InitFinally(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_FINALLY;
    GEFStateID_t next;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    int i;
    static GEFStateID_t next_state[] = {
        GEF_EXCEPT_SUCCESS, /* Level: None */
        GEF_EXCEPT_SUCCESS, /* Level: Preconditions */
        GEF_EXCEPT_POSTCONDS, /* Level: Postconditions */
        GEF_EXCEPT_POSTINVARIANTS /* Level: Invariants */
    };
    size_t next_state_quantity = sizeof(next_state) / sizeof(next_state[0]);
    int j;
    static GEFStateID_t next_state2[] = {
        GEF_EXCEPT_FAILURE,
        GEF_EXCEPT_FAILURE,
        GEF_EXCEPT_FAILURE,
        GEF_EXCEPT_FAILURE
    };
    size_t next_state2_quantity = sizeof(next_state2) / sizeof(next_state2[0]);

    previous = GEF_EXCEPT_TRY;
    for (j = 0; j < next_state_quantity && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state[j]];
    }

    previous = GEF_EXCEPT_CATCH;
    for (j = 0; j < next_state2_quantity && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state2[level]];
    }
}

static
void
InitPostInvariants(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_POSTINVARIANTS;
    GEFStateID_t next;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    static GEFStateID_t next_state[] = {
        GEF_EXCEPT_SUCCESS, /* Level: None */
        GEF_EXCEPT_SUCCESS, /* Level: Preconditions */
        GEF_EXCEPT_SUCCESS, /* Level: Postconditions */
        GEF_EXCEPT_POSTCONDS /* Level: Invariants */
    };
    size_t next_state_quantity = sizeof(next_state) / sizeof(next_state[0]);
    int j;

    previous = GEF_EXCEPT_FINALLY;
    for (j = 0; j < next_state_quantity && j < GEF_ASSERT_LEVEL_TOTAL; j++) {
        level = j;
        eh->stateTransitions[current][previous][level] = eh->states[next_state[j]];
    }
}

static
void
InitCatch(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_CATCH;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    static GEFStateID_t previous_state[] = {
        GEF_EXCEPT_TRY,
        GEF_EXCEPT_CATCH
    };
    GEFStateID_t next = GEF_EXCEPT_FINALLY;
    size_t previous_state_quantity = sizeof(previous_state) / sizeof(previous_state[0]);
    static GEFStateID_t previous_state2[] = {
        GEF_EXCEPT_FINALLY,
        GEF_EXCEPT_POSTINVARIANTS,
        GEF_EXCEPT_POSTCONDS
    };
    GEFStateID_t next2 = GEF_EXCEPT_FAILURE;
    size_t previous_state_quantity2 = sizeof(previous_state2) / sizeof(previous_state2[0]);
    int i;
    int j;
    for (i = 0; i < previous_state_quantity; i++) {
        previous = previous_state[i];
        for (level = 0; level < GEF_ASSERT_LEVEL_TOTAL; level++) {
            eh->stateTransitions[current][previous][level] = eh->states[next];
        }
    }

    for (i = 0; i < previous_state_quantity2; i++) {
        previous = previous_state2[i];
        for (level = 0; level < GEF_ASSERT_LEVEL_TOTAL; level++) {
            eh->stateTransitions[current][previous][level] = eh->states[next2];
        }
    }   
}

static
void
InitSuccess(GEFExceptionHandler_t eh) {
    GEFStateID_t current = GEF_EXCEPT_SUCCESS;
    GEFStateID_t next = GEF_EXCEPT_DONE;
    GEFStateID_t previous;
    GEFAssertLevel_t level;
    static GEFStateID_t previous_state[] = {
        GEF_EXCEPT_FINALLY,
        GEF_EXCEPT_POSTINVARIANTS,
        GEF_EXCEPT_POSTCONDS
    };
    size_t previous_state_quantity = sizeof(previous_state) / sizeof(previous_state[0]);
    int i;

    for (i = 0; i < previous_state_quantity; i++) {
        previous = previous_state[i];
        for (level = 0; level < GEF_ASSERT_LEVEL_TOTAL; level++) {
            eh->stateTransitions[current][previous][level] = eh->states[next];
        }
    }
}

#ifdef GEF_POSIX
void
GEFExceptionHandler_SetSignals(GEFExceptionHandler_t eh, sigset_t signalSet) {
    eh->signalMask = signalSet;
}
#endif

GEFExceptionHandler_t
GEFExceptionHandler_New(GEFAttr_t attrs) {
    int current;
    int previous;
    GEFAssertLevel_t level;
    GEFExceptionHandler_t eh = NULL;
    if ((eh = malloc(sizeof(*eh))) != NULL) {
        Init(eh);
        eh->programName = GEFProgramName();
        if (attrs.Abort != NULL) eh->Abort = attrs.Abort;
        if (attrs.AssertionViolation != NULL) eh->AssertionViolation = attrs.AssertionViolation;
        if (attrs.PreconditionViolation != NULL) eh->PreconditionViolation = attrs.PreconditionViolation;
        if (attrs.PostconditionViolation != NULL) eh->PostconditionViolation = attrs.PostconditionViolation;
        if (attrs.PreInvariantViolation != NULL) eh->PreInvariantViolation = attrs.PreInvariantViolation;
        if (attrs.PostInvariantViolation != NULL) eh->PostInvariantViolation = attrs.PostInvariantViolation;
        if (attrs.UnhandledException != NULL) eh->UnhandledException = attrs.UnhandledException;
        if (attrs.Exit != NULL) eh->Exit = attrs.Exit;
#ifdef GEF_POSIX
        if (attrs.OSSignalToException != NULL) eh->OSSignalToException = attrs.OSSignalToException;
#endif
        if (attrs.Error != NULL) eh->Error = attrs.Error;
        if (attrs.OutOfMemory != NULL) eh->OutOfMemory = attrs.OutOfMemory;
        if (attrs.UserCatch != NULL) eh->UserCatch = attrs.UserCatch;
        if (attrs.Delete != NULL) eh->Delete = attrs.Delete;
        for (current = 0; current < GEF_EXCEPT_NUMBER; current++) {
            for (previous = 0; previous < GEF_EXCEPT_NUMBER; previous ++){
                for (level = 0; level < GEF_ASSERT_LEVEL_TOTAL; level++){
                    eh->stateTransitions[current][previous][level] = eh->states[GEF_EXCEPT_INVALID];
                }
            }
        }
        InitInit(eh);
        InitPreInvariants(eh);
        InitPostInvariants(eh);
        InitPreconditions(eh);
        InitTry(eh);
        InitCatch(eh);
        InitPostconditions(eh);
        InitFinally(eh);
        InitSuccess(eh);
        GEFExceptionHandler_GrowStack(eh);
    }
    return(eh);
}

void
GEFExceptionHandler_Delete(GEFExceptionHandler_t* eh) {
    int debug = (*eh)->debug;
    if (debug) fprintf(stderr, "GEFExceptionHandler_Delete: Deleting stack!\n");
    free((void*) (*eh)->stack);
    if (debug) fprintf(stderr, "GEFExceptionHandler_Delete: Deleting eh!\n");
   free((void*) *eh);
   *eh = NULL;
}

int
GEFExceptionHandler_StackDepth(GEFExceptionHandler_t eh) {
    return(eh->sp);
}

#define CheckNoActiveCheckPoints(eh)\
if (eh->sp == 0) NoActiveCheckPoints(eh)

#define CheckOverflow(eh) \
if (eh->sp == eh->ssize) GEFExceptionHandler_GrowStack(eh)

static
void
InvalidTransition(GEFExceptionHandler_t eh, int current, int previous, int next) {
/*
    Description: This function reports an invalid state transition that the GEF
    facility makes, and aborts the currently running thread.
*/
    char* currentName = eh->states[current].name;
    char* previousName = eh->states[previous].name;
    char* nextName = eh->states[next].name;
    eh->Error("While executing in application/process, %s/%d, encountered invalid exception state...",
        eh->programName,
        eh->ProcessID());
    eh->Error("current = %s, previous = %s, next = %s.\n", currentName, previousName, nextName);
    eh->Abort(GEF_EXCEPTION_FAILURE);
    Abort(GEF_EXCEPTION_FAILURE);
}

GEFStateID_t
GEFExceptionHandler_NextState(GEFExceptionHandler_t eh) {
    GEFStateID_t previous;
    GEFStateID_t current;
    GEFStateID_t next;
    int sp;
    int numberOfAttempts;
    GEFAssertLevel_t assertLevel;
    GEFCheckPoint_t* env;
    GEFExceptionHandler_BeginCriticalSection(eh);
    CheckNoActiveCheckPoints(eh);
    sp = eh->sp - 1;
    env = &eh->stack[sp];
    current = env->current;
    previous = env->previous;
    assertLevel = eh->assertLevel;
    next = eh->stateTransitions[current][previous][assertLevel].id;
    if (next == GEF_EXCEPT_FINALLY && !env->isFinallyEnabled) {
        previous = env->previous = current;
        current = env->current = next;
        next = eh->stateTransitions[current][previous][assertLevel].id;
    }
#if GEF_DEBUG
    if (eh->debug) {
        fprintf(stderr, "Current = %s\n", eh->states[current].name);
        fprintf(stderr, "Previous = %s\n", eh->states[previous].name);
        fprintf(stderr, "Next = %s\n", eh->states[next].name);
    }
#endif
    switch(current) {
    case GEF_EXCEPT_CATCH:
        numberOfAttempts = env->numberOfAttempts;
        if (numberOfAttempts > 1) {
            eh->Delete(&env->exceptionID);
            env->numberOfAttempts--;
            env->previous = current;
            env->current = GEF_EXCEPT_TRY;
            return(GEF_EXCEPT_TRY);
        }
        env->previous = current;
        env->current = next;
        break;
    case GEF_EXCEPT_SUCCESS:
        eh->assertLevel = env->previousAssertLevel;
        eh->sp--;
        break;
    /* Optimization */
    case GEF_EXCEPT_FINALLY:
    case GEF_EXCEPT_POSTINVARIANTS:
    case GEF_EXCEPT_POSTCONDS:
        if (next == GEF_EXCEPT_SUCCESS) {
            eh->assertLevel = env->previousAssertLevel;
            eh->sp--;
            next = GEF_EXCEPT_DONE;
        } else {
            env->previous = current;
            env->current = next;
        }
        break;
    case GEF_EXCEPT_FAILURE:
        eh->assertLevel = env->previousAssertLevel;
        eh->sp--;
        GEFExceptionHandler_RaiseException(eh, eh->stack[eh->sp].exceptionID);
        break;
    case GEF_EXCEPT_INVALID:
        InvalidTransition(eh, current, previous, next);
        break;
    default:
        env->previous = current;
        env->current = next;
        break;
    }
    if (eh->jump) {
        eh->jump = 0;
        longjmp(env->env, next);
    }
    return(next);
}

void
GEFExceptionHandler_Break(GEFExceptionHandler_t eh) {
    int sp;
    GEFCheckPoint_t* env;
    int inCriticalSection = eh->inCriticalSection;
    GEFExceptionHandler_BeginCriticalSection(eh);
    CheckNoActiveCheckPoints(eh);
    sp = eh->sp - 1;
    env = &eh->stack[sp];
    switch(env->current) {
    case GEF_EXCEPT_CATCH:
        eh->Delete(&env->exceptionID);
        env->previous = env->current;
        env->current = GEF_EXCEPT_TRY;
        eh->jump = 1;
        GEFExceptionHandler_NextState(eh);
        break;
    case GEF_EXCEPT_TRY:
        eh->Delete(&env->exceptionID);
        env->previous = env->current;
        eh->jump = 1;
        GEFExceptionHandler_NextState(eh);
    default: break;
    }
    if (!inCriticalSection) GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFExceptionHandler_Retry(GEFExceptionHandler_t eh) {
    int sp;
    int numberOfAttempts;
    GEFCheckPoint_t* env;
    int inCriticalSection = eh->inCriticalSection;
    GEFExceptionHandler_BeginCriticalSection(eh);
    CheckNoActiveCheckPoints(eh);
    sp = eh->sp - 1;
    env = &eh->stack[sp];
    if (env->current == GEF_EXCEPT_CATCH) {
        eh->Delete(&env->exceptionID);
        numberOfAttempts = env->numberOfAttempts;
        if (numberOfAttempts > 1) {
            env->numberOfAttempts--;
            env->previous = env->current;
            env->current = GEF_EXCEPT_TRY;
            longjmp(env->env, GEF_EXCEPT_TRY);
        } else if (numberOfAttempts == 0) {
            env->previous = env->current;
            env->current = GEF_EXCEPT_TRY;
            longjmp(env->env, GEF_EXCEPT_TRY);
        } else {
            ; /* Ignore request; satisfied number of attempts */
        }
    }
    if (!inCriticalSection) GEFExceptionHandler_EndCriticalSection(eh);
}

GEFCheckPoint_t*
GEFExceptionHandler_CheckPoint(GEFExceptionHandler_t eh, int max, int isFinallyEnabled) {
    GEFCheckPoint_t* env;
#ifdef GEF_POSIX
    sigset_t oldmask;
#endif
    max = (max < 0 ? 0 : max);
    CheckOverflow(eh);
    env = &eh->stack[eh->sp];
#ifdef GEF_POSIX
    if (eh->supportAsyncSignals) {
#ifdef GEF_PTHREADS
        if (pthread_sigmask(SIG_BLOCK, NULL, &oldmask) < 0) {
            eh->Error("GEFExceptionHandler_CheckPoint--sigmask(SIG_BLOCK, ...):  Failed!\n");
            eh->Abort(GEF_EXCEPTION_FAILURE);
            Abort(GEF_EXCEPTION_FAILURE);
        }
#else
        if (sigprocmask(SIG_BLOCK, NULL, &oldmask) < 0) {
            eh->Error("GEFExceptionHandler_CheckPoint--sigmask(SIG_BLOCK, ...):  Failed!\n");
            eh->Abort(GEF_EXCEPTION_FAILURE);
            Abort(GEF_EXCEPTION_FAILURE);
        }
#endif
        GEFExceptionHandler_BeginCriticalSection(eh);
        env->mask = oldmask;
    }
#endif
    env->previousAssertLevel = eh->assertLevel;
    env->current = GEF_EXCEPT_INIT;
    env->previous = GEF_EXCEPT_INVALID;
    env->numberOfAttempts = max;
    env->isFinallyEnabled = isFinallyEnabled;
    env->exceptionID = NULL;
    eh->sp++;
    return(env);
}

void*
GEFExceptionHandler_GetException(GEFExceptionHandler_t eh) {
    CheckNoActiveCheckPoints(eh);
    return(eh->stack[eh->sp - 1].exceptionID);
}

extern
void
GEFExceptionHandler_InsufficientMemory(GEFExceptionHandler_t eh) {
    eh->OutOfMemory();
}


#ifdef GEF_POSIX
static
int
sigsetisempty(sigset_t* set) {
    int signo;
    for (signo = 1; signo < NSIG; signo++) {
        if (sigismember(set, signo)) {
            return(0);
        }
    }
    return(1);
}
#endif
