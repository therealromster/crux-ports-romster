/*
    GEF.c: The General Exception-Handling Facility Interface.

    Copyright (C) 1998-2006  Bruce Warren Bigby <bbigby@alum.MIT.edu>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the
    Free Software Foundation, Inc., 59 Temple Place - Suite 330,
    Boston, MA  02111-1307, USA.

    MODULE
        General Exception-Handling Facility (GEF)

    DESCRIPTION
        The General Exception-Handling Facility is a C library that enables a programmer
        to generate program exceptions and to receive and handle operating
        system exceptions, or signals in the case of UNIX, in a synchronous and
        safe manner. This implementation supports primarily UNIX-like operating
        systems, although the code, without the signal-handling support, is
        portable to any platform which supports the C programming language.

   CAVEATS
        (1) This implementation of GEF uses PosixThreads so you must link using
        your platform's pthread library. Typically, this means adding a
        <-lpthread> option to your link line.

        (2) PosixThreads has not declared the function, <pthread_getspecific>,
        to be async safe. However, this implementation of GEF requires that
        <pthread_gefspecific> be async-safe.  This is because GEF uses the
        function to determine the exception handler to which to transfer control
        in a multithreaded program. Consequently, to use the asynchronous signal
        support, you must ensure that, for your platform, or operating system,
        the implementation of pthread_getspecific is async-safe.  Fortunately,
        for several major, or popular, vendors of operating sytems that support
        pthreads, the function, pthread_getspecific, is async-safe. One
        qualifying operating system is Linux 2.x. Solaris 2.5.1 also appears to
        have an async-safe pthread_getspecific, although the Solaris
        documentation does not declare the function to be async-safe. You need
        to verify whether pthread_getspecific is async-safe for your operating
        system to be comfortable using it. However, if your program does not use
        GEF to handle asynchronous signals, then you have no cause for concern.

        (3) Programmers must always remember not to use the "return" statement
        from within the scope of an exception block. Doing so would cause the
        GEF checkpoint stack to get out of sync with the regular program stack.
        Consequently, always get in the habit of returning at the end of a
        function.  This constraint encourages good programming practice anyway.

        (4) Likewise, never use the C language "break" command, if doing so
        causes a thread to exit from within the scope of an active exception
        block.

    AUTHOR
        Bruce W. Bigby
        bbigby@alum.MIT.edu

    REFERENCES
        (1) Advanced Programming in the UNIX Environment, by Stevens.
        (2) A Guide to Multithreaded Programming: Threads Primer, by Bil Lewis
            and Daniel J. Berg.
        (3) OSF DCE: Guide to Developing Distributed Applications, by Harold W.
            Lockhart, Jr.
        (4) C++ Reference
        (5) Core Java by Sunsoft
        (6) See references on Eiffel exception-handling.

    COPYRIGHT (C) 1998 Bruce W. Bigby
*/

#include <stdio.h>
#include <stdlib.h>
#ifdef GEF_POSIX
#include <sys/types.h>
#include <unistd.h>
#endif

#include <gef/GEF.h>

#ifdef GEF_PTHREADS
#include <pthread.h>
#endif

#include <string.h>
#include <strings.h>

/* This data structure stores all of the thread synchronization
 * objects--the key that we use to access the thread-specific
 * exception-handler; the mutex that we must use for signal handler
 * initialization; and the list of signal handlers for each signal
 * that we override so that we may restore the appropriate signal
 * handlers when the last thread exits.
 */

typedef struct {
    const char* programName;
    int enabled;
    int debug;
    int assert_level;
    int abort_on_assertion_violation;
#ifdef GEF_PTHREADS
    pthread_key_t exceptionHandlerKey;
#endif
    int signalConfigurationDone;
#ifdef GEF_PTHREADS
    pthread_mutex_t signalInitLock;
    unsigned int numberOfThreads;
#endif
#ifdef GEF_POSIX
    sigset_t signalSet;
    void (*signalHandlers[NSIG])(int signo);
    void (*RaiseOSSignal)(int signum);
#endif
} GEF_t;

static GEF_t GEF = { NULL };
#ifndef GEF_PTHREADS
static GEFExceptionHandler_t eh = NULL;
#endif

static void ProcessOptions(int* argc, char*** argv);
static void ProcessAssertLevel(void);
static void Usage(void);

static
void
Error(const char* format, ...) {
    va_list args;
    va_start(args, format);
    fprintf(stderr, "\n[General Exception Facility]\n");
    fprintf(stderr, "   ");
    vfprintf(stderr, format, args);
    fprintf(stderr, "\n");
    va_end(args);
}

static
void
Abort(int exceptionID) {
#ifdef GEF_POSIX
    abort();
#else
    exit(exceptionID);
#endif
}

static
void
Exit(int code) {
#ifdef GEF_PTHREADS
    pthread_exit((void*) code);
#else
    exit(code);
#endif
}

static
void
OutOfMemory(void) {
    gef_throw((void*) GEF_EXCEPTION_NO_MEMORY);
}

static
void
Delete(void** exceptionID) {
    *exceptionID = NULL;
}

static
void
DisplayAssertionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    fprintf(stderr, "Assertion Violation!\n\tAssertion: %s\n\tFilename: %s\n\tFunction: %s\n\tLine number: %d\n",
        expString, fileName, function, lineNumber);
}

static
void
AssertionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    DisplayAssertionViolation(expString, fileName, function, lineNumber);
    gef_throw((void*) GEF_EXCEPTION_ASSERTION_VIOLATION);
}

static
void
DisplayPreconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    fprintf(stderr, "Precondition Violation!\n\tAssertion: %s\n\tFilename: %s\n\tFunction: %s\n\tLine number: %d\n",
        expString, fileName, function, lineNumber);
}

static
void
PreconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    DisplayPreconditionViolation(expString, fileName, function, lineNumber);
    gef_throw((void*) GEF_EXCEPTION_PRECONDITION_VIOLATION);
}

static
void
DisplayPostconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    fprintf(stderr, "Postcondition Violation!\n\tAssertion: %s\n\tFilename: %s\n\tFunction: %s\n\tLine number: %d\n",
        expString, fileName, function, lineNumber);
}

static
void
PostconditionViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    DisplayPostconditionViolation(expString, fileName, function, lineNumber);
    gef_throw((void*) GEF_EXCEPTION_POSTCONDITION_VIOLATION);
}

static
void
DisplayPreInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    fprintf(stderr, "Pre-Invariant Violation!\n\tAssertion: %s\n\tFilename: %s\n\tFunction: %s\n\tLine number: %d\n",
        expString, fileName, function, lineNumber);
}

static
void
PreInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    DisplayPreInvariantViolation(expString, fileName, function, lineNumber);
    gef_throw((void*) GEF_EXCEPTION_PREINVARIANT_VIOLATION);
}

static
void
DisplayPostInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    fprintf(stderr, "Post-Invariant Violation!\n\tAssertion: %s\n\tFilename: %s\n\tFunction: %s\n\tLine number: %d\n",
        expString, fileName, function, lineNumber);
}

static
void
PostInvariantViolation(const char* expString, const char* fileName, const char* function, int lineNumber) {
    DisplayPostInvariantViolation(expString, fileName, function, lineNumber);
    gef_throw((void*) GEF_EXCEPTION_POSTINVARIANT_VIOLATION);
}

static
void
UnhandledException(void* exceptionID) {
    fprintf(stderr, "\nGEF caught unhandled exception!\n");
}

#ifdef GEF_POSIX
static
void
signotset(sigset_t* oldset, sigset_t* newset) {
    int sig;

    for (sig = 1; sig < NSIG; sig++) {
        if (!sigismember(oldset, sig)) {
            sigaddset(newset, sig);
        }
    }
}
#endif

void
GEFSetDebug(int value) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_SetDebug(eh, value);
}

void
GEFEnable(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_Enable(eh);
}

int
GEFIsEnabled(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    return(GEFExceptionHandler_IsEnabled(eh));
}

void
GEFDisable(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_Disable(eh);
}

void
GEFSetAssertions(int value) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_SetAssertions(eh, value);
}

void
GEFEnablePreconditions(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_EnablePreconditions(eh);
}


void
GEFEnablePostconditions(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_EnablePostconditions(eh);
}

void
GEFEnableInvariants(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_EnableInvariants(eh);
}

void
GEFDisablePreconditions(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_DisablePreconditions(eh);
}


void
GEFDisablePostconditions(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_DisablePostconditions(eh);
}

void
GEFDisableInvariants(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_DisableInvariants(eh);
}

#ifdef GEF_POSIX
void
GEFSetAsyncSupport(int value) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    GEFExceptionHandler_SetAsyncSupport(eh, value);
}
#endif

#ifdef GEF_POSIX
int
GEFGetAsyncSupport(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    return(GEFExceptionHandler_GetAsyncSupport(eh));
}
#endif

int
GEFGetAssertions(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    return(GEFExceptionHandler_GetAssertions(eh));
}

void
GEFExecuteUserCatch(void* userData, void* exceptionID) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    eh->UserCatch(userData, exceptionID);
}

void
GEFBeginCriticalSection(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_BeginCriticalSection(eh);
}

void
GEFEndCriticalSection(GEFExceptionHandler_t eh) {
    GEFExceptionHandler_EndCriticalSection(eh);
}

void
GEFAssert(int expressionValue, const char* expString, const char* fileName, const char* function, int lineNumber) {
    if (!expressionValue) {
        GEFStateID_t current;
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        if (eh != NULL && GEFExceptionHandler_IsPreconditionsEnabled(eh)) {
            if (GEF.abort_on_assertion_violation) {
                DisplayAssertionViolation(expString, fileName, function, lineNumber);
                eh->Abort(GEF_EXCEPTION_FAILURE);
                Abort(GEF_EXCEPTION_FAILURE);
            } else {
                eh->AssertionViolation(expString, fileName, function, lineNumber);
                AssertionViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
            }
        }
    }
}

void
GEFAlwaysAssert(int expressionValue, const char* expString, const char* fileName, const char* function, int lineNumber) {
    if (!expressionValue) {
        GEFStateID_t current;
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        if (eh != NULL && !GEF.abort_on_assertion_violation) {
            eh->AssertionViolation(expString, fileName, function, lineNumber);
            AssertionViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
        } else {
            DisplayAssertionViolation(expString, fileName, function, lineNumber);
            eh->Abort(GEF_EXCEPTION_FAILURE);
            Abort(GEF_EXCEPTION_FAILURE);
        }
    }
}

void
GEFAssertPrecondition(int expressionValue, const char* expString, const char* fileName, const char* function, int lineNumber) {
    if (!expressionValue) {
        GEFStateID_t current;
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        if (eh != NULL && GEFExceptionHandler_IsPreconditionsEnabled(eh)) {
            if (GEF.abort_on_assertion_violation) {
                DisplayPreconditionViolation(expString, fileName, function, lineNumber);
                eh->Abort(GEF_EXCEPTION_FAILURE);
                Abort(GEF_EXCEPTION_FAILURE);
            } else {
                eh->PreconditionViolation(expString, fileName, function, lineNumber);
                PreconditionViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
            }
        }
    }
}

void
GEFAssertPostcondition(int expressionValue, const char* expString, const char* fileName, const char* function, int lineNumber) {
    if (!expressionValue) {
        GEFStateID_t current;
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        if (eh != NULL && GEFExceptionHandler_IsPostconditionsEnabled(eh)) {
            if (GEF.abort_on_assertion_violation) {
                DisplayPostconditionViolation(expString, fileName, function, lineNumber);
                eh->Abort(GEF_EXCEPTION_FAILURE);
                Abort(GEF_EXCEPTION_FAILURE);
            } else {
                eh->PostconditionViolation(expString, fileName, function, lineNumber);
                PostconditionViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
            }
        }
    }
}

void
GEFAssertInvariant(int expressionValue, const char* expString, const char* fileName, const char* function, int lineNumber, int _gefstate) {
    if (!expressionValue) {
        GEFStateID_t current;
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        if (eh != NULL && GEFExceptionHandler_IsInvariantsEnabled(eh)) {
            switch(_gefstate) {
            case GEF_EXCEPT_PREINVARIANTS:
                if (GEF.abort_on_assertion_violation) {
                    DisplayPreInvariantViolation(expString, fileName, function, lineNumber);
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                } else {
                    eh->PreInvariantViolation(expString, fileName, function, lineNumber);
                    PreInvariantViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
                }
                break;
            case GEF_EXCEPT_POSTINVARIANTS:
                if (GEF.abort_on_assertion_violation) {
                    DisplayPostInvariantViolation(expString, fileName, function, lineNumber);
                    eh->Abort(GEF_EXCEPTION_FAILURE);
                    Abort(GEF_EXCEPTION_FAILURE);
                } else {
                    eh->PostInvariantViolation(expString, fileName, function, lineNumber);
                    PostInvariantViolation(expString, fileName, function, lineNumber); /* Call default directly in case call-back does not throw exception */
                }
                break;
            default:
                eh->Error("GEFAssertInvariant: Internal error! Unexpected _gefstate!\n");
                eh->Abort(GEF_EXCEPTION_FAILURE);
                Abort(GEF_EXCEPTION_FAILURE);
                break;
            }
        }
    }
}

void
GEFRaiseException(void* id) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    if (eh != NULL) {
        GEFExceptionHandler_RaiseException(eh, id);
    }

    /* Most likely received a signal before we could initialize the handler */
    /* Just ignore signal, and return. */
}

#ifdef GEF_POSIX
static
void
GEFRaiseOSSignal(int signo) {
    void* exceptionID = NULL;
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    exceptionID = eh->OSSignalToException(signo);
    GEFRaiseException(exceptionID);
}
#endif

#ifdef GEF_POSIX
void
GEFCatchSignal(int signum) {
    GEF.RaiseOSSignal(signum);
}
#endif

#ifdef GEF_POSIX
GEFSignalHandler_t
GEFSignal(int signum, GEFSignalHandler_t handler) {
    struct sigaction act, oact;

    bzero(&act, sizeof(act));
    bzero(&oact, sizeof(oact));
    act.sa_handler = handler;
    act.sa_flags = 0;

    switch(signum) {
    case SIGFPE:
    case SIGBUS:
    case SIGSEGV:
    /* Note: This is unnecessary, since these signals will not occur */
    /* again while the GEF signal-handler is running, because it doesn't */
    /* do anything that would cause the OS to generate these signals */
    /* while the signal-handler is running. */
#ifdef SA_NODEFER
        act.sa_flags |= SA_NODEFER;
#endif
        break;
    default:
        act.sa_mask = GEF.signalSet;
        break;
    }
    if (signum == SIGALRM) {
#ifdef SA_INTERRUPT
        act.sa_flags |= SA_INTERRUPT;    /* SunOS */
#endif
    } else {
#ifdef SA_RESTART
        act.sa_flags |= SA_RESTART;    /* SVR4, 4.3+BSD */
#endif
    }
    if (sigaction(signum, &act, &oact) < 0) {
        return(SIG_ERR);
    }
    return(oact.sa_handler);
}
#endif

#ifdef GEF_POSIX
static
GEFSignalHandler_t
GEFAcceptSignal(int signum) {
    GEFSignalHandler_t answer = SIG_DFL;
    answer = GEFSignal(signum, GEFCatchSignal);
    if (signum == SIGABRT) {
        GEFSignal(signum, answer);
    }
    return(answer);
}
#endif

#ifdef GEF_POSIX
static
void
GEFInitializeSignalHandler(void) {
    int signum;
    int numberOfSignals = NSIG;
#ifdef GEF_PTHREADS
    /* Should check return code of lock */
    pthread_mutex_lock(&GEF.signalInitLock);
#endif
    if (!GEF.signalConfigurationDone) {
#ifdef GEF_POSIX
        for (signum = 1; signum < numberOfSignals; signum++) {
            if (sigismember(&GEF.signalSet, signum)) {
                GEF.signalHandlers[signum] = GEFAcceptSignal(signum);
            }    /* else do nothing for unsupported signals */
        }
#endif
        GEF.signalConfigurationDone = GEFTRUE;
    }
#ifdef GEF_PTHREADS
    GEF.numberOfThreads++;
    /* Should check return code of unlock */
    pthread_mutex_unlock(&GEF.signalInitLock);
#endif
}
#endif

#ifdef GEF_POSIX
static
void
GEFRestoreSignalHandlers(void) {
    int signum;
    int numberOfSignals = NSIG;

#ifdef GEF_PTHREADS
    pthread_mutex_lock(&GEF.signalInitLock);
    if (--GEF.numberOfThreads == 0) {
#endif
#ifdef GEF_POSIX
        for (signum = 1; signum < numberOfSignals; signum++) {
            if (sigismember(&GEF.signalSet, signum)) {
                (void) GEFSignal(signum, GEF.signalHandlers[signum]);
            }
        }
#endif
#ifdef GEF_PTHREADS
    }
    pthread_mutex_unlock(&GEF.signalInitLock);
#endif
}
#endif

static
void
GEFDeleteExceptionHandler(void* eh) {
    GEFExceptionHandler_t rep = eh;

#ifdef GEF_POSIX
    GEFRestoreSignalHandlers();
#endif
    GEFExceptionHandler_Delete(&rep);
#ifdef GEF_PTHREADS
    pthread_setspecific(GEF.exceptionHandlerKey, (void*) NULL);
#endif
}

void
GEFInitializeThread(GEFAttr_t attrs) {
    int current;
    int previous;
#ifdef GEF_POSIX
    sigset_t allSignals;
    sigset_t previousSignalMask;
#endif
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
#endif

    if (attrs.Abort == NULL) attrs.Abort = Abort;
    if (attrs.AssertionViolation == NULL) {
        attrs.AssertionViolation = AssertionViolation;
    }
    if (attrs.PreconditionViolation == NULL) {
        attrs.PreconditionViolation = PreconditionViolation;
    }
    if (attrs.PostconditionViolation == NULL) {
        attrs.PostconditionViolation = PostconditionViolation;
    }
    if (attrs.PreInvariantViolation == NULL) {
        attrs.PreInvariantViolation = PreInvariantViolation;
    }
    if (attrs.PostInvariantViolation == NULL) {
        attrs.PostInvariantViolation = PostInvariantViolation;
    }
    if (attrs.UnhandledException == NULL) {
        attrs.UnhandledException = UnhandledException;
    }
    if (attrs.Exit == NULL) attrs.Exit = Exit;
    if (attrs.Error == NULL) attrs.Error = Error;
    if (attrs.OutOfMemory == NULL) attrs.OutOfMemory = OutOfMemory;
    if (attrs.Delete == NULL) attrs.Delete = Delete;

#ifdef GEF_PTHREADS
#ifdef GEF_POSIX
    pthread_sigmask(SIG_UNBLOCK, &GEF.signalSet, NULL);
#endif
#else
#ifdef GEF_POSIX
    sigprocmask(SIG_UNBLOCK, &GEF.signalSet, NULL);
#endif
#endif

#ifdef GEF_POSIX
    sigfillset(&allSignals);
#endif
#ifdef GEF_PTHREADS
#ifdef GEF_POSIX
    if (pthread_sigmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        Error("GEFInitialize--pthread_sigmask(SIG_BLOCK, ...) failed!\n");
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#else
#ifdef GEF_POSIX
    if (sigprocmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        Error("GEFInitialize--sigprocmask(SIG_BLOCK, ...) failed!\n");
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
#endif
    if (eh == (GEFExceptionHandler_t) NULL) {
        eh = GEFExceptionHandler_New(attrs);
#ifdef GEF_POSIX
        GEFExceptionHandler_SetSignals(eh, GEF.signalSet);
#endif
#ifdef GEF_PTHREADS
        if (pthread_setspecific(GEF.exceptionHandlerKey, (void*) eh) != 0) {
            eh->Error("GEFInitializeThread--pthread_setspecific failed!\n");
            eh->Abort(GEF_EXCEPTION_FAILURE);
            Abort(GEF_EXCEPTION_FAILURE);
        }
#endif
    }
#ifdef GEF_POSIX
    GEFInitializeSignalHandler();
#else
    GEF.signalConfigurationDone = GEFTRUE;
#endif

    ProcessAssertLevel();

#ifdef GEF_PTHREADS
#ifdef GEF_POSIX
    if (pthread_sigmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        eh->Error("GEFInitialize--pthread_sigmask(SIG_SETMASK, ...) failed!\n");
        eh->Abort(GEF_EXCEPTION_FAILURE);
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
#else
#ifdef GEF_POSIX
    if (sigprocmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        eh->Error("GEFInitialize--sigprocmask(SIG_SETMASK, ...) failed!\n");
        eh->Abort(GEF_EXCEPTION_FAILURE);
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
#endif
}

#ifdef GEF_POSIX
void
GEFInitializeSignals(sigset_t signalSet) {
    sigset_t allSignals;
    sigset_t previousSignalMask;

    sigfillset(&allSignals);
#ifdef GEF_PTHREADS
#ifdef GEF_POSIX
    if (pthread_sigmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        fprintf(stderr, "GEFInitialize--pthread_sigmask(SIG_BLOCK, ...) failed!\n");
        pthread_kill(pthread_self(), SIGABRT);
    }
#endif
#else
#ifdef GEF_POSIX
    if (sigprocmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        fprintf(stderr, "GEFInitialize--sigprocmask(SIG_BLOCK, ...) failed!\n");
        kill(getpid(), SIGABRT);
    }
#endif
#endif
    if (sigismember(&signalSet, SIGABRT)) {
        /* Quietly remove SIGABRT, if it is a member of signalSet. */
        /* GEF reserves SIGABRT for its default behavior. */
        sigdelset(&signalSet, SIGABRT);
    }
    GEF.signalSet = signalSet;
#ifdef GEF_PTHREADS
#ifdef GEF_POSIX
    if (pthread_sigmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        Error("GEFInitialize--pthread_sigmask(SIG_SETMASK, ...) failed!\n");
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
#else
#ifdef GEF_POSIX
    if (sigprocmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        Error("GEFInitialize--sigprocmask(SIG_SETMASK, ...) failed!\n");
        Abort(GEF_EXCEPTION_FAILURE);
    }
#endif
#endif
}
#endif

static
void
Terminate(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = pthread_getspecific(GEF.exceptionHandlerKey);
    if (eh != NULL) GEFExceptionHandler_Delete(&eh);
    pthread_setspecific(GEF.exceptionHandlerKey, NULL);
    pthread_mutex_destroy(&GEF.signalInitLock);
    pthread_key_delete(GEF.exceptionHandlerKey);
#else
    if (eh != NULL) GEFExceptionHandler_Delete(&eh);
#endif
}

static
void
ProcessAssertLevel(void) {
    switch (GEF.assert_level) {
    case GEF_ASSERT_LEVEL_NONE:
        GEFDisablePreconditions();
        break;
    case GEF_ASSERT_LEVEL_PRE:
        GEFEnablePreconditions();
        break;
    case GEF_ASSERT_LEVEL_POST:
        GEFEnablePostconditions();
        break;
    case GEF_ASSERT_LEVEL_INVARIANTS:
        GEFEnableInvariants();
        break;
    default:
        Abort(GEF_EXCEPTION_FAILURE);
        break;
    }
    GEFSetDebug(GEF.debug);
    if (GEF.enabled) {
        GEFEnable();
    } else {
        GEFDisable();
    }
}

void
GEFInitialize(int* argc, char*** argv) {
    int current;
    int previous;
#ifdef GEF_POSIX
    sigset_t allSignals;
    sigset_t previousSignalMask;
#endif

    if (GEF.programName != NULL) {
        return; /* Already initialized! */
    }
    bzero(&GEF, sizeof(GEF));
    GEF.programName = "(Undefined Program Name)";
    GEF.enabled = GEFTRUE;
    GEF.debug = GEFFALSE;
    GEF.abort_on_assertion_violation = GEFFALSE;
    GEF.assert_level = GEF_ASSERT_LEVEL_NONE;
    ProcessOptions(argc, argv);
#ifdef GEF_POSIX
    sigfillset(&allSignals);
#ifdef GEF_PTHREADS
    if (pthread_sigmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        fprintf(stderr, "GEFInitialize--pthread_sigmask(SIG_BLOCK, ...) failed!\n");
        pthread_kill(pthread_self(), SIGABRT);
    }
    pthread_key_create(&GEF.exceptionHandlerKey, GEFDeleteExceptionHandler);
#else
    if (sigprocmask(SIG_BLOCK, &allSignals, &previousSignalMask) < 0) {
        fprintf(stderr, "GEFInitialize--sigprocmask(SIG_BLOCK, ...) failed!\n");
        kill(getpid(), SIGABRT);
    }
#endif /* GEF_PTHREADS */
#endif /* GEF_POSIX */
    GEF.signalConfigurationDone = GEFFALSE;
#ifdef GEF_POSIX
#ifdef GEF_PTHREADS
    pthread_mutex_init(&GEF.signalInitLock, NULL);
#endif /* GEF_PTHREADS */
    GEF.RaiseOSSignal = GEFRaiseOSSignal;
#ifdef GEF_PTHREADS
    GEF.numberOfThreads = 0;
    if (pthread_sigmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        fprintf(stderr, "GEFInitialize--pthread_sigmask(SIG_SET, ...) failed!\n");
        pthread_kill(pthread_self(), SIGABRT);
    }
#else
    if (sigprocmask(SIG_SETMASK, &previousSignalMask, NULL) < 0) {
        fprintf(stderr, "GEFInitialize--sigprocmask(SIG_SET, ...) failed!\n");
        kill(getpid(), SIGABRT);
    }
#endif /* GEF_PTHREADS */
#endif /* GEF_POSIX */
    atexit(Terminate);
}

#ifdef GEF_POSIX
void
GEFAddSignal(int signum) {
    sigaddset(&GEF.signalSet, signum);
}
#endif

#ifdef GEF_POSIX
void
GEFDeleteSignal(int signum) {
#ifdef GEF_POSIX
    sigdelset(&GEF.signalSet, signum);
#endif
}
#endif

GEFExceptionHandler_t
GEFGetExceptionHandler(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    return(eh);
}

int
GEFStackDepth(void) {
#ifdef GEF_PTHREADS
    GEFExceptionHandler_t eh = NULL;
    eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
    return(GEFExceptionHandler_StackDepth(eh));
}

#ifdef GEF_POSIX
void
GEFPrintSignalMask(void) {
    sigset_t oldset;
    int sig;

#ifdef GEF_PTHREADS
    pthread_sigmask(SIG_SETMASK, NULL, &oldset);
#else
    sigprocmask(SIG_SETMASK, NULL, &oldset);
#endif
    for (sig = NSIG - 1; sig > 0; sig--) {
        if (sigismember(&oldset, sig)) {
            putchar('1');
        } else putchar('0');
    }
    putchar('\n');
}
#endif

const char*
GEFProgramName(void) {
    return(GEF.programName);
}

void*
gef_malloc(size_t size) {
    void* answer = malloc(size);
    if (answer == NULL) {
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        GEFExceptionHandler_InsufficientMemory(eh);
    }
    return(answer);
}

void*
gef_calloc(size_t nmemb, size_t size) {
    void* answer = calloc(nmemb, size);
    if (answer == NULL) {
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        GEFExceptionHandler_InsufficientMemory(eh);
    }
    return(answer);
}

void
gef_free(void** ptr) {
    gef_try {
        if (*ptr != NULL) {
            free((void*) *ptr);
            *ptr = NULL;
        }
    } gef_preconditions {
        gef_assert_precondition(ptr != NULL);
    } gef_postconditions {
        gef_assert_postcondition(*ptr == NULL);
    } gef_end;
}

void
gef_realloc(void** ptr, size_t size) {
    void* answer = realloc(*ptr, size);
    if (answer == NULL) {
#ifdef GEF_PTHREADS
        GEFExceptionHandler_t eh = NULL;
        eh = pthread_getspecific(GEF.exceptionHandlerKey);
#endif
        GEFExceptionHandler_InsufficientMemory(eh);
    } else *ptr = answer;
}


static
void
Nothing(void) {
}

/* Command-line options */
typedef struct {
    char* value;
    void (*method)(void);
} GEFCommandOptionMethod_t;

typedef struct {
    char* name;
    int display;
    GEFCommandOptionMethod_t methods[10];
} GEFOption_t;

static
void
EnableAbortOnAssertionViolation (void) {
    GEF.abort_on_assertion_violation = GEFTRUE;
}

static
void
DisableAbortOnAssertionViolation (void) {
    GEF.abort_on_assertion_violation = GEFFALSE;
}

static
void
EnablePreconditions(void) {
    if (GEF.assert_level < GEF_ASSERT_LEVEL_PRE) {
        GEF.assert_level = GEF_ASSERT_LEVEL_PRE;
    }
}

static
void
DisablePreconditions(void) {
    if (GEF.assert_level > GEF_ASSERT_LEVEL_NONE) {
        GEF.assert_level =  GEF_ASSERT_LEVEL_NONE;
    }
}

static
void
EnablePostconditions(void) {
    if (GEF.assert_level < GEF_ASSERT_LEVEL_POST) {
        GEF.assert_level = GEF_ASSERT_LEVEL_POST;
    }
}

static
void
DisablePostconditions(void) {
    if (GEF.assert_level > GEF_ASSERT_LEVEL_PRE) {
        GEF.assert_level = GEF_ASSERT_LEVEL_PRE;
    }
}

static
void
EnableInvariants(void) {
    if (GEF.assert_level < GEF_ASSERT_LEVEL_INVARIANTS) {
        GEF.assert_level =  GEF_ASSERT_LEVEL_INVARIANTS;
    }
}

static
void
DisableInvariants(void) {
    if (GEF.assert_level >  GEF_ASSERT_LEVEL_POST) {
        GEF.assert_level = GEF_ASSERT_LEVEL_POST;
    }
}

static
void
Enable(void) {
    GEF.enabled = GEFTRUE;
}

static
void
Disable(void) {
    GEF.enabled = GEFFALSE;
}

static GEFOption_t CommandOptions[] = {
    { "--gef-preconditions=",  1, {{"true", EnablePreconditions}, {"false", DisablePreconditions}, { NULL, NULL}}},
    { "--gef-postconditions=", 1, {{"true", EnablePostconditions}, {"false", DisablePostconditions}, {NULL, NULL}}},
    { "--gef-invariants=", 1, {{"true", EnableInvariants}, {"false", DisableInvariants}, {NULL, NULL}}},
    /*
    { "--gef-debugger=", 1, {{"xxgdb", Nothing}, {"gdb", Nothing}, {"dbx", Nothing}, {NULL, NULL}}},
    { "--gef-activate-debugger=", 1, {{"true", Enable}, {"false", Disable}, {NULL, NULL}}},
    */
    { "--gef-abort-on-assertion-violation=", 1, {{"true", EnableAbortOnAssertionViolation}, {"false", DisableAbortOnAssertionViolation}, {NULL, NULL}}},
    { "--gef-activate-exception-handling=", 1, {{"true", Enable}, {"false", Disable}, {NULL, NULL}}},
    { "--gef-enable", 0, {{"", Enable}}}, /* Deprecate */
    { "--gef-disable", 0, {{ "", Disable}}}, /* Deprecate */
    { "--gef-help", 1, {{ "", Usage}}},
    { "-?", 1, {{ "", Usage}}},
    { NULL, 0, {{"", Nothing}}}
};


static
void
Usage(void) {
    int i = 0;
    printf("\nSummary of command-line options for the General Exception-Handling Facility\n(GEF)...\n\n");
    while (CommandOptions[i].name != NULL) {
        if (CommandOptions[i].display) {
            int j = 0;
            printf("   %s", CommandOptions[i].name);
            if (CommandOptions[i].methods[j].value != NULL &&
                strcmp(CommandOptions[i].methods[j].value, "") != 0) {
                printf("{%s", CommandOptions[i].methods[j].value);
                j++;
                while (CommandOptions[i].methods[j].value != NULL &&
                       strcmp(CommandOptions[i].methods[j].value, "") != 0) {
                    printf(" | %s", CommandOptions[i].methods[j].value);
                    j++;
                }
                printf("}");
            }
            printf("\n");
        }
        i++;
    }
    printf("\n\n");
}

static
int
DispatchOption(char* aCommand) {
    int answer = GEFFALSE;
    int i = 0;
    while (CommandOptions[i].name != NULL && answer == GEFFALSE) {
        if (strncmp(aCommand, CommandOptions[i].name, strlen(CommandOptions[i].name)) == 0) {
            char* aCommandValue = &aCommand[strlen(CommandOptions[i].name)];
            int j = 0;
            while (CommandOptions[i].methods[j].value != NULL) {
                if (strcmp(aCommandValue, CommandOptions[i].methods[j].value) == 0) {
                    CommandOptions[i].methods[j].method();
                    answer = GEFTRUE;
                    break;
                }
                j++;
            }
        }
        i++;
    }
    return(answer);
}

static
void
ShiftArgsLeftByOneAt(int* argc, char*** argv, int* i) {
    int j = *i;
    while (j + 1 < *argc) {
        (*argv)[j] = (*argv)[j + 1];
        j++;
    }
    (*argv)[j] = NULL;
    (*argc)--;
    (*i)--;
}

static
void
ProcessOptions(int* argc, char*** argv) {
    int i = 0;
    GEF.programName = (*argv)[0];
    for (i = 1; i < *argc; i++) {
        if (DispatchOption((*argv)[i])) {
            if (strcmp((*argv)[i], "-?") != 0) {
                if (strcmp((*argv)[i], "--gef-help") != 0) {
                    ShiftArgsLeftByOneAt(argc, argv, &i);
                } else (*argv)[i] = "-?";
            }
        }
    }
}
