%
% wine_sample.erl
%
-module (wine_sample).

-compile (export_all).
-include ("wine.hrl").

start () ->
  eresye:start (wine, wine),
  eresye:add_rule (wine, {wine_sample, rule, 1}),
  %eresye:assert (wine, #wine {name = "Vino"}),
  eresye:assert (wine, #'Chianti' {}),
  eresye:assert (wine, #'wine_grape' {}),
  ok.

stop () ->
  eresye:stop (wine).

%% rule (Engine, #wine{name = 'Vino'} = W) ->
%%   io:format ("~p~n", [W]);
rule (Engine, #wine{} = W) ->
  io:format ("~p~n", [W]);

rule (Engine, W) ->
  io:format ("~p~n", [W]).
