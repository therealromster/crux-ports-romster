%
% prodcons.erl
%
-module (prodcons).

-compile (export_all).

start () ->
  eresye:start (pc),
  spawn (prodcons, cons_1, [1]),
  spawn (prodcons, cons_1, [2]),
  spawn (prodcons, cons_1, [3]),
  spawn (prodcons, prod, [0]),
  ok.

prod (20) -> ok;
prod (Index) ->
  eresye:assert (pc, {item, Index}),
  prod (Index + 1).

cons (20) -> ok;%eres:stop (pc);
cons (Index) ->
  Fact = eresye:wait_and_retract (pc, {item, fun (X) -> X == Index end}),
  %%eres:retract (pc, Fact),
  io:format ("Consumer ~p~n", [Fact]),
  cons (Index + 1).

cons_1 (N) ->
  Fact = eresye:wait_and_retract (pc, {item, '_'}),
  %%eres:retract (pc, Fact),
  io:format ("~w: Consumer ~p~n", [N, Fact]),
  timer:sleep (random:uniform(500)),
  cons_1 (N).
