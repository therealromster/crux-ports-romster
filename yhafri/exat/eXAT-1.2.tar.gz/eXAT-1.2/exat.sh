#!/bin/sh

help()
{
  echo ""
  echo "usage:  exat.sh platform_name flags"
  echo ""
  echo "Flags:"
  echo "  -noshell             -- do not start erlang shell"
  echo "  -http_port PORT      -- use given http port instead of 7779 (default)"
  echo "  -start app1,..,appN  -- start the given agent applications"
  echo ""
  echo ""
  echo "The erlang eXperimental Agent Tool -- Release 1.2.0-EYE"
  echo "Copyright (C) 2003-05 Corrado Santoro (csanto@diit.unict.it)"
  echo "Copyright (C) 2005 Francesca Gangemi (francesca@erlang-consulting.com)"
  echo "Copyright (C) 2003-05 University of Catania (ITALY)"
  echo ""
  exit 1
}

if [ $# -gt 0 ]
then
    if [ "$1" == "--help" ]
    then
        help
    fi
    if [ "$1" == "-help" ]
    then
        help
    fi
    PLATFORM_NAME=$1
    shift
    erl -pa ebin -sname $PLATFORM_NAME -s exat_app $*
else
    help
fi
