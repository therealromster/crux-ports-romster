%
% sl.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-05, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the name of University of Catania
%   may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
-module (sl).
%%====================================================================
%% Include files
%%====================================================================
-include ("acl.hrl").
-include ("ontology.hrl").

%%====================================================================
%% External exports
%%====================================================================

-export ([decode/1,
          decode/3,
          encode/1,
          isList/1,
          isString/1,
          get_slot/2,
          replace_slot/3]).


%%====================================================================
%% Func: decode/1
%%====================================================================
decode (Message) ->
  decode (Message, ascii_sl, ontology).

%%====================================================================
%% Func: decode/3
%%====================================================================
decode (AsciiMessage, ascii_sl, erlang_sl) ->
  %%io:format ("ASCII ~s~n", [AsciiMessage]),
  T = tokenize (AsciiMessage),
  sl_parser:parse (T);
decode (SLMessage, erlang_sl, ontology) ->
  fipa_ontology_sl_codec:decode (SLMessage);
decode (AsciiMessage, ascii_sl, ontology) ->
  {ok, ErlangSL} = decode (AsciiMessage, ascii_sl, erlang_sl),
  %%io:format ("~w~n", [ErlangSL]),
  decode (ErlangSL, erlang_sl, ontology).



%%====================================================================
%% Func: encode/1
%% Description: ErlangSLForm --> ASCII SL Form
%% Returns: ASCIIForm
%%====================================================================
encode (Message) ->
  lists:flatten (encode (Message, isList (Message))).


encode (X, true) -> % isList
  [ "(", encode_list_terms ([], X), ")" ];
encode ({_, ?ACL_ANY}, false) -> % is not List
  [ ];
encode ({SlotName, SlotValue}, false) -> % is not List
  [ ":", atom_to_list (SlotName), " ",
    encode  (SlotValue, isList (SlotValue)) , " " ];
encode (TermValue, false) -> % is String
  [TermValue, " "].


encode_list_terms (Acc, []) -> lists:reverse (Acc);
encode_list_terms (Acc, [H|T]) ->
  Encoding = encode (H, isList (H)),
  encode_list_terms ([Encoding | Acc], T).


%%====================================================================
%% Func: get_slot/2
%% Description: returns the value of a given slot name
%% Returns: Value | ?ACL_ANY
%%====================================================================
get_slot (Key, List) ->
  case lists:keysearch (Key, 1, List) of
    {value, {_, Value}} -> Value;
    _ -> ?ACL_ANY
  end.

%%====================================================================
%% Func: replace_slot/3
%% Description: changes the value of a given slot name
%% Returns: None
%%====================================================================
replace_slot (Key, List, NewValue) ->
  lists:keyreplace (Key, 1, List, {Key, NewValue}).

%%====================================================================
%% Func: isList/1
%% Description: Checks if the given data is a list of strings
%% Returns: true | false
%%====================================================================
isList ([]) -> false;
isList ([H | _]) when is_number (H) -> false;
isList ([H | _]) when is_list (H) -> true;
isList (X) when is_tuple (X) -> false;
isList (_) -> true.


%%====================================================================
%% Func: isString/1
%% Description: Checks if the given data is a strings
%% Returns: true | false
%%====================================================================
isString ([]) -> true;
isString ([H | T]) when is_number (H) -> isString (T);
isString (X) when is_tuple (X) -> false;
isString (_) -> false.


%%====================================================================
%% Internal functions
%%====================================================================

tokenize ([]) -> [{'$end',1}];
tokenize ([H|T]) -> [ {list_to_atom ([H]),1} | tokenize (T) ].


