%
% match_lib.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-04, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of the <ORGANIZATION> nor the names of its
%   contributors may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
% $Id$
%
-module (match_lib).
-export ([match_all/2,match_acl/2]).

-author ('csanto@diit.unict.it').
-include ("acl.hrl").


match_atoms (F, Atom) when function(F) -> F (Atom);

match_atoms (Atom1, Atom2) ->
  (Atom1 == ?ACL_ANY) or (Atom2 == ?ACL_ANY) or (Atom1 == Atom2).

% matches lists
match_lists ([], []) -> true;
match_lists ([L1], [L2]) -> match_atoms (L1, L2);
match_lists ([L], [H|T]) -> false;
match_lists ([H|T], [L]) ->false;
match_lists ([H1|T1], [H2|T2]) ->
  X = match_atoms (H1, H2),
  if
    X -> match_lists (T1, T2);
    true -> false
  end.

% matches lists or tuples
match_all (Fact1, Fact2) ->
  Tuple1 = is_tuple (Fact1),
  Tuple2 = is_tuple (Fact2),
  if
    Tuple1 and Tuple2 ->
      match_lists (tuple_to_list (Fact1), tuple_to_list(Fact2));
    (not (Tuple1)) and Tuple2 ->
      false;
    Tuple1 and (not (Tuple2)) ->
      false;
    true ->
      match_lists (Fact1, Fact2)
  end.


%
% example:
%  match_lib:match_acl ({aclmessage,infom,nil,..,..,..,..}).
%
match_acl ([], Data) -> false;
match_acl ([Clause | Clauses], Data) ->
  Match = match_all (Clause, Data),
  if
    Match -> true;
    true -> match_acl (Clauses, Data)
  end.

%
% example:
%   match_lib:match(["[_,a]","[b,b]","[c,c]"],[z,a]).
%
match (Clauses, Pattern) ->
  F = build_fun (Clauses),
  StrPattern = lists:flatten (io_lib:write (Pattern)),
  F1 = "X=fun " ++ F ++ " end, X(" ++
    StrPattern ++ ").",
  %io:format ("~s\n", [F1]),
  {ok, Tokens, _} = erl_scan:string (F1),
  {ok, Expr} = erl_parse:parse_exprs (Tokens),
  case catch (erl_eval:exprs (Expr, erl_eval:new_bindings ())) of
    {'EXIT', _} -> false;
    {value, Value, Bindings} -> Value;
    _ -> false
  end.

build_fun ([H]) ->
  fun_from_term (H);

build_fun ([H|T]) ->
  fun_from_term (H) ++ "; " ++ build_fun (T).

%build_fun ([]) -> "".

fun_from_term (Term) ->
  "(" ++ Term ++ ") -> true".
