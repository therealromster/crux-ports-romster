%
% multisync.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-04, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the names of its
%   contributors may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
-module (multisync).
-export ([new/0, add_task/4, wait_one/1, abort/1]).

new () ->
  O = object:new (sync),
  object:set (O, 'tasklist', []),
  O.

add_task (Sync, Module, Proc, Params) ->
  %%io:format ("Exec task ~w\n", [Proc]),
  OldList = object:get (Sync, 'tasklist'),
  Pid = spawn (Module, Proc, [Sync | Params]),
  List = [Pid | OldList],
  object:set (Sync, 'tasklist', List),
  ok.

wait_one (Sync) ->
  Result = object:call (Sync, wait),
  %%io:format ("Wait result ~w\n", [Result]),
  kill_all (object:get (Sync, 'tasklist')),
  object:delete (Sync),
  Result.

abort (Sync) ->
  kill_all (object:get (Sync, 'tasklist')),
  object:delete (Sync),
  ok.

kill_all ([]) -> nil;
kill_all ([H]) -> catch (exit (H, kill));
kill_all ([H|T]) -> kill_all ([H]), kill_all (T).
