%
% aclscan.erl
% - New acl scanner
%
-module (aclscan).
-export ([scan/1]).

scan ([], Acc, Tokens) ->
  lists:reverse (Tokens);


scan ([$( | L], [], Tokens) ->
  scan (L, [], ["(" | Tokens]);

scan ([$( | L], Acc, Tokens) ->
  scan (L, [], ["(" | [lists:reverse (Acc) | Tokens]]);


scan ([$) | L], [], Tokens) ->
  scan (L, [], [")" | Tokens]);

scan ([$) | L], Acc, Tokens) ->
  scan (L, [], [")" | [lists:reverse (Acc) | Tokens]]);


scan ([$: | L], [], Tokens) ->
  scan (L, [], [":" | Tokens]);

scan ([$: | L], Acc, Tokens) ->
  scan (L, [], [":" | [lists:reverse (Acc) | Tokens]]);


scan ([$" | L], Acc, Tokens) ->
  [Data, Tail] = toquote (L),
  scan (Tail, [], [Data | [lists:reverse (Acc) | Tokens]]);


scan ([$  | L], Acc, Tokens) ->
  scan (L, [], [lists:reverse (Acc) | Tokens]);


scan ([$\\ , H | L], Acc, Tokens) ->
  scan (L, [H | Acc], Tokens);


scan ([H|L], Acc, Tokens) ->
  scan (L, [H | Acc], Tokens).

toquote ([]) -> [[], []];
toquote ([$" | T]) -> [[], T];
toquote ([$\\ , H | T]) -> [Data, Tail] = toquote (T), [[H | Data], Tail];
toquote ([H | T]) -> [Data, Tail] = toquote (T), [[H | Data], Tail].

remove_empty ([]) -> [];
remove_empty ([ [] | T]) -> remove_empty (T);
remove_empty ([ H  | T]) -> [H | remove_empty (T)].

scan (Message) ->
  remove_empty (scan (Message, [], [])).
