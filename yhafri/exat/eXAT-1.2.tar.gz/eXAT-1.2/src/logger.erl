%
% logger.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-04, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the name of University of Catania
%   may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%

-module (logger).
-behaviour (gen_event).
%%====================================================================
%% Include files
%%====================================================================

%%====================================================================
%% External exports
%%====================================================================

-export ([start/1,
          log/2,
          stop/1]).

%%====================================================================
%% Internal exports
%%====================================================================

-export ([init/1,
          handle_event/2,
          terminate/2,
          code_change/3]).

%%====================================================================
%% External functions
%%====================================================================
%%====================================================================
%% Function: start/1
%% Description: Starts a new logger
%%====================================================================

start (LoggerName) ->
  gen_event:start ({local, LoggerName}),
  gen_event:add_handler (LoggerName, logger, LoggerName).

%%====================================================================
%% Function: stop/1
%% Description: Stops a logger
%%====================================================================

stop (LoggerName) ->
  gen_event:stop (LoggerName).

%%====================================================================
%% Function: log/2
%% Description: Logs a message
%%====================================================================
log (LoggerName, Message) ->
  gen_event:notify (LoggerName, Message).


%%====================================================================
%% Internal functions
%%====================================================================
%%====================================================================
%% Func: init/1
%% Returns: {ok, State}
%%====================================================================
init (Arg) ->
  {ok, Arg}.


%%====================================================================
%% Func: handle_event/2
%% Returns: {ok, State}
%%====================================================================
handle_event (LogEvent, State) ->
  case LogEvent of
    {LogFormat, LogArgs} ->
      io:format ("[~w] " ++ LogFormat ++ "~n", [State | LogArgs]);
    LogString ->
      io:format ("[~w] ~s~n", [State, LogString])
  end,
  {ok, State}.


%%====================================================================
%% Func: terminate/2
%% Returns: ok
%%====================================================================
terminate (Args, State) -> ok.

%%====================================================================
%% Func: code_change/3
%% Returns: {ok, NewState}
%%====================================================================
code_change(OldVsn, State, _) ->
  {ok, State}.
