-module(sl_parser).
-define(THIS_MODULE, sl_parser).
-export([parse/1, parse_and_scan/1, format_error/1]).

%% ``The contents of this file are subject to the Erlang Public License,
%% Version 1.1, (the "License"); you may not use this file except in
%% compliance with the License. You should have received a copy of the
%% Erlang Public License along with this software. If not, it can be
%% retrieved via the world wide web at http://www.erlang.org/.
%% 
%% Software distributed under the License is distributed on an "AS IS"
%% basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
%% the License for the specific language governing rights and limitations
%% under the License.
%% 
%% The Initial Developer of the Original Code is Ericsson Utvecklings AB.
%% Portions created by Ericsson are Copyright 1999, Ericsson Utvecklings
%% AB. All Rights Reserved.''
%% 
%%     $Id$
%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The parser generator will insert appropriate declarations before this line.%

parse(Tokens) ->
    case catch yeccpars1(Tokens, false, 0, [], []) of
	error ->
	    Errorline =
		if Tokens == [] -> 0; true -> element(2, hd(Tokens)) end,
	    {error,
	     {Errorline, ?THIS_MODULE, "syntax error at or after this line."}};
	Other ->
	    Other
    end.

parse_and_scan({Mod, Fun, Args}) ->
    case apply(Mod, Fun, Args) of
	{eof, _} ->
	    {ok, eof};
	{error, Descriptor, _} ->
	    {error, Descriptor};
	{ok, Tokens, _} ->
	    yeccpars1(Tokens, {Mod, Fun, Args}, 0, [], [])
    end.

format_error(Message) ->
    case io_lib:deep_char_list(Message) of
	true ->
	    Message;
	_ ->
	    io_lib:write(Message)
    end.

% To be used in grammar files to throw an error message to the parser toplevel.
% Doesn't have to be exported!
return_error(Line, Message) ->
    throw({error, {Line, ?THIS_MODULE, Message}}).


% Don't change yeccpars1/6 too much, it is called recursively by yeccpars2/8!
yeccpars1([Token | Tokens], Tokenizer, State, States, Vstack) ->
    yeccpars2(State, element(1, Token), States, Vstack, Token, Tokens,
	      Tokenizer);
yeccpars1([], {M, F, A}, State, States, Vstack) ->
    case catch apply(M, F, A) of
        {eof, Endline} ->
            {error, {Endline, ?THIS_MODULE, "end_of_file"}};
        {error, Descriptor, _Endline} ->
            {error, Descriptor};
        {'EXIT', Reason} ->
            {error, {0, ?THIS_MODULE, Reason}};
        {ok, Tokens, _Endline} ->
	    case catch yeccpars1(Tokens, {M, F, A}, State, States, Vstack) of
		error ->
		    Errorline = element(2, hd(Tokens)),
		    {error, {Errorline, ?THIS_MODULE,
			     "syntax error at or after this line."}};
		Other ->
		    Other
	    end
    end;
yeccpars1([], false, State, States, Vstack) ->
    yeccpars2(State, '$end', States, Vstack, {'$end', 999999}, [], false).

% For internal use only.
yeccerror(Token) ->
    {error,
     {element(2, Token), ?THIS_MODULE,
      ["syntax error before: ", yecctoken2string(Token)]}}.

yecctoken2string({atom, _, A}) -> io_lib:write(A);
yecctoken2string({integer,_,N}) -> io_lib:write(N);
yecctoken2string({float,_,F}) -> io_lib:write(F);
yecctoken2string({char,_,C}) -> io_lib:write_char(C);
yecctoken2string({var,_,V}) -> io_lib:format('~s', [V]);
yecctoken2string({string,_,S}) -> io_lib:write_string(S);
yecctoken2string({reserved_symbol, _, A}) -> io_lib:format('~w', [A]);
yecctoken2string({_Cat, _, Val}) -> io_lib:format('~w', [Val]);

yecctoken2string({'dot', _}) -> io_lib:format('~w', ['.']);
yecctoken2string({'$end', _}) ->
    [];
yecctoken2string({Other, _}) when atom(Other) ->
    io_lib:format('~w', [Other]);
yecctoken2string(Other) ->
    io_lib:write(Other).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


yeccpars2(0, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 1, [0 | __Ss], [__T | __Stack]);
yeccpars2(0, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(1, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 9, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 10, [1 | __Ss], [__T | __Stack]);
yeccpars2(1, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(2, '$end', _, __Stack, _, _, _) ->
 {ok, hd(__Stack)};
yeccpars2(2, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(3, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(acl, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(4, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [4 | __Ss], [__T | __Stack]);
yeccpars2(4, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  '$undefined',
 yeccpars2(yeccgoto(wsp, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(5, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(6, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(7, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(8, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(9, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 1, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 10, [9 | __Ss], [__T | __Stack]);
yeccpars2(9, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(10, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [],
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(11, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(12, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(13, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(14, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(15, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(16, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(17, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(18, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(19, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(20, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(21, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(22, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(23, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(24, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(25, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(number, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(26, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 127, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [26 | __Ss], [__T | __Stack]);
yeccpars2(26, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(27, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(28, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(29, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(30, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(31, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(32, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(vchar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(33, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(34, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(35, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(36, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(37, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(38, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(39, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(40, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(41, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(42, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(43, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(44, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(45, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(46, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(47, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(48, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(49, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(50, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(51, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(52, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(53, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(54, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(55, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(56, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(57, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(58, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(upcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(59, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(60, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(61, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(62, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(63, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(64, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(65, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(66, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(67, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(68, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [68 | __Ss], [__T | __Stack]);
yeccpars2(68, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1],
 yeccpars2(yeccgoto(elements, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(69, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [69 | __Ss], [__T | __Stack]);
yeccpars2(69, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 118, [69 | __Ss], [__T | __Stack]);
yeccpars2(69, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(70, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(71, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(72, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(73, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(74, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(75, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(76, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(77, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(vchar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(78, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(elem, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(79, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(80, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(81, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(82, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(vchar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(83, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(84, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(85, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(86, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(87, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(88, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(elem, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(89, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(vchar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(90, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(91, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(elem, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(92, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(93, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(94, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(95, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 127, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [95 | __Ss], [__T | __Stack]);
yeccpars2(95, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1],
 yeccpars2(yeccgoto(vcharstringterms, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(96, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(term, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(97, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  http_server:terms_to_string(__1),
 yeccpars2(yeccgoto(vcharstring, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(98, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(99, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 107, [99 | __Ss], [__T | __Stack]);
yeccpars2(99, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(100, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(101, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(102, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(lowcase_letter, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(103, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(104, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(105, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(106, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(107, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 112, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 10, [107 | __Ss], [__T | __Stack]);
yeccpars2(107, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(108, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [108 | __Ss], [__T | __Stack]);
yeccpars2(108, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 109, [108 | __Ss], [__T | __Stack]);
yeccpars2(108, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(109, __Cat, __Ss,  [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __3,
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(110, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 111, [110 | __Ss], [__T | __Stack]);
yeccpars2(110, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(111, __Cat, __Ss,  [__5,__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __3,
 __Nss = lists:nthtail(4, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(112, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 9, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 10, [112 | __Ss], [__T | __Stack]);
yeccpars2(112, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(113, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [113 | __Ss], [__T | __Stack]);
yeccpars2(113, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 118, [113 | __Ss], [__T | __Stack]);
yeccpars2(113, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(114, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 107, [114 | __Ss], [__T | __Stack]);
yeccpars2(114, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(115, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [115 | __Ss], [__T | __Stack]);
yeccpars2(115, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 109, [115 | __Ss], [__T | __Stack]);
yeccpars2(115, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(116, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 117, [116 | __Ss], [__T | __Stack]);
yeccpars2(116, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(117, __Cat, __Ss,  [__5,__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __3,
 __Nss = lists:nthtail(4, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(118, __Cat, __Ss,  [__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(2, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(119, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 120, [119 | __Ss], [__T | __Stack]);
yeccpars2(119, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(120, __Cat, __Ss,  [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(121, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [121 | __Ss], [__T | __Stack]);
yeccpars2(121, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 126, [121 | __Ss], [__T | __Stack]);
yeccpars2(121, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(122, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 123, [122 | __Ss], [__T | __Stack]);
yeccpars2(122, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(123, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 1, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 10, [123 | __Ss], [__T | __Stack]);
yeccpars2(123, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(124, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [124 | __Ss], [__T | __Stack]);
yeccpars2(124, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 125, [124 | __Ss], [__T | __Stack]);
yeccpars2(124, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(125, ' ', __Ss, [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __3,
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), ' ', __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(125, __Cat, __Ss,  [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __3,
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(126, ')', __Ss, [__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(2, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), ')', __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(126, __Cat, __Ss,  [__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(2, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(127, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(symbol, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(128, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1|__2],
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(vcharstringterms, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(129, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 130, [129 | __Ss], [__T | __Stack]);
yeccpars2(129, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(130, __Cat, __Ss,  [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(list, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(131, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 26, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 1, [131 | __Ss], [__T | __Stack]);
yeccpars2(131, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1],
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(elements, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(132, __Cat, __Ss,  [__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1] ++ __3,
 __Nss = lists:nthtail(2, __Ss),
 yeccpars2(yeccgoto(elements, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(133, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [133 | __Ss], [__T | __Stack]);
yeccpars2(133, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(134, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 127, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '"', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 135, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 1, [134 | __Ss], [__T | __Stack]);
yeccpars2(134, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(135, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 127, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '\\', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 144, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 142, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 141, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '$', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 140, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, '*', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 143, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 139, [135 | __Ss], [__T | __Stack]);
yeccpars2(135, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(136, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(slotterm, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(137, __Cat, __Ss,  [__4,__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  {list_to_atom(__2),__4},
 __Nss = lists:nthtail(3, __Ss),
 yeccpars2(yeccgoto(slot, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(138, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(slotterm, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(139, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(140, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(141, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(142, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(143, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(144, '"', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 151, [144 | __Ss], [__T | __Stack]);
yeccpars2(144, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(145, '9', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 25, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '8', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 24, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '7', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 23, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '6', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 22, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '5', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 21, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '4', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 20, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '3', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 19, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '2', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 18, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '1', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 17, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '0', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 16, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 102, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 101, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'x', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 100, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'w', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 98, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'v', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 94, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'u', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 92, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 't', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 90, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 's', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 87, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'r', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 86, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 85, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'p', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 84, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'o', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 83, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'n', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 81, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'm', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 80, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'l', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 76, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'k', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 75, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'j', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 74, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'i', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 73, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'h', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 72, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'g', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 71, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'f', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 70, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'e', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 67, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'd', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 66, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'c', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 65, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'b', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 64, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'a', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 63, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'Z', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 58, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'Y', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 57, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'X', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 56, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'W', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 55, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'V', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 54, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'U', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 53, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'T', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 52, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'S', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 51, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'R', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 50, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'Q', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 49, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'P', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 48, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'O', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 47, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'N', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 46, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'M', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 45, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'L', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 44, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'K', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 43, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'J', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 42, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'I', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 41, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'H', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 40, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'G', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 39, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'F', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 38, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'E', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 37, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'D', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 36, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'C', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 35, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'B', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 34, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, 'A', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 33, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '~', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 106, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '}', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 105, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '|', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 104, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '{', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 103, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '_', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 62, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '^', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 61, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ']', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 60, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '[', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 59, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '?', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 31, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '>', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 30, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '=', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 29, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '<', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 28, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ';', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 27, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ':', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 127, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '.', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 14, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '/', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 15, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '-', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 13, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ',', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 12, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '+', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 11, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '&', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 8, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '%', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 7, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '#', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 6, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '!', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 5, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '@', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 32, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '\\', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 144, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 142, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '(', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 141, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '$', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 140, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, '*', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 143, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 139, [145 | __Ss], [__T | __Stack]);
yeccpars2(145, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1],
 yeccpars2(yeccgoto(astringterms, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(146, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  http_server:terms_to_string(__1),
 yeccpars2(yeccgoto(quotedstring, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(147, '"', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 149, [147 | __Ss], [__T | __Stack]);
yeccpars2(147, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(148, __Cat, __Ss,  [__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __1,
 yeccpars2(yeccgoto(achar, hd(__Ss)), __Cat, __Ss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(149, __Cat, __Ss,  [__3,__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(2, __Ss),
 yeccpars2(yeccgoto(slotterm, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(150, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  [__1|__2],
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(astringterms, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(151, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  __2,
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(achar, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(152, ' ', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 4, [152 | __Ss], [__T | __Stack]);
yeccpars2(152, ')', __Ss, __Stack, __T, __Ts, __Tzr) ->
 yeccpars1(__Ts, __Tzr, 126, [152 | __Ss], [__T | __Stack]);
yeccpars2(152, _, _, _, __T, _, _) ->
 yeccerror(__T);
yeccpars2(153, __Cat, __Ss,  [__2,__1|__Stack], __T, __Ts, __Tzr) ->
 __Val =  '$undefined',
 __Nss = lists:nthtail(1, __Ss),
 yeccpars2(yeccgoto(wsp, hd(__Nss)), __Cat, __Nss, [__Val | __Stack], __T, __Ts, __Tzr);
yeccpars2(__Other, _, _, _, _, _, _) ->
 exit({parser, __Other, missing_state_in_action_table}).

yeccgoto(achar, 135) ->
 145;
yeccgoto(achar, 145) ->
 145;
yeccgoto(acl, 0) ->
 2;
yeccgoto(astringterms, 135) ->
 146;
yeccgoto(astringterms, 145) ->
 150;
yeccgoto(elem, 1) ->
 68;
yeccgoto(elem, 9) ->
 68;
yeccgoto(elem, 99) ->
 68;
yeccgoto(elem, 107) ->
 68;
yeccgoto(elem, 112) ->
 68;
yeccgoto(elem, 114) ->
 68;
yeccgoto(elem, 122) ->
 68;
yeccgoto(elem, 123) ->
 68;
yeccgoto(elem, 131) ->
 68;
yeccgoto(elements, 1) ->
 69;
yeccgoto(elements, 9) ->
 152;
yeccgoto(elements, 99) ->
 108;
yeccgoto(elements, 107) ->
 113;
yeccgoto(elements, 112) ->
 121;
yeccgoto(elements, 114) ->
 115;
yeccgoto(elements, 122) ->
 124;
yeccgoto(elements, 123) ->
 113;
yeccgoto(elements, 131) ->
 132;
yeccgoto(letter, 1) ->
 77;
yeccgoto(letter, 9) ->
 77;
yeccgoto(letter, 26) ->
 77;
yeccgoto(letter, 95) ->
 77;
yeccgoto(letter, 99) ->
 77;
yeccgoto(letter, 107) ->
 77;
yeccgoto(letter, 112) ->
 77;
yeccgoto(letter, 114) ->
 77;
yeccgoto(letter, 122) ->
 77;
yeccgoto(letter, 123) ->
 77;
yeccgoto(letter, 131) ->
 77;
yeccgoto(letter, 134) ->
 77;
yeccgoto(letter, 135) ->
 77;
yeccgoto(letter, 145) ->
 77;
yeccgoto(list, 0) ->
 3;
yeccgoto(list, 1) ->
 78;
yeccgoto(list, 9) ->
 78;
yeccgoto(list, 99) ->
 78;
yeccgoto(list, 107) ->
 78;
yeccgoto(list, 112) ->
 78;
yeccgoto(list, 114) ->
 78;
yeccgoto(list, 122) ->
 78;
yeccgoto(list, 123) ->
 78;
yeccgoto(list, 131) ->
 78;
yeccgoto(list, 134) ->
 136;
yeccgoto(lowcase_letter, 1) ->
 79;
yeccgoto(lowcase_letter, 9) ->
 79;
yeccgoto(lowcase_letter, 26) ->
 79;
yeccgoto(lowcase_letter, 95) ->
 79;
yeccgoto(lowcase_letter, 99) ->
 79;
yeccgoto(lowcase_letter, 107) ->
 79;
yeccgoto(lowcase_letter, 112) ->
 79;
yeccgoto(lowcase_letter, 114) ->
 79;
yeccgoto(lowcase_letter, 122) ->
 79;
yeccgoto(lowcase_letter, 123) ->
 79;
yeccgoto(lowcase_letter, 131) ->
 79;
yeccgoto(lowcase_letter, 134) ->
 79;
yeccgoto(lowcase_letter, 135) ->
 79;
yeccgoto(lowcase_letter, 145) ->
 79;
yeccgoto(number, 1) ->
 82;
yeccgoto(number, 9) ->
 82;
yeccgoto(number, 26) ->
 82;
yeccgoto(number, 95) ->
 82;
yeccgoto(number, 99) ->
 82;
yeccgoto(number, 107) ->
 82;
yeccgoto(number, 112) ->
 82;
yeccgoto(number, 114) ->
 82;
yeccgoto(number, 122) ->
 82;
yeccgoto(number, 123) ->
 82;
yeccgoto(number, 131) ->
 82;
yeccgoto(number, 134) ->
 82;
yeccgoto(number, 135) ->
 82;
yeccgoto(number, 145) ->
 82;
yeccgoto(quotedstring, 135) ->
 147;
yeccgoto(slot, 1) ->
 88;
yeccgoto(slot, 9) ->
 88;
yeccgoto(slot, 99) ->
 88;
yeccgoto(slot, 107) ->
 88;
yeccgoto(slot, 112) ->
 88;
yeccgoto(slot, 114) ->
 88;
yeccgoto(slot, 122) ->
 88;
yeccgoto(slot, 123) ->
 88;
yeccgoto(slot, 131) ->
 88;
yeccgoto(slotterm, 134) ->
 137;
yeccgoto(symbol, 1) ->
 89;
yeccgoto(symbol, 9) ->
 89;
yeccgoto(symbol, 26) ->
 89;
yeccgoto(symbol, 95) ->
 89;
yeccgoto(symbol, 99) ->
 89;
yeccgoto(symbol, 107) ->
 89;
yeccgoto(symbol, 112) ->
 89;
yeccgoto(symbol, 114) ->
 89;
yeccgoto(symbol, 122) ->
 89;
yeccgoto(symbol, 123) ->
 89;
yeccgoto(symbol, 131) ->
 89;
yeccgoto(symbol, 134) ->
 89;
yeccgoto(symbol, 135) ->
 89;
yeccgoto(symbol, 145) ->
 89;
yeccgoto(term, 1) ->
 91;
yeccgoto(term, 9) ->
 91;
yeccgoto(term, 26) ->
 133;
yeccgoto(term, 99) ->
 91;
yeccgoto(term, 107) ->
 91;
yeccgoto(term, 112) ->
 91;
yeccgoto(term, 114) ->
 91;
yeccgoto(term, 122) ->
 91;
yeccgoto(term, 123) ->
 91;
yeccgoto(term, 131) ->
 91;
yeccgoto(term, 134) ->
 138;
yeccgoto(upcase_letter, 1) ->
 93;
yeccgoto(upcase_letter, 9) ->
 93;
yeccgoto(upcase_letter, 26) ->
 93;
yeccgoto(upcase_letter, 95) ->
 93;
yeccgoto(upcase_letter, 99) ->
 93;
yeccgoto(upcase_letter, 107) ->
 93;
yeccgoto(upcase_letter, 112) ->
 93;
yeccgoto(upcase_letter, 114) ->
 93;
yeccgoto(upcase_letter, 122) ->
 93;
yeccgoto(upcase_letter, 123) ->
 93;
yeccgoto(upcase_letter, 131) ->
 93;
yeccgoto(upcase_letter, 134) ->
 93;
yeccgoto(upcase_letter, 135) ->
 93;
yeccgoto(upcase_letter, 145) ->
 93;
yeccgoto(vchar, 1) ->
 95;
yeccgoto(vchar, 9) ->
 95;
yeccgoto(vchar, 26) ->
 95;
yeccgoto(vchar, 95) ->
 95;
yeccgoto(vchar, 99) ->
 95;
yeccgoto(vchar, 107) ->
 95;
yeccgoto(vchar, 112) ->
 95;
yeccgoto(vchar, 114) ->
 95;
yeccgoto(vchar, 122) ->
 95;
yeccgoto(vchar, 123) ->
 95;
yeccgoto(vchar, 131) ->
 95;
yeccgoto(vchar, 134) ->
 95;
yeccgoto(vchar, 135) ->
 148;
yeccgoto(vchar, 145) ->
 148;
yeccgoto(vcharstring, 1) ->
 96;
yeccgoto(vcharstring, 9) ->
 96;
yeccgoto(vcharstring, 26) ->
 96;
yeccgoto(vcharstring, 99) ->
 96;
yeccgoto(vcharstring, 107) ->
 96;
yeccgoto(vcharstring, 112) ->
 96;
yeccgoto(vcharstring, 114) ->
 96;
yeccgoto(vcharstring, 122) ->
 96;
yeccgoto(vcharstring, 123) ->
 96;
yeccgoto(vcharstring, 131) ->
 96;
yeccgoto(vcharstring, 134) ->
 96;
yeccgoto(vcharstringterms, 1) ->
 97;
yeccgoto(vcharstringterms, 9) ->
 97;
yeccgoto(vcharstringterms, 26) ->
 97;
yeccgoto(vcharstringterms, 95) ->
 128;
yeccgoto(vcharstringterms, 99) ->
 97;
yeccgoto(vcharstringterms, 107) ->
 97;
yeccgoto(vcharstringterms, 112) ->
 97;
yeccgoto(vcharstringterms, 114) ->
 97;
yeccgoto(vcharstringterms, 122) ->
 97;
yeccgoto(vcharstringterms, 123) ->
 97;
yeccgoto(vcharstringterms, 131) ->
 97;
yeccgoto(vcharstringterms, 134) ->
 97;
yeccgoto(wsp, 1) ->
 99;
yeccgoto(wsp, 4) ->
 153;
yeccgoto(wsp, 9) ->
 122;
yeccgoto(wsp, 68) ->
 131;
yeccgoto(wsp, 69) ->
 129;
yeccgoto(wsp, 107) ->
 114;
yeccgoto(wsp, 108) ->
 110;
yeccgoto(wsp, 112) ->
 122;
yeccgoto(wsp, 113) ->
 119;
yeccgoto(wsp, 115) ->
 116;
yeccgoto(wsp, 121) ->
 119;
yeccgoto(wsp, 123) ->
 99;
yeccgoto(wsp, 124) ->
 110;
yeccgoto(wsp, 133) ->
 134;
yeccgoto(wsp, 152) ->
 129;
yeccgoto(__Symbol, __State) ->
 exit({__Symbol, __State, missing_in_goto_table}).


