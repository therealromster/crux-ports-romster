%
% exat_server.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-05, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the name of University of Catania
%   may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
-module (exat_server).

%%====================================================================
%% Include files
%%====================================================================

%%====================================================================
%% External exports
%%====================================================================

-export ([start_link/1]).

%%====================================================================
%% Internal exports
%%====================================================================

%%====================================================================
%% Macros
%%====================================================================

%%====================================================================
%% Records
%%====================================================================

%%====================================================================
%% External functions
%%====================================================================
%%====================================================================
%% Function: start_link/1
%% Description: Starts the MTP worker
%%====================================================================

start_link (Port) ->
  io:format ("~n"),
  io:format ("              __      __    __    _______~n"),
  io:format ("              \\ \\    / /   /  \\  |__   __|~n"),
  io:format ("        ____   \\ \\  / /   / /\\ \\    | |~n"),
  io:format ("       / __ \\   \\ \\/ /   | |__| |   | |~n"),
  io:format ("      | ____/   / /\\ \\   |  __  |   | |~n"),
  io:format ("      | \\____  / /  \\ \\  | |  | |   | |~n"),
  io:format ("       \\____/ /_/    \\_\\ |_|  |_|   |_|~n"),
  io:format ("*****                                     *****************~n"),
  io:format ("* The erlang eXperimental Agent Tool -- Release 1.2.0-EYE *~n"),
  io:format ("***********************************************************~n"),
  io:format ("Copyright (C) 2003-05 Corrado Santoro (csanto@diit.unict.it)~n"),
  io:format ("Copyright (C) 2005 Francesca Gangemi (francesca@erlang-consulting.com)~n"),
  io:format ("Copyright (C) 2003-05 University of Catania (ITALY)~n~n"),
  {ok, Pid} = mtp:http (Port),
  register (mtp, Pid),
  {ok, Pid}.

