%
% pingagent.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-05, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the name of University of Catania
%   may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
% $Id$
%
%-------------------------------------------
% THIS IS THE AGENTCITIES PING AGENT
%-------------------------------------------
%
-module (pingagent).
-export ([extends/0,
          pattern/2,
          event/2,
          action/2,
          on_starting/1,
          get_ping_proc/4,
          start/0]).
-include ("acl.hrl").

extends () -> nil.

action (Self, start) -> [{acl_event, get_ping_proc}].

event (Self, acl_event) -> {acl, all_pattern}.

pattern (Self, all_pattern) -> [#aclmessage {}].


%%
%%
%%
on_starting (Self) ->
  logger:start ('PING-AGENT').

%%
%% get the ping message
%%
get_ping_proc (Self, Event, Msg = #aclmessage {speechact = 'QUERY-REF',
                                               content = "ping"},
               Action) ->
  logger:log ('PING-AGENT', "Received PING MESSAGE"),
  acl:reply (Msg, 'INFORM', "alive");
%%
%%
%%
get_ping_proc (Self, Event, Msg, Action) ->
  logger:log ('PING-AGENT', {"Received ~p, NOT UNDERSTOOD", [Msg]}),
  acl:reply (Msg, 'NOT-UNDERSTOOD', Msg#aclmessage.content).
%%
%%

%%
start () ->
  agent:new (pingagent, [{behaviour, pingagent}]).
