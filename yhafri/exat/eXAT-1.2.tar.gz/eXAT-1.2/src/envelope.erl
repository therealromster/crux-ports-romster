%
% envelope.erl
%
% ----------------------------------------------------------------------
% Copyright (c) 2003-05, Corrado Santoro <csanto@diit.unict.it>
% Department of Computer and Telecommunication Engineering,
% University of Catania, Italy. All rights reserved.
%
% Redistribution and use in source and binary forms, with or without
% modification, are permitted provided that the following conditions are met:
%
% * Redistributions of source code must retain the above copyright notice,
%   this list of conditions and the following disclaimer.
%
% * Redistributions in binary form must reproduce the above copyright
%   notice, this list of conditions and the following disclaimer in the
%   documentation and/or other materials provided with the distribution.
%
% * Neither the name of Corrado Santoro nor the name of University of Catania
%   may be used to endorse or promote products derived from this
%   software without specific prior written permission.
%
% THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
% AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
% IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
% ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
% LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
% CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
% SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
% INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
% CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
% ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
% POSSIBILITY OF SUCH DAMAGE.
%
-module (envelope).
-include_lib ("xmerl/include/xmerl.hrl").
-include ("acl.hrl").
-include ("fipa_ontology.hrl").
-export ([make_xml_envelope/4,
          make_xml_envelope/3,
          parse_xml_envelope/1,
          test/0]).

make_xml_envelope (To, From, Length, AclRepr) ->
%%   io:format ("From ~w~n", [From]),
%%   io:format ("To ~w~n", [To]),
  XmlTo = {'agent-identifier', [],
           [ {name, [], [To#'agent-identifier'.name]},
             {addresses, [], [ {url, [], [X]} ||
                               X <- To#'agent-identifier'.addresses] }
            ]},
  XmlFrom = {'agent-identifier', [],
             [ {name, [], [From#'agent-identifier'.name]},
             {addresses, [], [ {url, [], [X]} ||
                               X <- From#'agent-identifier'.addresses] }]
            },
%%   io:format ("XMLFrom ~w~n", [XmlFrom]),
%%   io:format ("XMLTo ~w~n", [XmlTo]),
%%   io:format ("Length ~s~n", [integer_to_list (Length)]),
  Envelope = {envelope, [],
              [ {params, [{index, 1}],
                 [{to, [], [XmlTo]},
                  {from, [], [XmlFrom]},
                  {'acl-representation', [], [AclRepr]},
                  {'payload-length', [], [integer_to_list (Length)]},
                  {'payload-encoding', [], ["US-ASCII"]},
                  {'intended-receiver', [], [XmlTo]}
                 ]}]},

  lists:flatten (xmerl:export_simple ([Envelope], xmerl_xml)).



make_xml_envelope (To, From, Length) ->
  make_xml_envelope (To, From, Length, "fipa.acl.rep.string.std").


get_xml_element (XML = #xmlElement {name = Key}, Key) ->
  {ok, XML};
get_xml_element (XML, Key) when record (XML, xmlElement) ->
  get_xml_element (XML#xmlElement.content, Key);
get_xml_element ([], _)  ->
  {error, nil};
get_xml_element ([XMLH | XMLT], Key)  ->
  case get_xml_element (XMLH, Key) of
    {ok, Data} -> {ok, Data};
    _ -> get_xml_element (XMLT, Key)
  end;
get_xml_element (_,_) -> {error, nil}.


get_xml_text (XML) ->
  [Content | _] = XML#xmlElement.content,
  Text = Content#xmlText.value,
  Text.

parse_xml_envelope (XmlEnvelope) ->
  {Envelope, _} = xmerl_scan:string (XmlEnvelope),

  {ok, XTo} = get_xml_element (Envelope, 'to'),
  {ok, XToAgentID} = get_xml_element (XTo, 'agent-identifier'),
  {ok, XToAgentName} = get_xml_element (XToAgentID, 'name'),
  {ok, XToAgentAddress} = get_xml_element (XToAgentID, 'addresses'),
  {ok, XToURL} = get_xml_element (XToAgentAddress, 'url'),
  ToAgentName = get_xml_text (XToAgentName),
  ToURL = get_xml_text (XToURL),

  {ok, XFrom} = get_xml_element (Envelope, 'from'),
  {ok, XFromAgentID} = get_xml_element (XFrom, 'agent-identifier'),
  {ok, XFromAgentName} = get_xml_element (XFromAgentID, 'name'),
  {ok, XFromAgentAddress} = get_xml_element (XFromAgentID, 'addresses'),
  {ok, XFromURL} = get_xml_element (XFromAgentAddress, 'url'),
  FromAgentName = get_xml_text (XFromAgentName),
  FromURL = get_xml_text (XFromURL),

  {ok, XACLRepresentation} = get_xml_element (Envelope, 'acl-representation'),
  ACLRepresentation = get_xml_text (XACLRepresentation),

  %io:format ("From ~s[~s]~n", [FromAgentName, FromURL]),
  %io:format ("To   ~s[~s]~n", [ToAgentName, ToURL]),
  %io:format ("Repr ~s~n", [ACLRepresentation]),

  {#'agent-identifier' {name = list_to_atom (ToAgentName),
                           addresses = ToURL},
   #'agent-identifier' {name = list_to_atom (FromAgentName),
                           addresses = FromURL},
   ACLRepresentation}.

test () ->
  make_xml_envelope (#'agent-identifier' {name = pippo,
                                             addresses = "http://a:80/acc"},
                     #'agent-identifier' {name = pluto,
                                             addresses = "http://b:80/acc"},
                     100).

