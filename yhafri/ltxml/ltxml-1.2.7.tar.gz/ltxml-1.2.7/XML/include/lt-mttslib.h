/* Interface to STD library used by NSLSUP and NSL */
/* Used to be called stdlib.h */
#ifndef _steve_stdlib_h

#include <stdlib.h>
#include <string.h>
#include "lt-defs.h"
#include "lt-comment.h"  /* comments */
#include "lt-memory.h"   /* malloc definitions */
#include "lt-safe.h"     /* file opening definitions */

#define _steve_stdlib_h
#endif
