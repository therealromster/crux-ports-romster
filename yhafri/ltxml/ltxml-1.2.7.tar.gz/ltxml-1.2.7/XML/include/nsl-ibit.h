enum NSL_ibit_type { NSL_ibit_doctype_statement };

struct NSL_ibit {
  enum NSL_ibit_type subtype;
  void * data;
};
