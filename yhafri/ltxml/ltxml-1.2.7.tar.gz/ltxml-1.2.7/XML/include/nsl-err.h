/* This is an include file for defining error handling for programs
   which use the LT NSL library */

/* Include the LT STD error handling stuff */

#include "lt-comment.h"

/* Then, redefine the stuff we are interested in (i.e. NSLNERR?,
   SHOULDNT_ERROR, SHOULDNT) */

#include "nsl-errmsg.h"

#undef SHOULDNT_ERROR
#define SHOULDNT_ERROR NSNSL

#undef SHOULDNT
#define SHOULDNT LTSTDError(SHOULDNT_ERROR,2,__FILE__,__LINE__)

