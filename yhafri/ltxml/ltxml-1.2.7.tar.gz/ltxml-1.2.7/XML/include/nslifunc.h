/* This version uses Richard's XML-aware parser */

#ifndef _nslifunc_h
#define _nslifunc_h

/* function templates for internal use only */

#include "nsl-defs.h"

extern XML_API boolean EXPRT AddOpenContext( NSL_File_I *f, NSL_Item *item);
extern XML_API boolean EXPRT AddCloseContext( NSL_File_I *f, const Char *tagname );
extern XML_API SFState EXPRT PrintStartTagInternal(NSL_File_I *f, SFState state, const NSL_Item *item);
extern XML_API  NSL_Data * EXPRT FirstChild( const NSL_Item *item, boolean noText ); 
extern XML_API  int  EXPRT SQMatch ( const NSL_Query_I *qu, const NSL_Item *item );

extern XML_API NSL_Attr * EXPRT AllocAttr(const NSL_Doctype_I *doctype);
extern XML_API NSL_Q_Attr * EXPRT AllocQAttr(void);
extern XML_API NSL_Attr * EXPRT AttrDup( const NSL_Attr *attr );
extern XML_API NSL_Attr * EXPRT AttrFromSpec( const AttributeSummary *atsum,
					      const NSL_Doctype_I *doctype);
const AttributeSummary* FindAttrSpecAndNumber(const NSL_ElementSummary_I *elts,
				     const NSL_Doctype_I *doctype,
				     const Char *name,
				     int *attrnum);
const Char * EXPRT DeclareAttr(NSL_Doctype_I *doctype, const Char *Name,
			int length,
			NSL_Attr_Declared_Value declared_value,
			const Char *allowed_values, int allowed_values_count,
			NSL_ADefType default_type, const Char *default_value,
			NSL_ElementSummary_I **eltptr,
			const Char *eltName);
extern XML_API RHTEntry * EXPRT DeclareElement(NSL_Doctype_I *doctype, const Char *name,
			 int length, const char *data, ctVals mtype);
extern XML_API const Char * EXPRT ElementUniqueNameI(const NSL_Doctype_I *doctype,
				      const Char *name, int length);
extern XML_API boolean  EXPRT ExecQueryUp( const NSL_Query_I *qu, const NSL_Data *dptr );
extern XML_API boolean  EXPRT FreeQAttr(NSL_Q_Attr *attr,NSL_Name_Behaviour nb);
extern XML_API const void * EXPRT GetAttrDefaultVal( const AttributeSummary *atsum );
extern XML_API const NSL_Query_I * EXPRT InitSegQueryUp( const NSL_Query_I *qu,
					  const NSL_Data *dptr );
extern XML_API const char8 * EXPRT MakeSpec( const NSL_Doctype_I *doctype );
extern XML_API Char * EXPRT MkRCData( const Char *data );
extern XML_API NSL_Bit * EXPRT NextBit(NSL_File_I *sf);
extern XML_API int  EXPRT SetSourceFile(  NSL_File_I *sf, const FILE *filep );
extern XML_API boolean  EXPRT StdFiles( NSL_FType type );
extern XML_API boolean  EXPRT in( const Char *string, int ch );
extern XML_API RHTEntry* EXPRT xrinsert(NSL_Doctype_I *doctype,
					const Char*,int,RHashTableHdr*,RHVal);

#ifdef _LinkIDs_
extern XML_API LinkRef * EXPRT AddRef( Char *name, NSL_Item *item );
extern XML_API LinkRef * EXPRT FindRef(Char *name);
extern XML_API void      EXPRT DeleteRef( Char *name );
extern XML_API void    * EXPRT GetCRef( Char *name );
extern XML_API LinkRef * EXPRT GetRef( Char *name );
extern XML_API boolean   EXPRT LinkCStruct( NSL_Item *item, void *cstruct, char *type );
#endif

#endif

