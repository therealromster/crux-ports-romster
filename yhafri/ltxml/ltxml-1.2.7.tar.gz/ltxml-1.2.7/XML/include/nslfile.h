/* This version uses Richard's XML-aware parser */
/* nslfile.h	-- Henry S. Thompson
 */

#ifndef _NSLFILE_H

#include "nsl-stack.h"

typedef enum {_pending_re,_elt_unknown,_elt_begin,
		_elt_text,_elt_end} SFState;

typedef struct NSL_File_I {
  FILE16 *file16;		/* only for output */
  FILE *fileToClose;		/* If we opened it, we will need to close it */
  struct NSL_Doctype_I *doctype;
  NSL_FType type;
  struct Stack eltContent;
  /* next lot only valid for input files */
  NSL_Bit _bit1;
  NSL_Bit *peekBit;
  int cnum;                           /* Used by AddOpen/CloseContext */
  struct parser_state *pstate;
  NSL_Data *currentbase;
  int currentItemCharPosn;	/* Char offset of latest item read */
  int currentBitOffset;

#if 0
  /* No longer required - there is always a doctype to store this in */
  const Char *doctypeStatement;
#endif
  /* rest only valid for output files */
  SFState state;
} NSL_File_I;

#define _NSLFILE_H

#endif
