/* stack.h	-- Henry S. Thompson
 */

#ifndef _STACK_H

#include "lt-defs.h"

#define StackSize 32

typedef struct Stack {
  void** base;
  void** end;
  void** current;
} Stack;

extern boolean  EXPRT  stackGrow( Stack *stack );

#define _STACK_H

#endif
