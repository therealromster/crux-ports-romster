#ifndef _steve_string_h
#define _steve_string_h

extern STD_API int EXPRT var_int_scan ( char *string, int *list );
extern STD_API int EXPRT var_float_scan ( char *string, float *list );
extern STD_API int EXPRT var_string_scan ( char *string, char **list );
extern STD_API char * EXPRT var_int_print ( int n, char *string, int *list );
extern STD_API char * EXPRT var_float_print ( int n, char *string, float *list );
extern STD_API char * EXPRT var_string_print ( int n, char *string, char **list );
extern STD_API int EXPRT NumTokens( char *string );
#endif
