/* errmsg.h	-- Henry S. Thompson
   Error numbers and messages for library functions
 */

#ifndef _LT_ERRMSG_H
#define _LT_ERRMSG_H

#define LENULA 1
#define LESHOULDNT 2
#define LEMALE 3
#define LEFILE 4
#define LEMAP 5
#define LEFREE 6
#define LEDDB  7
#define LEWRTF 8
#define LERDF 9
#define LESYSE 10
#define LERGXP 11
#define LEDDBF 12

#define LENERR 12

#endif
