#ifndef _steve_env_h
#define _steve_env_h

#include <stdio.h>

/******************  DIRECTORIES & FILES ********************/

extern STD_API char * EXPRT FindFilename(char *name, char **path); /*allocate memory*/
extern STD_API char ** EXPRT MakePath(char *envpath);

extern STD_API char*   EXPRT getCurDir(void);  /* allocate memory */
extern STD_API int     EXPRT get_process_dir(const char *argv0, char** dir, char** name); 

#ifdef HAVE_POPEN
extern STD_API FILE*   EXPRT open_abs_names(const char*  fn);
extern STD_API void    EXPRT close_abs_names(  FILE*  fi);
#endif

#endif
