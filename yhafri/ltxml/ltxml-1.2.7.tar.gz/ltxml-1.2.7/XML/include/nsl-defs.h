/* defs.h	-- Henry Thompson
 * Some basics, and stuff depending on switches in config.h
 */

#ifndef _NSL_DEFS_H
#define _NSL_DEFS_H

#define XML_API

#if defined(WIN32) && ! defined(__CYGWIN__)
 #ifndef __BORLAND__
  #undef XML_API
  #ifdef _BUILD_API
   #define XML_API __declspec(dllexport)
  #else
   #define XML_API __declspec(dllimport)
  #endif
 #endif
#endif

#include "lt-defs.h"

#define STREQ(str1,str2)\
((((str1)==NULL)||((str2)==NULL))?0:(strcmp((str1),(str2))==0))

     /* Added here, so that knitGenerator can use this, without using
        the rest of the LT NSL interface */

extern int NSLInitErrorMessages( int error_Threshold );

#endif /* _NSL_DEFS_H */
