#ifndef _readddb_h
#define _readddb_h

/* Map in a .ddb file and provide access to the information there */

#include "nsl-defs.h"
#include "ddb.h"

extern XML_API DDBHeader* readddb(const char8*); /* filename */
extern XML_API boolean showddb(const DDBHeader*);
extern XML_API boolean checkddb(const char8* ddbFile, const DDBHeader* ddb, boolean quiet);

#endif /* _readddb_h */
