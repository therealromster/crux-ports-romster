/* 	$Id: sgmltrans.c,v 1.32 2003/05/23 00:45:17 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sgmltrans.c,v 1.32 2003/05/23 00:45:17 richard Exp $";
#endif /* lint */
/* Copyright 1996,1997 Human Communication Research Centre, 
   Edinburgh University */

/* At present, only reads ASCII rule files */

#include <stdlib.h>
#include "nsl.h"
#include "lt-memory.h"
#include "query.h"
#include "ctype16.h"
#include "string16.h"

/* From query.c */

extern int SQMatch(NSL_Query qu, const NSL_Item *item );

boolean MyExecQueryUp(NSL_Query qu, const NSL_Item *item );
boolean MySQSatisfy(NSL_Query qu, const NSL_Item *item);
const NSL_Item *MyParentItem(const NSL_Item *item);

/* Stacks */

typedef struct MyStack {
  int* base;
  int* end;
  int* current;
} MyStack;

boolean initStack(MyStack *stack, int size);
boolean MystackGrow( MyStack *stack );
void    FreeStack(MyStack *stack);

#define POP(stack) (*(--stack.current))

#define POPNV(stack) (--stack.current)

#define TOP(stack) (*(stack.current-1))

#define STACKBAD(stack) (stack.current < stack.base)

#define EMPTY(stack) (stack.current == stack.base)

#define NONEMPTY(stack) (stack.current > stack.base)

#define PUSH(stack,newc) if (stack.current==stack.end) { \
			   MystackGrow(&(stack)); \
			 }; \
			 *(stack.current++)=newc;

MyStack stack;

/* Rules */

typedef struct Rule {
  struct Rule *next;
  boolean pcdata;
  Char *querys;
  NSL_Query query;
  /* for element rules */
  Char * startrule;
  Char *endrule;
  boolean skip;             /* If true, then we don't process children */
  /* for data rules */
  int nopatterns;
  Char **pattern;
  Char **replace;
} Rule;

Rule *rules = NULL;

void ApplyRule(Char *rulestring, NSL_Item *item, NSL_Doctype dct);
void ApplyTextRule(const Rule *rule, const NSL_Bit *bit);
Rule *MatchesRule( Rule *rules, const NSL_Item *item , boolean pcdata);
void ExpandRuleString(Char *string, Char *newstring, NSL_Item *item, 
		      NSL_Doctype dct);
void PrintTextString(Char *string, const Rule *rule);

Rule *read_rule_file(FILE *filep, NSL_Doctype dct);
Rule *ReadRule(FILE *filep, NSL_Doctype dct);
Char *ReadQuery(FILE *filep, boolean *pcdata);
Char *ReadTemplate(FILE *filep, boolean *skip);
void ReadSubsList(FILE *filep, Rule *rule);
boolean ReadSub(FILE *filep, char *pattern, char *replace, boolean *skip);
Char* Normalise(char *pattern);
void PrintRules(Rule *rules);
void FreeRules(Rule *rules);
void HandleAttributeName(Char **chr, Char **newchr, boolean lc,
			  NSL_Item *item, NSL_Doctype dct);
int process_file(NSL_File inf, NSL_Doctype dct);

static char *read_delimited(FILE *f, int delimiter, int escape);

/* MAIN */

static void usage(int exitval)
{
    fprintf(stderr, "usage: sgmltrans [-he] [-d ddb-file] [-u base-url] -r rulefile [-p] [filename ...]\n");
    exit(exitval);
}

CharacterEncoding OutputEncoding;

int main(int argc, char **argv) {
  NSL_File inf=NULL;
  NSL_Doctype dct=NULL;
  char *rulefile = NULL;
  FILE *filep;
  boolean printRules = FALSE;
  int arg;
  char *s;
  NSL_Common_Options *options;

  NSLInit(0);
  initStack(&stack,500);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 'p':
	      printRules = TRUE;
	      break;
	  case 'r':
	      if(arg+1 == argc)
		  usage(2);
	      rulefile = argv[++arg];
	      break;
	  default:
	      usage(2);
	  }
  }

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    default:
	inf = SFopen(argv[arg++], dct, options->read_type);
	break;
  }
  dct=DoctypeFromFile(inf);
  /*  OutputEncoding = dct->defaultOutputEncoding; ht removed
      XXX add arg for this */

  if( ( filep = fopen(rulefile,"r") )){
    rules = read_rule_file(filep,dct);
  } else {
    Fprintf(Stderr, "sgmltrans: Couldn't open %s\n",rulefile);
  }
  if( printRules ){
    PrintRules(rules);
    FreeRules(rules);
    FreeStack(&stack);
    return(0);
  }

  process_file(inf,dct);
  while( arg < argc ){
    SFclose(inf);
    inf=SFopen(argv[arg++], dct, options->read_type);
    process_file(inf,dct);
  }

  FreeRules(rules);
  FreeStack(&stack);
  SFrelease(inf,TRUE);
  return 0;
}

int process_file(NSL_File inf, NSL_Doctype dct){
  NSL_Bit *bit;
  NSL_Item *startItem = NULL;
  Rule *rule = NULL;
 
  while( ( bit=GetNextBit(inf) ) ) {
    switch (bit->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
      if( TOP(stack) ){
	/* This is a hack! The items have NULL in pointers */
	/* presumably because they are inchoate. I reuse */
	/* The in pointer to point to the previous item */
	/* on the stack, so that SQSatisfy will work    */
	bit->value.item->in = (NSL_Data*)TOP(stack);
      }
      if( ( rule = MatchesRule(rules, bit->value.item, FALSE) ) ){
	ApplyRule(rule->startrule,bit->value.item,dct);
	if( bit->type == NSL_start_bit){
	  if( rule->skip ){
	    /* Don't process children of this element */
	    ItemParse(inf,bit->value.item);
	    FreeBit(bit);
	  } else {
	    /* Else, process its children by pushing myself and
               continue reading bits */
	    PUSH(stack,(int)rule);
	    PUSH(stack,(int)(bit->value.item));
	  }
	} else {
	  FreeBit(bit);
	}
      } else {
	/* No matching rule */
	Fprintf(Stderr, "No matching rule for %S\n",bit->label);
	FreeRules(rules);
	FreeStack(&stack);
	return 2;
      }
      break;
    case NSL_end_bit:
      startItem = (NSL_Item*)POP(stack);
      rule      = (Rule*)POP(stack);
      if( rule == NULL ){
	Fprintf(Stderr, "Empty stack at </%S>\n",bit->label);
	return 4;
      } else {
	ApplyRule(rule->endrule,startItem,dct);
	startItem->in = NULL;
	FreeItem(startItem);
	FreeBit(bit);
      }
      break;
    case NSL_text_bit:
      if( TOP(stack) ){
	rule = MatchesRule(rules,(NSL_Item*)TOP(stack),TRUE);
	ApplyTextRule(rule,bit);
      } else {
	Fprintf(Stderr, "Empty stack at '%S'\n",bit->value.body);
      }
      FreeBit(bit);
      break;
    case NSL_pi_bit:
      FreeBit(bit);
      break;
    case NSL_bad:
    case NSL_eof_bit:
      Fprintf(Stderr, "ERROR: bad/eof bit type\n");
      FreeRules(rules);
      FreeStack(&stack);
      return 3;
      break;
    default:
      Fprintf(Stderr, "ERROR: odd bit type %d\n",bit->type);
    }
  }
  return 0;
}

/* =========== STACK implementation ========== */

boolean initStack(MyStack *stack,int size){
  ECNF(stack->base=stack->current=(int*)salloc(size*sizeof(int)));
  stack->end=stack->base+size;
  *(stack->current++)=0; /* Push fencepost */
  return TRUE;
}

boolean MystackGrow(MyStack *stack) {
  int len;
  int *p;
  len=stack->end-stack->base;
  ECNF(p=salloc(2*len));
  memcpy(p,stack->base,2*len);
  ECFF(sfree(stack->base));
  stack->base=p;
  stack->current=stack->base+len;
  stack->end=stack->base+(2*len);
  return TRUE;
}

void FreeStack(MyStack *stack){
  sfree(stack->base);
}

/* ========= Rule application =========== */

/* */

void ApplyRule(Char *rulestring, NSL_Item *item, NSL_Doctype dct){
  static Char newstring[500];
  if( !rulestring ){
    Fprintf(Stderr, "Null string in ApplyRule. Item = %S\n", item->label);
  }
  ExpandRuleString(rulestring,newstring,item,dct);
  Printf("%S",newstring);
}

void ApplyTextRule(const Rule *rule, const NSL_Bit *bit){
  if( rule ){
    if( !rule->skip ){
      /* If the rule says skip we dont print anything */
      PrintTextString(bit->value.body,rule);
    }
  } else {
    Printf("%S",bit->value.body);
  }
}

Rule *MatchesRule( Rule *rule, const NSL_Item *item, boolean pcdata ){
  Rule *r;

  for( r=rule; r ; r=r->next ){
    if( ( MyExecQueryUp(r->query,item) ) && ( pcdata == r->pcdata )){
      return r;
    }
  }
  return NULL;
}

void subst(Char *string, Char* newstring, const Char* pattern, const Char* replacement){
  Char *x, *new;
  int patternlen, replacelen;

  new = newstring;
  patternlen = Strlen(pattern);
  replacelen = Strlen(replacement);
  
  while( ( x = Strstr(string,pattern) )){
    Strncpy(new,string,(int)(x-string));
    new = new + (int)(x-string);
    Strncpy(new,replacement,replacelen);
    new = new + replacelen;
    string = x + patternlen;
  }
  Strcpy(new,string);
}

void PrintTextString(Char *string, const Rule *rule){
  Char *src, *dest, *tmp;
  int i;
  src  = (Char*)salloc(2*(Strlen(string)+1)*sizeof(Char));
  dest = (Char*)salloc(2*(Strlen(string)+1)*sizeof(Char));
  Strcpy(src,string);
  for( i=0; i<rule->nopatterns; i++){
    subst(src,dest,rule->pattern[i],rule->replace[i]);
    tmp = src;
    src = dest;
    dest = tmp;
  }
  Printf("%S",src);
  sfree(src);
  sfree(dest);
}

/* Takes a string and creates a new string where all $name s have been
   replaced with the GI or attribute values from item.  If we have
   $lc(ATTRNAME), then we replace with the lower case value of the
   attribute or GI.  If the sequence of name3 characters after $ is
   not an attribute name then we leave the $ in place. */

void ExpandRuleString(Char *string, Char *newstring, NSL_Item *item,
		      NSL_Doctype dct){
  Char * chr, *newchr ;

  if( !string ){
    Fprintf(Stderr,
	    "Null string in ExpandRuleString. Item = %S\n",item->label);
  }
  newchr = newstring;
  for( chr=string ; *chr ; chr++){
    if( *chr == '$' ){
      if( *(chr+1) == 'l' && *(chr+2) == 'c' && *(chr+3) == '(' ){
	/* We lower case the attribute value */
        chr += 3;
	HandleAttributeName(&chr,&newchr,TRUE,item,dct);
	if( *(chr+1) != ')' ){
	  Fprintf(Stderr, "Found '%c' instead of ')' in call of lc()\n",
		  *(chr+1));
	} else {
	  chr++;
	}
      } else {
	HandleAttributeName(&chr,&newchr,FALSE,item,dct);
      }
    } else {
      *newchr++ = *chr;
    }
  }
  *newchr = '\000';
}

/* chr is character before start of attribute name */
/* If lc is TRUE, then we lowercase the value of the attribute or gi */

void HandleAttributeName(Char **chr, Char **newchr, boolean lc,
			  NSL_Item *item, NSL_Doctype dct){

  /* Attribute names ==> attribute values */ 
  Char name[128], *tmp = *chr+1; 
  const Char *uName, *val;
  int len;

  if( *tmp == 'g' && *(tmp+1) == 'i' ){
    *chr += 2; 
    val = item->label;
    if( lc ){
      while( *val ){
	**newchr = Tolower(*val++);
	*newchr += 1;
      }
    } else {
      Strcpy(*newchr,val);
      *newchr += Strlen(val);
    }
    return;
  }

  /* skip over attribute name */
  while(is_xml_namechar(*tmp, xml_char_map))
      tmp++;

/* was:
  for( ; ( ( ( 'A' <= *tmp ) && ( *tmp <= 'Z' ) ) || 
         ( ( '0' <= *tmp ) && ( *tmp <= '9' ) ) ||
	 ( *tmp == '-' ) || 
	 ( *tmp == '_' ) ); tmp++ ){};
*/
  
  len = tmp-*chr-1;
  Strncpy(name,*chr+1,len);
  name[len] = '\000';
  uName = AttrUniqueName(dct,name,len);
  if( uName ){
    /* A Valid attribute */
    if( ( val = GetAttrStringVal(item,uName))){
      if( lc ){
	while( *val ){
	  **newchr = Tolower(*val++);
	  *newchr += 1;
	}
      } else {
	Strcpy(*newchr,val);
	*newchr += Strlen(val);
      }
      *chr = tmp-1;
    } else {
      **newchr++ = **chr;
    }
  } else {
    Fprintf(Stderr, "Invalid attribute name: \"%S\" ignored\n",name);
    **newchr++ = **chr;
  }
}

/* ============ Reading the rules file ============= */

Rule *read_rule_file(FILE *filep, NSL_Doctype dct){
  Rule *rules = NULL, 
       *lastRule = NULL, 
       *rule;

  for( rule=ReadRule(filep,dct); rule; rule=ReadRule(filep,dct) ){
    if( lastRule ){
	lastRule->next = rule;
      } else {
	rules = rule;
      }
      lastRule = rule;
  }
  return rules;
}

Rule *ReadRule(FILE *filep, NSL_Doctype dct){
  Char *querys;
  NSL_Query query;
  Rule *rule;
  boolean pcdata, skip;

  if( ( querys = ReadQuery(filep,&pcdata) ) ){
    rule = (Rule *)salloc(sizeof(Rule));
    rule->querys = querys; 
    if( !( query = ParseQuery(dct,querys) ) ){
      Fprintf(Stderr, "Invalid query: \"%S\"\n", querys);
    }
    rule->query = query;
    rule->pcdata = pcdata;
    if( pcdata == TRUE ){
      ReadSubsList(filep,rule);
      rule->startrule=rule->endrule=NULL;
    } else {
      rule->nopatterns=0;
      rule->pattern=rule->replace=0;
      rule->startrule = ReadTemplate(filep,&skip);
      rule->endrule   = ReadTemplate(filep,&skip);
      rule->skip      = skip;
    }
    rule->next = NULL;
    return rule;
  } else {
    return NULL;
  }
}

/* XXX converts char8 input to Char */

Char *ReadQuery(FILE *filep, boolean *pcdata){
  static char querys[500];
  char *xxx;
  int len;

  /* Read lines, until we get to one with some non-whitespace chars,
   and whose first character is NOT a '#' character */
  do{
    if( fgets(querys,500,filep) ){
      len = strlen(querys);
    } else {
      len = 0;
    }
  } while ( len > 0 && ( querys[0] == '#' || strspn(querys," \t\n") == (size_t)len ));
  if( len ){
    querys[len-1] = '\000'; /* Remove newline */
    if( ( xxx = strstr(querys,"/#") ) && ( strlen(xxx) == 2 ) ){
      /* querys ends in /# */
      querys[len-3] = '\000';
      *pcdata = TRUE;
    } else {
      *pcdata = FALSE;
    }
    return strdup_char8_to_Char(querys);
  } else {
    return NULL;
  }
}

/* Read a start tag or end tag format string */

/* Fixed to handle long strings, but there are still lots more... */

Char *ReadTemplate(FILE *filep, boolean *skip ){
  char *template;
  int chr;

  *skip = FALSE;
  while( ( chr = fgetc(filep)) == '\n' ||
	 ( chr == '\t' ) ||
         ( chr == ' ' ) ){};
  if( chr != '"' ){
    template = read_delimited(filep, '\n', 0);
    if( chr == 'S' && strncmp8(template,"KIP",3) == 0 ){
      /* Special case: SKIP as an endtag replacement means don't process
	 children of this node */
      *skip = TRUE;
    } else {
	Fprintf(Stderr, "sgmltrans: Missing \" in rules file: %s\n",template);
    }
    return NULL;
  } else {
    /* Read until we get a un-backslashed double quote */
    template = read_delimited(filep, '"', '\\');
    while( ( chr = fgetc(filep)) != '\n' ){};
    return Normalise(template);
  } 
}

void ReadSubsList(FILE *filep, Rule *rule){
  char pattern[500], replace[500];
  boolean skip;

  rule->nopatterns = 0;
  rule->pattern = (Char **)malloc(200*sizeof(char*));
  rule->replace = (Char **)malloc(200*sizeof(char*));
  while( ReadSub(filep,pattern,replace,&skip) ){
    rule->skip = skip;
    rule->pattern[rule->nopatterns] = Normalise(pattern);
    rule->replace[rule->nopatterns] = Normalise(replace);
    rule->nopatterns++;
  }
}

/* This routine converts \CHAR into a character
   \n ==> newline
   \t ==> tab
   \\ ==> \
   Other \X ==> \X */

/* At present, it also does char8 -> Char conversion XXX */

Char* Normalise(char *pattern){
  Char *news, *newchr;
  char *chr;

  news = tsalloc(Char, strlen(pattern)+1);
  newchr = news;
  for( chr=pattern; *chr; chr++ ){
    if( *chr == '\\' ){
      if( *(chr+1) == 'n' ){
	*newchr++ = '\n';
	chr += 1;
      } else if( *(chr+1) == '\\' ){
	*newchr++ = '\\';
	chr += 1;
      } else if( *(chr+1) == 't' ){
	*newchr++ = '\t';
	chr += 1;
      } else {
	*newchr++ = *chr;
      }
    } else {
      *newchr++ = *chr;
    }
  }
  *newchr = '\000';
  return news;  
}

boolean ReadSub(FILE *filep, char *pattern, char *replace, boolean *skip){
  int chr;
  char line[500];

  *skip = FALSE;
  if( ( chr = fgetc(filep) ) == '\t' ){
    fgets(line,500,filep);
    if( strncmp(line,"SKIP",4) == 0 ){
      *skip = TRUE;
      return TRUE;
    } else if( sscanf(line," \"%[^\"]\" --> \"%[^\"]\"",
		      pattern,replace) == 2 ){
      return TRUE;
    } else if( sscanf(line," \"%[^\"]\" --> \"\"",
		      pattern) == 1 ){
      replace = (char *)"";
      return TRUE;
    } else {
      Fprintf(Stderr,"Invalid syntax: %s\n",line);
      return FALSE;
    }
  } else {
    ungetc(chr,filep);
    return FALSE;
  }
}

void PrintRules(Rule *rules){
  int i;

  for( ; rules ; rules = rules->next ){
    Printf("Rule(%d): %S\n",rules->pcdata,rules->querys);
    if( rules->pcdata ){
      for( i=0; i<rules->nopatterns; i++){    
	Printf("      \"%S\" --> \"%S\"\n",
	       rules->pattern[i],
	       rules->replace[i]);
      }
    } else{
      Printf("      START: \"%S\"\n",rules->startrule);
      Printf("      END: \"%S\"\n",rules->endrule);  
    }
  }
}

/* Free space associated with a sequence of Rules */

void FreeRules(Rule *rules){
  int i;
  Rule *next;

  for( ; rules ; rules = next ){
    sfree(rules->querys);
    FreeQuery(rules->query);
    sfree(rules->startrule);
    sfree(rules->endrule);
    if( rules->pcdata ){
      for( i=0; i<rules->nopatterns; i++){
	sfree(rules->pattern[i]);
	sfree(rules->replace[i]);
      }
    }
    sfree(rules->pattern);
    sfree(rules->replace);
    next = rules->next;
    sfree(rules);
  }
}

/* ============ Matching queries and items ============= */
/* Copied from query.c cos we need a new version of MyParentItem() */


const NSL_Item *MyParentItem(const NSL_Item *item){
  return (NSL_Item*)item->in;
}

/* This starts at the bottom and goes up */

boolean MySQSatisfy( NSL_Query qu, const NSL_Item *item) {
  const NSL_Item *iptr;

  if (qu==NULL && item==NULL) {
    return TRUE;
  }
  if (qu && qu->type==_qu_anystar && qu->prev==NULL) {
    return TRUE;
  }

  if (qu==NULL || item==NULL) {
    return FALSE;
  }

  switch (qu->type) {
  case _qu_any:
    return MySQSatisfy( qu->prev, MyParentItem(item) );
  case _qu_anystar:
    for (iptr=item; iptr; iptr=MyParentItem(iptr)) {
      if (MySQSatisfy(qu->prev, iptr)) {
	return TRUE;
      }
    }
    return FALSE;
  case _qu_star:
    for (iptr=item; iptr; iptr=MyParentItem(iptr)) {
      if (MySQSatisfy(qu->prev, iptr)) {
	return TRUE;
      }
      if (!SQMatch(qu,iptr)) {
	return FALSE;
      }
    }
    return FALSE;
  case _qu_norm:
    if (SQMatch(qu, item)) {
      return MySQSatisfy(qu->prev, MyParentItem(item));
    }
    else {
      return FALSE;
    }
  default:
    SHOULDNT;
    return FALSE;
  }
}

boolean MyExecQueryUp( NSL_Query qu, const NSL_Item *item ) {
  NSL_Query q;

  for (q=qu; q->next; q=q->next)
    ; /* EMPTY */

  return MySQSatisfy(q, item );
}

/* Read up to but excluding a delimiter (or EOF).  If escape is non-zero,
 * the delimiter will not be recognised after the escape character,
 * and the escape will be removed when followed by the delimiter.
 * Space is allocated as required, but is owned by this function, so
 * the caller must copy it if it wants to keep it beyond another call.
 */

static char *read_delimited(FILE *f, int delimiter, int escape)
{
    static int alloc = 0;
    static char *buffer = 0;
    int c, len = 0;

    while((c = getc(f)) != EOF && c != delimiter)
    {
	if(len+2 > alloc)	/* sometimes we add two character */
	{
	    alloc = alloc > 0 ? alloc * 2 : 60;
	    ECNN(buffer = srealloc(buffer, alloc));
	}
	if(escape && c == escape)
	{
	    c = getc(f);
	    if(c == EOF)
	    {
		buffer[len++] = escape;
		break;
	    }
	    else if(c == delimiter)
		buffer[len++] = delimiter;
	    else 
	    {
		buffer[len++] = escape;
		buffer[len++] = c;
	    }
	}
	else
	    buffer[len++] = c;
    }

    if(len+1 > alloc)
    {
	alloc = alloc > 0 ? alloc * 2 : 60;
	ECNN(buffer = srealloc(buffer, alloc));
    }
    buffer[len++] = 0;

    return buffer;
}
