#include "readddb.h"
#include "stdio16.h"

int main(int argc, char **argv)
{
  if( argc == 2 ){
    init_charset();
    init_stdio16();
    showddb(readddb(argv[1]));
    return 0;
  } else {
    fprintf(stderr,"Invalid parameters\nUsage: nslshowddb <ddbfile>\n");
    return 1;
  }
}
