/* simple.c -- A model MArch application
   Duplicates the tag attribute from each word from a text
   paragraph in its content */

/* Input is an NSGML file */

#include "lt-memory.h"    /* For sfree */
#include "nsl.h"        /* Need this for the SHOULDNT macro */
#include "ctype16.h"
#include "string16.h"
#include "stdio16.h"
#ifdef macintosh
#include <console.h>
#endif

static void usage(int exitval)
{
    fprintf(stderr, "usage: simple [-he] [-d ddb-file] [-u base-url] [-t type-attr] [-w word-element] [-f format] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_Bit *bit;
  NSL_File inf=NULL, outf;
  NSL_Doctype dct=NULL;
  const Char *paraLabel,*wordLabel,*textLabel,*label,*tagAttr,*tagVal=NULL;
  char *ptr;
  Char buf[100];
  int in_para=0,in_text=0,arg=1,in_word=0,len;
  char *s;
  NSL_Common_Options *options;

  /* defaults for command line arguments */
  /* Name of attribute carrying tag -- set with -t */
  char* targ= (char *)"TYPE";
  /* Name of word element -- set with -w */
  char* warg= (char *)"W";
  /* Format string for word, tag -- set with -f */
  const char* textFormat="%S/%S";

#ifdef macintosh
argc = ccommand(&argv);
#endif
  /* Initialise the NSL API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 't':
	      if(arg+1 == argc)
		  usage(2);
	      targ=argv[++arg];
	      break;
	  case 'w':
	      if(arg+1 == argc)
		  usage(2);
	      warg=argv[++arg];
	      break;
	  case 'f':
	      if(arg+1 == argc)
		  usage(2);
	      textFormat=argv[++arg];
	      break;
	  default:
	      usage(2);
	  }
  }

  /* Open the specified file or standard input */

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf); 

  /* If we're reading nSGML, then case-folding upwards may have
     happened, so we need to case-fold our test strings */

  if (DocumentIsNSGML(dct)) {
    /* need upper case for attribute lookup */
    ptr=targ;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
    /* need upper case for tag lookup */
    ptr=warg;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
  };
  /* Open the output NSGML stream using the same doctype declaration */

  outf=SFFopen(stdout, dct, options->write_type, "stdout");

  /* Get the unique name of the elements we care about */

  textLabel=ElementUniqueName8(dct,"TEXT",4);
  paraLabel=ElementUniqueName8(dct,"P",1);
  wordLabel=ElementUniqueName8(dct,warg,0); /* length will be computed */
  tagAttr=AttrUniqueName8(dct,targ,0);
  
  /* Loop round reading components of the NSGML input text */

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_start_bit:
      /* note that the item value of this bit is of type inchoate,
	 meaning that unless you ItemParse on it, it's got
	 just the start tag info and no contents */
      if ((label=bit->label)==textLabel) {
	/* note that we're inside a text element */
	in_text=1;
      } else if (in_text &&
	       label==paraLabel) {
	/* note that we're inside a para inside text */
	in_para=1;
      } else if (in_para &&
	       label==wordLabel) {
	/* we've hit a word in a text para.  Note that and save the POS tags */
	in_word=1;
	tagVal=Strdup(GetAttrStringVal(bit->value.item,
				       tagAttr)); /* Save the tag(s) */
      }
      /* no matter what, fall through to print it out */
    case NSL_empty_bit:
      /* No point in comparing labels of empty items.
	 Note PrintItem is smart and will only print a start tag
	 for empty or inchoate items, but will get into a different state
	 depending on which */
      PrintItem(outf, bit->value.item);
      break;
    case NSL_text_bit:
      if (in_word) {
	/* strip trailing whitespace */
	len=Strlen(bit->value.body);
	while (is_xml_whitespace(bit->value.body[len-1])) {
	  bit->value.body[--len]='\000';
	}
	/* put out the word and the POS tag(s) */
	/* We use PrintText to keep the file output state up-to-date */
	Sprintf(buf, InternalCharacterEncoding, textFormat, 
		bit->value.body,tagVal);
	sfree((Char *)tagVal);
	PrintText(outf,buf);
      } else {
	/* text in some other context -- just print it */
	PrintText(outf, bit->value.body);
      }
      break;
    case NSL_end_bit:
      if (in_para) {
	if (bit->label==paraLabel) {
	  /* no longer in para */
	  in_para=0;		/* NOTA BENE assume no nested para's! */
	} else if (bit->label==wordLabel) {
	  /* no longer in word */
	  in_word=0;
	}
      }
      /* print it no matter what */
      PrintEndTag(outf,bit->label);
      break;
    default:
      SHOULDNT;
    }
    /* Bits are fixed but their contents are not freed
       unless we do it ourselves */
    FreeBit(bit);
  }
  /* at the very end we need . . . */
  SFclose(outf);
  return 0;
}
