/* sgsort.c	-- Henry Thompson Thu Apr 24 1997
 *
 * Usage: sgsort [-d ddbfile] domain elt key
 *
 * For each element of tag domain, sorts all daughters of tag elt
 * alphabetically by the contents of key, which must start with PCDATA
 *
 */

#ifndef lint
static const char *rcsid = "$Header: /export/cvsserver/cvsroot/ltg/LTXML/src/appl/sgsort.c,v 1.13 1999/07/12 18:16:32 richard Exp $";
#endif

/* Input is an NSGML file */

#include <stdlib.h>
#include "lt-memory.h"
#include "nsl.h"
#include "string16.h"
#include "ctype16.h"

typedef struct keyPair {
  const Char *kstr;
  NSL_Item *item;
} keyPair;

int keycmp(const void *k1,const void *k2) {
  return Strcmp(((const keyPair*)k1)->kstr,((const keyPair*)k2)->kstr);
}

static void usage(int exitval)
{
    fprintf(stderr, "usage: sgsort [-he] [-d ddb-file] [-u base-url] domain element key [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_Bit *bit;
  NSL_File inf=NULL, outf;
  NSL_Doctype dct=NULL;
  char *domLabel8=0,*eltLabel8=0;
  const Char *domLabel=0,*eltLabel=0;
  char buf[100],*ptr;
  NSL_Query qu;
  keyPair *kps=0,*kpp;
  int arg,nelts;
  NSL_Data *head,*dptr,*last,*next,*tail;
  const NSL_Data *found;
  NSL_Item *item,*xitem;
  NSL_Common_Options *options;

  /* Initialise the NSL API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      usage(2);
  }

  if(argc - arg < 3)
      usage(2);

  domLabel8=argv[arg++];
  eltLabel8=argv[arg++];
  sprintf(buf,".*/%s/#",argv[arg++]);

  /* Open the input NSGML file passing in doctype declaration if any */

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf); 
  if (DocumentIsNSGML(dct)) {
    ptr=domLabel8;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
    ptr=eltLabel8;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
  }
  /* if we didn't set it, will have been set by reading from file on opening */

  /* Open the output NSGML stream using the same doctype declaration */

  outf=SFFopen(stdout, dct, options->write_type, "stdout");

  /* Get the unique name of the elements we care about */

  domLabel=ElementUniqueName8(dct,domLabel8,0); /* length will be computed */
  eltLabel=ElementUniqueName8(dct,eltLabel8,0);
  qu=ParseQuery8(dct,buf);
  
  /* Loop round reading components of the NSGML input text */

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_start_bit:
      /* note that the item value of this bit is of type inchoate,
	 meaning that unless you ItemParse on it, it's got
	 just the start tag info and no contents */
      if (bit->label==domLabel) {
	ItemParse(inf,item=bit->value.item);
	for (nelts=0,head=0,next=0,last=0,tail=0,dptr=item->data;
	     dptr;
	     dptr=next) {
	  next=dptr->next;
	  found=0;
	  if (dptr->type==NSL_item_data &&
	      ((NSL_Item*)(dptr->first))->label==eltLabel
	      && RetrieveQueryData((NSL_Item*)dptr->first,qu,&found,FALSE)) {
	    dptr->next=head;
	    head=dptr;
	    nelts++;
	  }
	  else {
	    if (tail) {
	      tail->next=dptr;
	    }
	    else {
	      last=dptr;
	    };
	    dptr->next=0;
	    tail=dptr;
	  };
	};
	/* now we've got two data lists, one for elts at head
	   and one for the others at last */
	kps=tsalloc(keyPair,nelts);
	for (dptr=head,kpp=kps;dptr;kpp++,dptr=dptr->next) {
	  (*kpp).item=xitem=(NSL_Item*)(dptr->first);
	  found=0;
	  if (!RetrieveQueryData(xitem,qu,&found,FALSE)) {
	    SHOULDNT;
	  };
	  (*kpp).kstr=(const Char*)(found->first);
	};
	qsort((void*)kps,nelts,sizeof(keyPair),keycmp);
	/* put the sorted items back in the list */
	for (dptr=head,kpp=kps;dptr;kpp++,dptr=dptr->next) {
	  (dptr->first)=(void*)((*kpp).item);
	  tail=dptr;
	};
	sfree(kps);
	/* plug in the remnants */
	tail->next=last;
	/* and plug in the whole thing */
	item->data=head;
	PrintItem(outf,item);
	break;
      };
      /* fall through to print */
    case NSL_empty_bit:
    case NSL_text_bit:
    case NSL_end_bit:
      PrintBit(outf, bit);
      break;
    default:
      SHOULDNT;
    };
    /* Bits are fixed but their contents are not freed
       unless we do it ourselves */
    FreeBit(bit);
  };
  /* at the very end we need . . . */
  SFclose(outf);
  return 0;
}
