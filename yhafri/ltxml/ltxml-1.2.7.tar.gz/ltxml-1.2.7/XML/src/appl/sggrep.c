/* 	$Id: sggrep.c,v 1.46 1999/07/12 18:15:03 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sggrep.c,v 1.46 1999/07/12 18:15:03 richard Exp $";
#endif /* lint */
/* ============================================================== */
/* SGGREP    version 1.3                                          */
/* total manicure of 1.2 by Chris Brew                            */

/* Extended by David McKelvie                                     */
/* -mq <marker-query> and -mt <marker-query>                      */
/* to include sggrep-mark functionality                           */

/* -a <element-name> to allow wrapping output in a toplevel       */
/*                   element                                      */
/* ============================================================== */


#include "nsl.h"
#include "lt-memory.h"
#include "hsregexp.h"           
#include "string16.h"
#include "sggrep.h"


/* 
 * Internal details for SearchRequests
 */
 
 
 
struct SearchRequestRec {
    	 SgMatchSense matchSense;   				
/* sgNegativeMatch if sense of search inverted or sgPositiveMatch if not */
    	 SgReMatchType attrValAreRe;    			
  /* If sgMatchRe then attribute values in queries are
     regular expressions, if sgMatchString then they are just literal strings */
	 	int nlSep;              
  /* if TRUE add newline separator between every matched element  */
	 	
  const Char * 	topLevelString;   			
  const Char * 	markerTagString;       

  const char8 * 	queryString;     	
  const char8 * 	subQueryString; 
  const char8 * 	regexpString;
  const char8 * 	markerQueryString;

  const char8 * 	ddbFileString;
  const char8 * 	inputFileString;
  const char8 * 	outputFileString;
  int  	numSecondaryFiles;
  const char8 ** secondaryInputFiles;
  NSL_Doctype doctype;
  int read_type;
  int write_type;
  const char8 * base_url;
 };





/* the internal structure for Searches */
struct SearchRec {
  SgMatchSense match;         	    /* sgNegativeMatch if last item 
				       matched sgNegativeMatch if it didn't */
  NSL_File 		inf;        /* current input file */
  NSL_File 		outf;       /* the current output file */
  NSL_Doctype 	docType;            /* the doctype */
  int		readType;	    /* type for SFopen */
  int           writeType;
  NSL_Query 	markerQuery;        /* marker query - if used */
  NSL_ElementSummary markSummary;  /*  the summary of the element for the marker */
  NSL_Query 	query;              /* the top level query */
  NSL_Query  	subQuery;           /* the sub-query */                   
  regexp *   	regExp;        	    /* the regular expression which must 
				       match */
  SearchRequest request;       	    /* the request which I am answering */
};


static void PrintTopLevelTag(NSL_File f, const Char * s, int start);

static SearchRequest theRequest=0;

static void usage(int exitval)
{
    fprintf(stderr, "usage: \n\
\n\
   sggrep [<options>] -q query [ -s sub-query] [-t regexp] file... \n\
     or\n\
   sggrep [<options>] query [[sub-query] regexp] [[--] file...] \n\
\n\
   query:  pattern on items to select, basically path based with terms \n\
     separated by /, <term>:=<GI><cond>?'*'? \n\
                     <GI>:=<elementName>|'.' \n\
		     <cond>:='['<index>|<atests>|<index> <atests>']' \n\
		     <index>:=<number> \n\
		     <atests>:=<atest>(' '<atest>)* \n\
		     <atest>:=<aname>( ['='|'!='] <aval> )? \n\
     Aname and aval are as per SGML, except that if the -r flag is given,  \n\
     aval are regular expressions. \n\
     A GI of . matches any tag.  A condition with an index matches only the \n\
     index'th sub-element of the enclosing element.  Attribute tests are not \n\
     exhaustive, and will match against both explicitly present and defaulted \n\
     attribute values, using string equality.  Bare anames are satisfied by \n\
     ANY value, explicit or defaulted.  Terms ending with * match \n\
     any number of links in the chain, including 0. \n\
\n\
   sub-query:  if present, selects sub-elements of query-selected item for \n\
               regexp to match \n\
\n\
   regexp:  Regular expression to match against text directly contained in \n\
            query-selected item (if no sub-query) or in any sub-query selected \n\
	    sub-element of query-selected item. \n\
            If empty (i.e. '') matches anything, including empty elements, \n\
            indeed this is the ONLY way to get empty elements if required. \n\
\n\
When using the second, terse, form, the '--' is required unless both regexp and \n\
sub-query are provided. \n\
\n\
Other options:\n"
"  -d ddb-file:  Take Dtd from specified ddb file \n"
"  -e: don't expand entities\n"
"  -o out-file: Put output to specified file \n"
"  -v: invert sense of sub-query+regexp \n"
"  -n: don't force a newline between output matches \n"
"  -r: attribute values in queries are regular expressions \n"
"\n"
"  -mq mark-query: is an NSL query which tells us which subelements of \n\
                  elements matching <query> are going to be 'marked'. \n\
                  Sub-elements matching <mark-query> are 'marked' if they \n\
                  in turn contain a sub element which matches \n\
                  <sub-query> which includes text matching <regexp> \n\
                  mt must be specified if mq is \n"
"  -mt mark-tag:  indicates which tag is to be used to wrap the marked elements.\n\
 \n"
"  -a element-name: Give an element name to act as a toplevel element \n\
                    in which matching elements will be embedded. \n\
                    (in NSL mode this tag must be in the DTD) \n\
");
    if (theRequest) {
      FreeRequest(theRequest);
    };
    exit(exitval);
}

/*
 Allocate a search request with all the default values
 */


SearchRequest  NewSearchRequest(void) {

	SearchRequest req = malloc(sizeof(struct SearchRequestRec));
	SetMatchSense(req,sgPositiveMatch);
  	SetAttrValAreRe(req,sgMatchString);
  	SetNewlineSep(req,TRUE);
  	SetTopLevelString(req,NULL);
  	SetQueryString(req,NULL);
  	SetSubQueryString(req,".");
  	SetRegexpString(req,"");
  	SetMarkerQueryString(req,NULL);
  	SetMarkerTagString(req,NULL);
  	SetDdbFileString(req,NULL);
  	SetOutputFileString(req,NULL);
  	SetInputFileString(req,NULL);
  	SetSecondaryInputFiles(req,0,NULL);
  	
  	return req;

}

/*
Set up a search request from a command-line style interface.
*/

void InitSearchRequestFromArgcArgv (SearchRequest theRequest,
				    int argc,char8 * argv[],
				    NSL_Common_Options *options) {
  int arg,switch_done=0;
  char *s;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-' || switch_done)
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 'q':
	      /* The main query */
	      if(arg+1 == argc) usage(1);
	      SetQueryString(theRequest,argv[++arg]);
	      break;
	  case 's':
	      /* The sub query (must specify -r before this if wanted) */
	      if(arg+1 == argc) usage(1);
	      SetSubQueryString(theRequest,argv[++arg]);
	      break;
	  case 't':
	      /* The text regular expression */
	      if(arg+1 == argc) usage(1);
	      SetRegexpString(theRequest,argv[++arg]);
	      break;
	  case 'm':
	      /* The marker query mq or the marker tag mt */
	      if(arg+1 == argc) usage(1);
	      switch(s[1]) 
		{
		case 'q':
		  ++s;		  
		  SetMarkerQueryString(theRequest,argv[++arg]);
		  break;

		case 't':
		  ++s;
		  SetMarkerTagString(theRequest,argv[++arg]);
		  break;

		default:
		  usage(1);
		  break;
		}

	      break;
	  case 'a':
	      /* The optional top-level element */
	      if(arg+1 == argc) usage(1);
	      SetTopLevelString(theRequest,argv[++arg]);
	      break;
	  case 'o':
	      if(arg+1 == argc) usage(1);
	      SetOutputFileString(theRequest,argv[++arg]);
	      break;
	  case 'd':
	      if(arg+1 == argc) usage(1);
	      SetDdbFileString(theRequest,argv[++arg]);
	      break;
	  case 'v':
	      SetMatchSense(theRequest,sgNegativeMatch); 
	      break;
	  case 'n':
	      SetNewlineSep(theRequest,FALSE);
	      break;
	  case 'r':
	      SetAttrValAreRe(theRequest,sgMatchRe);
	      break;
	  case '-':
	    switch_done=1;
	    break;
	  default:
	      usage(1);
	      break;
    }
  }
  if(theRequest->markerTagString == NULL && theRequest->markerQueryString != NULL) usage(1);
  if(theRequest->markerTagString != NULL && theRequest->markerQueryString == NULL) usage(1);
  if (theRequest->queryString==NULL) {
    const char *firsta;
    if (switch_done) usage(1);
    /* No -q option, so this is an old style command list (for
       backward compatibility ) */
    if (argc<arg+1 ||
	(argv[arg][0]=='-' && argv[arg][1]=='-' && argv[arg][2]=='\0')) {
      fprintf(stderr,"[-q] query required, but missing\n");
      usage(3);
    }
    SetQueryString(theRequest,argv[arg++]);
    if (arg<argc &&
	!(argv[arg][0]=='-' && argv[arg][1]=='-' && argv[arg][2]=='\0')) {
      firsta=argv[arg++];
      if (arg<argc &&
	  !(argv[arg][0]=='-' && argv[arg][1]=='-' && argv[arg][2]=='\0')) {
	/* two additional arguments, sub and reg */
	SetSubQueryString(theRequest,firsta);
	SetRegexpString(theRequest,argv[arg++]);
      }
      else {
	/* one add'l arg, reg, sub defaults */
	SetSubQueryString(theRequest, ".");
	SetRegexpString(theRequest, firsta);
      };
    }
    else {
      /* no add'l args, default both */
      SetSubQueryString(theRequest,".");
      SetRegexpString(theRequest, "");      
    };
    if (arg<argc &&
	argv[arg][0]=='-' && argv[arg][1]=='-' && argv[arg][2]=='\0') {
      arg++;
    };
  };

  theRequest->doctype = options->doctype;
  theRequest->base_url = options->base_url;
  theRequest->read_type = options->read_type;
  theRequest->write_type = options->write_type;

  /* Whether new or old the rest of the
     command line args are file names */
  if( arg < argc ){
    SetInputFileString(theRequest,argv[arg++]);
  }


  SetSecondaryInputFiles(theRequest,argc-arg,(const char **)argv+arg);
}


/* implementation of the public interface to match requests */

void  SetNewlineSep (SearchRequest req,int newlinesWanted) {
  req->nlSep = newlinesWanted;
}
	
void  SetMatchSense (SearchRequest req, SgMatchSense matchSense) {
  req->matchSense = matchSense;
}
	
void  SetAttrValAreRe (SearchRequest req, SgReMatchType attrValAreRe){
  req->attrValAreRe = attrValAreRe;
}
	
void  SetTopLevelString (SearchRequest req,const char8 * topLevelString){
   req->topLevelString = topLevelString ?
    strdup_char8_to_Char(topLevelString) : NULL; 
}

void  SetQueryString (SearchRequest req,const char8 * queryString){
  req->queryString = queryString;
}
	
void  SetSubQueryString (SearchRequest req,const char8 * subQueryString){
  req->subQueryString = subQueryString;
}
	
void  SetRegexpString (SearchRequest req,const char8 *regexpString){
  req->regexpString = regexpString;
}
	
void  SetMarkerQueryString (SearchRequest req,
			    const char8 *markerQueryString){
  req->markerQueryString = markerQueryString;

}

void  SetMarkerTagString (SearchRequest req,
			    const char *markerTagString){
  req->markerTagString = markerTagString ?
                               strdup_char8_to_Char(markerTagString) : NULL;
}


void  SetDdbFileString (SearchRequest req,const char * ddbFileString){
  req->ddbFileString = ddbFileString;
}
	
void  SetOutputFileString (SearchRequest req, 
			   const char * outputFileString){
  req->outputFileString = outputFileString;
}

void  SetInputFileString (SearchRequest req, 
			  const char * inputFileString){
  req->inputFileString = inputFileString;
}
	
void   SetSecondaryInputFiles (SearchRequest req,int numSecondaryFiles,
			       const char ** inputFileStrings){ 
  req->numSecondaryFiles = numSecondaryFiles;
  req->secondaryInputFiles = inputFileStrings;
}



/*
 * OpenSearchOutput
 * In the ordinary way of things 
 * we only do this once we have a definite need to print stuff out.
 * In the case that no match is found, no output occurs. But if
 * passed the -a elementname option, the output will always be 
 * an XML file whose (single) root is an <elementname> element.
 * In NSL mode the -a elementname must refer to an element type
 * which is present in the DTD
 */

static void OpenSearchOutput(Search theSearch) {
  if(theSearch->request->outputFileString == NULL) {

     theSearch->outf=SFFopen(stdout, 
			     theSearch->docType, 
			     theSearch->writeType,
			     "<stdout>");
  } else {
    theSearch->outf=OpenURL(theSearch->request->outputFileString,
			    theSearch->docType, 
			    theSearch->writeType,
			    CE_unknown, 0);
  }

  if(theSearch->outf == NULL) {
    fprintf(stderr,"Couldn't open output file\n");
    SHOULDNT;
  }

  /* If -a elementName specified then print out a start tag */
  if(theSearch->request->topLevelString != NULL)
    PrintTopLevelTag(theSearch->outf,theSearch->request->topLevelString,TRUE);
}	
	
static void CompileRegexpString(Search theSearch,const char8 *RegexpString) {
  /* check for empty regexp meaning "anything at all" *
   *  - in which case needn't really do matching      */
  theSearch->regExp=strlen(RegexpString)==0 ? NULL : hsregcomp(RegexpString);
}
  
  
/* Add a new item (whose unique name is in theSearch->request->markerTag)
 *  which contains titem as its only content,
 *  and whose parent is titem's old parent 
 */

static void addMarkerAbove(NSL_Item *titem, Search theSearch){
  const Char * label = theSearch->request->markerTagString;
  int len = Strlen(label);
  NSL_Item * markerItem,*parent;
  NSL_Data *data;
  
   markerItem = NewNullNSLItem(theSearch->docType,
					theSearch->request->markerTagString,
					len);
   
   parent = ParentItem(titem);

   for(data = parent->data; data != NULL; data= data->next)
     if(data->type == NSL_item_data && data->first == titem) {
       data->first = markerItem;
       markerItem->in = data;
       AddItemToEnd(markerItem,titem);
       return;
     }
   
 
}

/* NextSearchMarkItem - find items matching Query, MatchQuery,
   SubQuery, Regexp.  modify such items so that every subitem of item
   which matches MatchQuery, SubQuery, Regexp, is included in a
   <MARKER> element.  */

static NSL_Item * NextSearchMarkItem(Search theSearch) {
  NSL_Item *titem=NULL, *ttitem;
  NSL_Data *dpt;
  NSL_Item * item  = GetNextQueryItem(theSearch->inf, theSearch->query, NULL);
  int modify;


  theSearch->match = sgNegativeMatch;

  /* For each subitem which matches the marker query */

  while( ( titem=RetrieveQueryItem(item, theSearch->markerQuery, titem) )){
    modify = FALSE;
    /* Can we find the necessary stuff inside the marked element? */
    ttitem = NULL;
    while( !modify && ( ttitem=RetrieveQueryItem(titem, theSearch->subQuery,
						 ttitem) ) ){
      if (theSearch->regExp == NULL) {
	/* empty regular expression meaning anything */
	modify=TRUE;
	break;
      } else {
	for(dpt=ttitem->data; dpt; dpt=dpt->next){
	  if(dpt->type==NSL_text_data) {
	    char8 *text = strdup_Char_to_char8(dpt->first);
	    if (hsregexec(theSearch->regExp,text)) {
	      sfree(text);
	      modify = TRUE;
	      break;
	    }
	    sfree(text);
	  }
	}
      }
    } /* while subquery item */
    if( modify ){
	/* We found the sub item that we were looking for */
	/* enclose it in a MARKER element */
	theSearch->match = sgPositiveMatch;
	addMarkerAbove(titem,theSearch);
    }
  } /* while marker query item */
  return item;
}

/* NextSearchItem -- returns next putative match, setting the
   match flag according to match status of sub-item. Whether
   we really print the enclosing item depends on the sense of
   the sub-comparison. If the comparison is as usual then all
   enclosing items with a matching sub-item are printed.
   If it is negated all items with no matching sub-item are
   printed.

*/



static NSL_Item * NextSearchItem(Search theSearch) {
  NSL_Item *titem=NULL;
  NSL_Data *dpt;
  NSL_Item * item  = GetNextQueryItem(theSearch->inf, theSearch->query, NULL);


  if( theSearch->markerQuery ){
    return NextSearchMarkItem(theSearch);
  } else {
    titem = NULL;
    theSearch->match = sgNegativeMatch;
    while(!theSearch->match) {
      titem=RetrieveQueryItem(item, theSearch->subQuery, titem);
      if(titem==NULL) {
	break;
      } else if (!theSearch->regExp) {
	/* empty regular expression meaning anything */
	theSearch->match=sgPositiveMatch;
	break;
      } else {

	for(dpt=titem->data; dpt; dpt=dpt->next){
	 if(dpt->type==NSL_text_data) {
	    char8 *text = strdup_Char_to_char8(dpt->first);
	    if (hsregexec(theSearch->regExp,text)) {
	      sfree(text);
	      theSearch->match=sgPositiveMatch;
	      break;
	    }
	    sfree(text);
	  }
	}
      }
    }
    return item;
  }
}

/* MaybePrintMatchedItem is called on all items, with a flag set
   in the search which indicates whether the sub-query and the regexp
   succeeded. It opens the output file only when needed.
 */

static void MaybePrintMatchedItem(Search theSearch,NSL_Item * item) {

  if (theSearch->match == theSearch->request->matchSense) {
    if(theSearch->outf == NULL) {
      OpenSearchOutput(theSearch);
    }
    PrintItem(theSearch->outf, item);
    if (theSearch->request->nlSep) {
      ForceNewline(theSearch->outf);
    }
  }
}



/* Print start/end tags for element called s, to get round LTXML's 
   treatment of '<' and '>' ???? */

static void PrintTopLevelTag(NSL_File f, const Char * s, int start){
 if(start)
   PrintStartTag(f,s);
 else
   PrintEndTag(f,s);

  
}


/* iterator for input files */
static const char * NextInputFile(SearchRequest theRequest) {
  const char * inputFile;

  if(theRequest-> numSecondaryFiles == 0) {
    return NULL;
  } else {
    inputFile = *theRequest->secondaryInputFiles;
    theRequest->numSecondaryFiles--;
    theRequest->secondaryInputFiles++;
    return inputFile; 
  }
}
	
	
static Search NewSearch(void) {
  Search theSearch = malloc(sizeof(struct SearchRec));
	
  theSearch->markerQuery = NULL;
  theSearch->inf = NULL;            /* current input file */
  theSearch->outf = NULL;           /* the current output file */
  theSearch->docType = NULL;        /* the doctype */
  theSearch->markerQuery = NULL;    /* marker query - if used */
  theSearch->query = NULL;          /* the top level query */
  theSearch->subQuery = NULL;       /* the sub-query */                   
  theSearch->regExp = NULL;         /* the regular expression which 
				       must match */
  theSearch-> request = NULL;       /* the request which I am answering */
  return theSearch;
}

/*
 * Subroutine for organizing the data used for the sggrep-mark functionality
 */

static int SetUpMarkerQueries(SearchRequest theRequest,Search theSearch)
{
    NSL_ElementSummary sum;
    int len = Strlen(theRequest->markerTagString);
  
    if((sum = FindElementAndName(theSearch->docType,
				 &(theRequest->markerTagString),
				 len)) == NULL) {
      /* this only happens with NSL documents */
      /* because in XML we are allowed to declare extra attributes */
      Fprintf(Stderr,"You must provide a marker which is in the DTD (found %S)\n",theRequest->markerTagString);

      return -1;
    }
      
    theSearch->markSummary = sum;


    if( theRequest->attrValAreRe == sgMatchRe){
      theSearch->markerQuery=ParseQueryR8(theSearch->docType,
					 theRequest->markerQueryString);
    } else {
      
      theSearch->markerQuery=ParseQuery8(theSearch->docType,
					theRequest->markerQueryString);
    }
    return 0;
}

/* Open a search from a request */

Search SGGOpen (SearchRequest theRequest) {
  Search theSearch = NewSearch();
#ifdef SGGREP_ENGINE_ONLY
  static int inited = 0;
  if(!inited) {
    NSLInit(0);
    inited = 1;
  }
#endif
	
  CompileRegexpString(theSearch,theRequest->regexpString);

  theSearch->docType = theRequest->doctype;
  theSearch->readType = theRequest->read_type;
  theSearch->writeType = theRequest->write_type;
 

  /* open input file possibly from stdin */

  if(theRequest->inputFileString == NULL) {
    theSearch->inf=SFFopen(stdin, theSearch->docType, theSearch->readType, theRequest->base_url);
  } else {
    theSearch->inf=OpenURL(theRequest->inputFileString,
			  theSearch->docType, theSearch->readType, CE_unknown, 0);
  }

  theSearch->docType=DoctypeFromFile(theSearch->inf);

  if( theRequest->attrValAreRe ==  sgMatchRe){
    theSearch->query=ParseQueryR8(theSearch->docType,theRequest->queryString);
    theSearch->subQuery=ParseQueryR8(theSearch->docType,
				    theRequest->subQueryString);
  } else {
    theSearch->query=ParseQuery8(theSearch->docType,theRequest->queryString);
    theSearch->subQuery=ParseQuery8(theSearch->docType,
				   theRequest->subQueryString);
  }


  
  if( theRequest->markerQueryString != NULL)
    if(SetUpMarkerQueries(theRequest,theSearch) != 0)
      return NULL;


  theSearch->request = theRequest;

  /* If the -a option has been used, we always
   * produce a file with a single root. 
   * Without this option we may produce no output whatsoever
   */

  if(theRequest->topLevelString) {
    OpenSearchOutput(theSearch);
  }

  return theSearch;

}



/* actually do the search -- the first input file has been opened, and the
  doctype established
 */

void SGGSearch(Search theSearch) {
    NSL_Item *item;
    const char * nextFile;
    
    

  /* Process the first input file */

  while((item=NextSearchItem(theSearch)) !=NULL) {
    MaybePrintMatchedItem(theSearch,item);
    FreeItem(item);
  }

  /* If required, process the rest of the input files */
  
  while((nextFile = NextInputFile(theSearch->request)) != NULL) {
    SFrelease(theSearch->inf,FALSE);
     /* NB We assume that subsequent files have the same DTD as the first */
     /* perhaps we shouldn't assume this -- another switch? */
    theSearch->inf = SFopen(nextFile,theSearch->docType,theSearch->readType);
   
    while((item=NextSearchItem(theSearch)) !=NULL) {
	MaybePrintMatchedItem(theSearch,item);
	FreeItem(item);
      }
   }
   
 /* remaining input file will be released during SGGClose */ 
  
  /* If -a elementName specified then print out an end tag */
  
  if( (theSearch->outf != NULL) && theSearch->request->topLevelString ){
    if(theSearch->request->nlSep) {
      ForceNewline(theSearch->outf);
      ForceOutput(theSearch->outf);
    }
    PrintTopLevelTag(theSearch->outf,theSearch->request->topLevelString,FALSE);
  }
}

/*  clean up after a search -- all files are done.
 *  We try very hard not to de-allocate anything 
 *  unless we are very sure we allocated it. In a
 *  sane world some of these if's are redundant,
 *  but they are left in for safety.
 */

void SGGClose(Search theSearch) {

  if(theSearch->regExp)
    free(theSearch->regExp);
    
  if( theSearch->markerQuery)
    FreeQuery(theSearch->markerQuery);	
    
  if(theSearch->subQuery) 
  	FreeQuery(theSearch->subQuery);
  	
  if(theSearch->query) 
  	FreeQuery(theSearch->query);
  	
  if(theSearch->inf)	
  	SFrelease(theSearch->inf,FALSE);	
  	
  if(theSearch->outf)
  	SFrelease(theSearch->outf,FALSE);
  
  if(theSearch->docType) 
        FreeDoctype(theSearch->docType);
  	
  if(theSearch->request)	
  	FreeRequest(theSearch->request);
  		
  free(theSearch);
  /* NSLClose(); */
}


void FreeRequest(SearchRequest theRequest) {
  free(theRequest);
}


#ifndef SGGREP_ENGINE_ONLY
int main(int argc,char**argv) {
  Search theSearch;
  NSL_Common_Options *options;

  NSLInit(0);


  options = NSLGetoptions(&argc, argv, "hdeu", usage);
  theRequest=NewSearchRequest();
  InitSearchRequestFromArgcArgv(theRequest,argc,argv,options);
  if ((theSearch = SGGOpen(theRequest)) != NULL) {
    SGGSearch(theSearch);		
    SGGClose(theSearch);
  }
  else {
    FreeRequest(theRequest);
  };
  return 0;
}
#endif


