/* intersect - 
   Program which takes a set of nSGML files, each of which is a
   sequence of top level elements (e.g. output of sggrep ), and
   outputs a set of those which intersect

   NB We need to do this with times - so that we can compare data 
   from the two speakers
*/

#include "nsl.h"
#include "nslfile.h"
#include "string16.h"
#include "hsregexp.h"
#include "lt-memory.h"
#include <math.h>
#include <stdlib.h>

#define MAX_NO_FILES 32
#define INFINITY 100000000

static int no_of_input_files = 0 ;
static int count_hits = 0;               /* Number of intersections found */
static int output_count  = 0;            /* Whether to output count */
static int output_full  = 0;             /* Whether to output elements */

static void read_control_file(char *control_file, NSL_Doctype dct);

NSL_File cf, outf;

char8 *transbuf;
#define Chartochar8(s) Char_to_char8((s), transbuf)

NSL_File stream[MAX_NO_FILES];
NSL_Query query[MAX_NO_FILES],
          subquery[MAX_NO_FILES];
regexp * rexp[MAX_NO_FILES];
double startpt[MAX_NO_FILES],
       endpt[MAX_NO_FILES];
const Char * startAttr[MAX_NO_FILES],
           * durAttr[MAX_NO_FILES],
           * endAttr[MAX_NO_FILES];
Char * id[MAX_NO_FILES];
int  elcount[MAX_NO_FILES];
NSL_Item * current_item[MAX_NO_FILES];

char *filename[MAX_NO_FILES], *regexpstr[MAX_NO_FILES], *filter[MAX_NO_FILES];
Char *querystr[MAX_NO_FILES], *subquerystr[MAX_NO_FILES],
       *startattrname[MAX_NO_FILES], *durattrname[MAX_NO_FILES], 
       *endattrname[MAX_NO_FILES];


int     find_earliest ( void );
boolean lessthan (double e1, double e2);
void    intersect ( void );
boolean read_element ( int i );

static void usage(int exitval)
{
    fprintf(stderr,
	    "usage: intersect [-c] [-f] [-D control_ddb_file] [control_file]\n");
    exit(exitval);
}

struct strings {
    const char *file, *query, *subquery, *regexp, *start, *dur, *end, *filter;
    const char *file_query;
    const char *file_format, *count_format;
    const char *intersect_format, *endintersect_format;
    const char *span_format, *endspan_format;
    const char *spanlink_format, *closespanlink_format;
    const char *subspan_format, *endsubspan_format;
    const char *id_format;
} *strings;

struct strings xml_strings = {
    "file", "query", "subquery", "regexp", "start", "dur", "end", "filter",
    ".*/file",
    "<file id='id.%d' file=\"%s\" query=\"%S\" subquery=\"%S\" regexp=\"%s\" start=\"%S\" end=\"%S\" dur=\"%S\" filter=\"%s\"/>\n",
    "<count n='%d'/>\n",
    "<intersect>\n", "</intersect>\n",
    "<span from='%.4f' dur='%.4f' wfrom='%.4f' wdur='%.4f'>\n", "</span>\n",
    "<span from=%.4f dur=%.4f wfrom=%.4f wdur=%.4f links='", "'/>\n",
    "<subspan n='%d' from='%.4f' dur='%.4f'>\n", "</subspan>\n",
    "id.%d.%d"
};

struct strings nsgml_strings = {
    "FILE", "QUERY", "SUBQUERY", "REGEXP", "START", "DUR", "END", "FILTER",
    ".*/FILE",
    "<FILE ID=ID.%d FILE=\"%s\" QUERY=\"%S\" SUBQUERY=\"%S\" REGEXP=\"%s\" START=\"%S\" END=\"%S\" DUR=\"%S\" FILTER=\"%s\">\n",
    "<COUNT N=%d>\n",
    "", "",
    "<SPAN FROM=%.4f DUR=%.4f WFROM=%.4f WDUR=%.4f>\n", "</SPAN>\n",
    "<SPAN FROM=%.4f DUR=%.4f WFROM=%.4f WDUR=%.4f LINKS=", ">\n",
    "<SUBSPAN N=%d FROM=%.4f DUR=%.4f>\n", "</SUBSPAN>\n",
    "ID.%d.%d"
};

int main(int argc, char **argv) {

  NSL_Doctype dct=NULL;
  int arg;
  char *s;
  NSL_Common_Options *options;
#ifdef HAVE_POPEN
  FILE *fp[MAX_NO_FILES];
#endif
  int i;

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hD", usage);

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 'c':
	      output_count = 1;
	      break;
	  case 'f':
	      output_full = 1;
	      break;
	  default:
	      usage(2);
	  }
  }

  if(argc - arg > 1)
      usage(2);

  /* Read the control file */

  read_control_file(argc > arg ? argv[arg] : 0, options->aux_doctype);

  /* Open each of the input files */

  for(i=0; i < no_of_input_files; i++) {
    if( filter[i][0] ){
#ifdef HAVE_POPEN
      char command[1000];
      command[0] = 0;
      strcat(command,filter[i]);
      strcat(command," ");
      strcat(command,filename[i]);
      fp[i] = popen(command,"r");
      if( fp[i] ){
	stream[i] = SFFopen(fp[i],NULL,NSL_read,command);
      }
#else
      Fprintf(Stderr, "Error: popen() not available so filters not allowed\n");
      return 5;
#endif
    } else {
      stream[i] = SFopen(filename[i], NULL, NSL_read);
    }

    if(!stream[i]){
      return 5;
    }

    dct = DoctypeFromFile(stream[i]);
    query[i]    = ParseQuery(dct,querystr[i]);
    subquery[i] = ParseQuery(dct,subquerystr[i]);
    /* check for empty regexp meaning anything */
    rexp[i] =strlen(regexpstr[i])==0?0:hsregcomp(regexpstr[i]);
    startAttr[i] = AttrUniqueName(dct,startattrname[i],0);
    durAttr[i]   = AttrUniqueName(dct,durattrname[i],0);
    endAttr[i]   = AttrUniqueName(dct,endattrname[i],0);

    if( ! read_element(i) ) {
	/* Then one of the files contains NO elements
	   and hence there can be NO complete intersections
	   So, we can just return now */
	Fprintf(Stderr,
		"intersect WARNING: File %s contained NO elements matching '%S' '%S' '%s'\n",
		filename[i],querystr[i],subquerystr[i],regexpstr[i]);
	if( output_count ) {
	    Fprintf(((NSL_File_I*)outf)->file16, strings->count_format, 0);
	}
	Fprintf(((NSL_File_I*)outf)->file16, strings->endintersect_format);
	SFclose(outf);
	return 0;
    }
  }

  /* Main Loop */

  while( 1 ){
    /* Find an intersection if there is one */
    intersect();
    /* Find the element which has the earliest end point */
    i = find_earliest();
    if( ! read_element(i) ){
      /* Then one of the files contains NO more elements
	 and hence there can be NO more complete intersections
	 So, we can just return now */
      break;
    }
  }

  /* Close input files */

  for(i=0; i < no_of_input_files; i++){
    SFclose(stream[i]);
#ifdef HAVE_POPEN
    if( filter[i][0] ){ pclose(fp[i]); }
#endif
  }
  SFclose(cf);
  if( output_count ) {
      Fprintf(((NSL_File_I*)outf)->file16, strings->count_format, count_hits);
  }
  Fprintf(((NSL_File_I*)outf)->file16, strings->endintersect_format);
  SFclose(outf);
  return 0;
}

/* Find the element with the earliest end point
   and return its index */

int find_earliest ( void ) {
  int i, res=-1;
  double e, end = INFINITY ;
  for(i=0; i < no_of_input_files; i++){
    e = endpt[i];
    if( lessthan(e,end) ){ end = e; res = i; }
  }
  return res;
}

/* Compare start/end points */

/* It's possible that rounding errors in earlier processing may have 
   produced numbers that ought to be the same but aren't, so require at
   least FUZZ difference. */

#define FUZZ (1e-6)

boolean lessthan (double e1, double e2){
    return e1 < e2 - FUZZ;
}

/* If there is an intersection, then generate SGML for it */

void intersect ( void ) {
  int i ;
  double s, e, start = - INFINITY, end = INFINITY, 
         estart = INFINITY, lend = - INFINITY, dur, edur ;

  /* Find the latest start point(start) and the earliest end point(end) */
  /* Also the earliest start point(estart) and the latest end point(lend) */

  for(i=0; i < no_of_input_files; i++){
    s = startpt[i];
    e = endpt[i];
    if( lessthan(start,s)) { start = s; }
    if( lessthan(s,estart)){ estart = s; }
    if( lessthan(e,end))   { end   = e; }
    if( lessthan(lend,e))  { lend  = e; }
  }
  if( lessthan(start,end) ){
    /* We have got a match */
    count_hits += 1;
    /* Print summary only */
    dur  = end  - start;
    edur = lend - estart;

    /* <SPAN> element; FROM/DUR is the intersection period;
       WFROM/WDUR is the union period */

    if( output_full ){ 
      /* If full output then we print SUBSPAN content */
	Fprintf(((NSL_File_I*)outf)->file16, strings->span_format,
		start,dur,estart,edur);
      for(i=0; i < no_of_input_files; i++){
	Fprintf(((NSL_File_I*)outf)->file16, strings->subspan_format,
		i,startpt[i],endpt[i]-startpt[i]);
	PrintItem(outf,current_item[i]);
	Fprintf(((NSL_File_I*)outf)->file16, "\n");
	Fprintf(((NSL_File_I*)outf)->file16, strings->endsubspan_format);
      }
      Fprintf(((NSL_File_I*)outf)->file16, strings->endspan_format);
    } else {
	/* If NOT full output then we add conref LINKS attribute */
	Fprintf(((NSL_File_I*)outf)->file16, strings->spanlink_format,
		start,dur,estart,edur);
	for(i=0; i < no_of_input_files; i++){
	    Fprintf(((NSL_File_I*)outf)->file16,"%S ",id[i]);
	}
	Fprintf(((NSL_File_I*)outf)->file16, strings->closespanlink_format);
    }
  }
}

/* Read an SGML element which matches the query and extract 
   start, end, and id */

boolean read_element ( int i ){
  static NSL_Data holder={0,NSL_item_data,NULL,NULL,NULL};
  NSL_Data *dpt;
  boolean print,  found = FALSE, neg = FALSE;
  NSL_Item *item, *titem;
  const Char * startStr, * durStr = NULL, * endStr = NULL;

  if( current_item[i] ){ FreeItem(current_item[i]); }

  /* Skip until we reach a matching element */

  while( ( item=GetNextQueryItem(stream[i], query[i], NULL) ) ){

    holder.first=item;
    item->in=&holder;
    for(titem=NULL, print=FALSE; !print;) {
      titem=RetrieveQueryItem(item, subquery[i], titem);
      if(titem==NULL) {
	break;
      } else if (!rexp[i]) {
	/* this is efficient and allows e.g. empty elements to match */
	print=TRUE;
	break;
      } else {
	for(dpt=titem->data; dpt; dpt=dpt->next){
	  if(dpt->type==NSL_text_data) {
	    if (hsregexec(rexp[i],Chartochar8(dpt->first))) {
	      print=TRUE;
	      break;
	    }
	  }
	}
      }
    }
    if( ( print && !neg ) || neg ) {
      /* We have found a matching item -
	 extract startpt, endpt and id attributes */
      if( ( startStr = GetAttrStringVal(item,startAttr[i]) ) ){
	startpt[i] = atof(Chartochar8(startStr));
      } else {
	/* If no startpoint given */
	startpt[i] = - INFINITY ;
      }
      if( ( endStr = GetAttrStringVal(item,endAttr[i]) ) ){
	/* End point given */
	endpt[i] = atof(Chartochar8(endStr));
      } else if( ( durStr = GetAttrStringVal(item,durAttr[i]) ) ){
	/* Duration given */
	endpt[i] = startpt[i] + atof(Chartochar8(durStr));
      } else {
	/* If no dur attribute given - assume zero duration */
	endpt[i] = startpt[i];
      }
      sfree(id[i]);		/* free the old value */
      if( ! ( id[i] = GetIdVal(item) ) ){
	  /* If no ID attribute given */
	  id[i] = (Char *)salloc(255);
	  Sprintf(id[i], InternalCharacterEncoding, strings->id_format,
		  i, ++elcount[i]);
      } else {
	  id[i] = Strdup(id[i]);
      }
      found = TRUE;
      current_item[i] = item;
      break;
    }
    FreeItem(item);
  }
  return found;
}

const char8 *control_dtd = 
"<!DOCTYPE intersect [\n"
" <!ELEMENT intersect (file*)>\n"
" <!ELEMENT file EMPTY>\n"
" <!ATTLIST file\n"
"           id		ID	#IMPLIED\n"
"           file	CDATA	#REQUIRED\n"
"           query	CDATA	'.*'\n"
"           subquery	CDATA	'.'\n"
"           regexp	CDATA	'' \n"
"           start	CDATA	'start'\n"
"           dur		CDATA	'dur'\n"
"           end		CDATA	'end' \n"
"           filter      CDATA   #IMPLIED>\n"
"]>\n"
"<intersect/>\n";

static void read_control_file(char *control_file, NSL_Doctype dct)
{
    NSL_File cfdtd;
    NSL_Query qu;
    NSL_Item *item;
    const Char *fileAttr, *queryAttr, *subqueryAttr, *regexpAttr,
	       *startAttrAttr, *durAttrAttr, *endAttrAttr, *filterAttr;


    /* Get the (XML) doctype if user didn't specify one */

    if(!dct)
    {
	cfdtd = OpenString(strdup_char8_to_Char(control_dtd), 0, NSL_read);
	dct = DoctypeFromFile(cfdtd);
	SFclose(cfdtd);
    }

    /* Open the control file, either an argument or stdin */

    if(control_file) 
    {
	if(!(cf = SFopen(control_file, dct, NSL_read|NSL_read_validate))) {
	    Fprintf(Stderr, "Can't open %s for reading\n",control_file);
	    exit(2);
	}
    } else {
	if(!(cf = SFFopen(stdin, dct, NSL_read|NSL_read_validate,"stdin"))) {
	    Fprintf(Stderr, "Can't open stdin for reading\n");
	    exit(2);
	}
    }

    /* nSGML or XML? */

    if(DocumentIsNSGML(dct))
    {
	strings = &nsgml_strings;
	if( ! ( outf = SFFopen(stdout, dct, NSL_write_normal,"stdout") ) ){
	    Fprintf(Stderr, "Can't open stdout for writing\n");
	    exit(7);
	}
	Fprintf(((NSL_File_I*)outf)->file16,
		"<!DOCTYPE INTERSECT PUBLIC \"-//LTG//DTD Intersect Control File//EN//\">\n");
    }
    else
    {
#if CHAR_SIZE == 16
#define	ENCODING CE_UTF_8
#else
#define ENCODING CE_unknown
#endif
	strings = &xml_strings;
	if(!(outf = OpenStream(stdout, NULL, NSL_write_minimal, ENCODING,
			       "stdout"))) {
	    Fprintf(Stderr, "Can't open stdout for writing\n");
	    exit(7);
	}
    }

    qu  = ParseQuery8(dct, strings->file_query);
    /* These are attributes on <file> elements in the control file */
    fileAttr     = AttrUniqueName8(dct,strings->file,4);
    queryAttr    = AttrUniqueName8(dct,strings->query,5);
    subqueryAttr = AttrUniqueName8(dct,strings->subquery,8);
    regexpAttr   = AttrUniqueName8(dct,strings->regexp,6);
    startAttrAttr= AttrUniqueName8(dct,strings->start,5);
    durAttrAttr  = AttrUniqueName8(dct,strings->dur,3);
    endAttrAttr  = AttrUniqueName8(dct,strings->end,3);
    filterAttr   = AttrUniqueName8(dct,strings->filter,6);

  /* Read the control file and extract the filenames and the queries 
     that we need */

    Fprintf(((NSL_File_I*)outf)->file16, strings->intersect_format);

    no_of_input_files = 0;
    while( ( item=GetNextQueryItem(cf, qu, NULL ) ) ) {
	if( no_of_input_files >= MAX_NO_FILES ){
	    Fprintf(Stderr,
		    "Too many input files: Current max is 32\n");
	    exit(4);
	}

	filename[no_of_input_files]    = 
	    strdup_Char_to_char8(GetAttrStringVal(item,fileAttr));
	querystr[no_of_input_files]    = 
	    Strdup(GetAttrStringVal(item,queryAttr));
	subquerystr[no_of_input_files] = 
	    Strdup(GetAttrStringVal(item,subqueryAttr));
	regexpstr[no_of_input_files]   = 
	    strdup_Char_to_char8(GetAttrStringVal(item,regexpAttr));

	startattrname[no_of_input_files]   = 
	    Strdup(GetAttrStringVal(item,startAttrAttr));
	durattrname[no_of_input_files]   = 
	    Strdup(GetAttrStringVal(item,durAttrAttr));
	endattrname[no_of_input_files]   = 
	    Strdup(GetAttrStringVal(item,endAttrAttr));
	filter[no_of_input_files]   = 
	    strdup_Char_to_char8(GetAttrStringVal(item,filterAttr));

	Fprintf(((NSL_File_I*)outf)->file16, strings->file_format,
		no_of_input_files,
		filename[no_of_input_files],
		querystr[no_of_input_files],
		subquerystr[no_of_input_files],
		regexpstr[no_of_input_files],
		startattrname[no_of_input_files],
		endattrname[no_of_input_files],
		durattrname[no_of_input_files],
		filter[no_of_input_files]);

	no_of_input_files++;
	FreeItem(item);
    }
}
