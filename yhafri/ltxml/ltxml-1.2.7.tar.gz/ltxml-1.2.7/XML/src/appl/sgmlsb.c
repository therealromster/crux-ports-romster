/* quick and dirty sentence marking application */

/* Include the NSL public interface definition */
#include "nsl.h"
#include "string16.h"

#define PENDING -1
#define NEUTRAL 0
#define OPEN 1

static void usage(int exitval)
{
    fprintf(stderr, "usage: sgmlsb [-he] [-d ddb-file] [-u base-url] [-s] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_Bit *bit;
  NSL_Item *item, sitem;
  NSL_File inf=NULL, outf;
  NSL_Doctype dct=NULL;
  const Char *paraLabel[2],*wLabel[2],*textLabel=0,*qLabel=0,*label;
  Char sentId[10];
  int arg,in_para=0,sent_open[10],in_text=0,qd=0,was_colon=0,
       ns=0,strong=0;
  Char *dtext;
  char *s;
  NSL_Common_Options *options;
  Char s_S[] = {'S',0};

  NSLInit(0);
  
  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 's':
	      strong = 1;
	      break;
	  default:
	      usage(2);
	  }
  }

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf);
  outf=SFFopen(stdout, dct, options->write_type, "stdout");

  sent_open[qd]=NEUTRAL;

  sitem.doctype = dct;
  sitem.label=s_S;
  sitem.type=NSL_inchoate;
  sitem.data=NULL; sitem.attr=NULL; sitem.in=NULL;
  if( !(sitem.defn=FindElementAndName(dct,&(sitem.label),1))){
    fprintf(stderr,
	    "ERROR sgmlsb: DOCTYPE does not contain a defn for an S element\n");
    return 1;
  };
  NewAttrVal(&sitem,AttrUniqueName8(dct,"ID",2),sentId);
  textLabel=ElementUniqueName8(dct,"TEXT",4);
  paraLabel[0]=ElementUniqueName8(dct,"P",1);
  paraLabel[1]=ElementUniqueName8(dct,"NOTE",4);
  wLabel[0]=ElementUniqueName8(dct,"W",1);
  wLabel[1]=ElementUniqueName8(dct,"ABBR",4);
  qLabel=ElementUniqueName8(dct,"Q",1);

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_start_bit:
      if ((label=bit->label)==textLabel) {
	in_text=1;
	PrintBit(outf, bit);
      }
      else if (in_text &&
	       (label==paraLabel[0] ||
		 label==paraLabel[1])) {
	PrintBit(outf, bit);
	in_para+=1;
	sent_open[qd]=PENDING;
	/* this makes the open s occur not after the open p, but
	   before the first open w */
      }
      /* this is very minimal handling of quotes, not sure how good it is,
	 but it seems to work for my canonical text . . . */
      else if (in_para) {
	if (label==qLabel) {
	  PrintBit(outf, bit);
	  sent_open[++qd]=(was_colon?PENDING:NEUTRAL);
	}
	else if (label==wLabel[0] || label==wLabel[1]) {
	  if (sent_open[qd]==PENDING) {
	    sent_open[qd]=OPEN;
	    Sprintf(sentId, InternalCharacterEncoding,
		    "s%d",ns++); /* install this in a sentence item */
	    PrintItem(outf,&sitem);
	  };
	  item=bit->value.item;
	  ItemParse(inf,item);
	  PrintItem(outf,item);
	  was_colon=0;
	  if (label==wLabel[0] &&
	      (!item->data->next) && /* only one (C) daughter */
	      (dtext=(Char*)(((NSL_Item*)(item->data->first))
			     ->data->first))[1]=='\000' &&
	      /* one character of text exactly */
	      dtext[0]!='\000') {
	      if (dtext[0] == '.' || dtext[0] == '?' || dtext[0] == '!') {
	      /* got one */
	      if (sent_open[qd]!=OPEN) {
		SHOULDNT;
	      };
	      PrintEndTag(outf,sitem.label);
	      sent_open[qd]=PENDING;
	    }
	    else {
	      was_colon=(dtext[0]==':');
	    };
	  };
	}
	else {
	  /* Unrecognised -- better snarf whole thing
	     and print to avoid trouble */
	  item=bit->value.item;
	  ItemParse(inf,item);
	  PrintItem(outf,item);
	  was_colon=0;
	};
      }
      else {
	PrintBit(outf, bit);
      };
      break;
    case NSL_text_bit:
    case NSL_empty_bit:
      PrintBit(outf, bit);
      break;
    case NSL_end_bit:
      if (in_para) {
	if (bit->label==paraLabel[0] || bit->label==paraLabel[1]) {
	  in_para-=1;
	  if (sent_open[qd]==OPEN) {
	    PrintEndTag(outf,sitem.label);
	    sent_open[qd]=NEUTRAL;
	  };
	}
	else if (bit->label==qLabel) {
	  if (sent_open[qd--]==OPEN) {
	    PrintEndTag(outf,sitem.label);
	  };
	};
      };
      PrintBit(outf,bit);
      break;
    default:
      SHOULDNT;
    };
    FreeBit(bit);
  };
  SFrelease(outf,FALSE);
  SFrelease(inf,TRUE);
  return 0;
}
