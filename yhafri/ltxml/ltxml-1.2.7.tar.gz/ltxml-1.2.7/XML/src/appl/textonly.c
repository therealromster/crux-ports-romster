/* textonly.c
   Extract the text from an NSGML file, optionally restricted to text
   somewhere under a user-supplied tag -- use command line arg -t
   To expand sdata entities use -x
   Will insert separator string supplied with
   arg -s, e.g. -s '\n' */

/* Input is an NSGML file */

#include "nsl.h"
#include "lt-memory.h"
#include "ctype16.h"
#include "string16.h"
#include "stdio16.h"

const Char *IDCharFn(const NSL_Doctype doctype,const Char *string) {
  /* no SDATA processing for now */
  return string;
}

static void usage(int exitval)
{
  fprintf(stderr, "usage: textonly [-he] [-d ddb-file] [-u base-url] [-t tag] [-s c] [-x] [file]\n\
Expects nsgml as input, outputs text only.\n\
If -t is present, only text somewhere inside <tag ...> elements is printed.\n\
If -x is present, expand internal SDATA and numerical character references.\n\
If -s is present, the STRING c (e.g. ' ' or \"\\^J\") is printed between \n\
each bit of text.\n\
");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_Bit *bit;
  NSL_File inf=NULL;
  NSL_Doctype dct=NULL;
  char *targ = NULL, *sep = NULL, *ptr;
  const Char *txt;
  const Char *targLabel = 0;
  int in_targ=0,arg,expand=0;
  char *s;
  NSL_Common_Options *options;

  /* Initialise the SAM SGML API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 't':
	      if(arg+1 == argc)
		  usage(2);
	     targ=argv[++arg];
	     break;
	  case 's':
	      if(arg+1 == argc)
		  usage(2);
	      sep= argv[++arg];
	      break;
	  case 'x':
	      expand=1;
	      break;
	  default:
	      usage(2);
	  }
  }

  /* Open the input NSGML file passing in doctype declaration if any */

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf);
  /* if we didn't set it, will have been set by reading from file on opening */

  /* Get the unique name of the elements we care about */

  if (targ) {
    /* If we're reading nSGML, then case-folding upwards may have
       happened, so we need to case-fold our test string */

    if (DocumentIsNSGML(dct)) {
      /* need upper case for tag lookup */
      ptr=targ;
      while (*ptr) {
	*ptr=Toupper(*ptr);
	ptr++;
      };
    };
    targLabel=ElementUniqueName8(dct,targ,strlen(targ));
  }
  else {
    in_targ=1; /* always on */
  };
  
  /* Loop round reading bits of the SGML input text */

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_start_bit:
      if (targLabel && bit->label==targLabel) {
	/* note that we're inside a(nother) target element */
	in_targ++;
      }
      break;
    case NSL_text_bit:
      if (in_targ) {
	txt=bit->value.body;
	if (expand) {
	  txt=ParseRCData(dct,txt,IDCharFn);
	}
	Printf("%S", txt);
	if (sep) {
	    Printf("%s",sep);
	}
	if (expand) {
	  sfree((Char*)txt);
	}
      }
      break;
    case NSL_end_bit:
      if (in_targ && targLabel && bit->label==targLabel) {
	  in_targ--;
      }
      break;
    default: break;
    }
    FreeBit(bit);
  }
  SFrelease(inf,TRUE);
  return 0;
}
