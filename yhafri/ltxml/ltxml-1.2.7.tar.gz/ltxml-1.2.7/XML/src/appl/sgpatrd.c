/* sgpatrd.c	-- Henry Thompson Tue Oct  1 1996
 * Reader for sgrpg patterns
 */

#include "lt-hash.h"
#include "sgrpg.h"
#include "ctype16.h"
#include "string16.h"
#include "stdio16.h"

int attr_val_are_re = FALSE;  /* If TRUE then attribute values in queries are
			     regular expressions, if FALSE then they are
			     just literal strings */
const Char giptr[]={'g','i',0}, dataptr[]={'d','a','t','a',0};
const Char *slab, *flab, *alab, *orlab, *glab, *qlab;
static const Char *supFmtChars=0,*allFmtChars=0;
NSL_Doctype dct;
NSL_Doctype sgdct;
HashTab *idtab;
expo *InternaliseGroupD(NSL_Data *,ktype);
expo *InternaliseDefGroupD(NSL_Data *);

const Char *contextAttr, *polarityAttr, *vqAttr, *qAttr, *dnAttr, *typeAttr,
  *rnAttr, *aAttr, *typeAttr, *linkAttr, *tAttr, *expAttr, *vtAttr, *sAttr,
  *idAttr, *refAttr;

const Char *IdExpansion(const NSL_Doctype dct, const Char *sdata) {
  return sdata;
}

const Char *MyAV(const NSL_Item *item, const Char *aname) {
  const Char *attrval;
  ECNN(attrval=GetAttrStringVal(item,aname));
  return ParseRCData(dct,attrval,IdExpansion);
}

ktype InternaliseKT(NSL_Item *item) {
  switch (GetAttrStringVal(item,expAttr)[1]) {
  case 'N': return one;
  case 'P': return opt;
  case 'L': return plus;
  case 'T': return star;
  default: SHOULDNT;
    return (ktype)NULL;
  }
}

boolean CheckCRef(NSL_Item *item,expo **exp) {
  /* check both ends of id/ref */
  const Char *name;
 if ((name=GetAttrSVal(item,refAttr))) {
    *exp=(expo*)(FindWordInTable(idtab,name)->index);
    return TRUE;
 }
 else {
   *exp=tsalloc(expo,1);
   if ((name=GetAttrSVal(item,idAttr))) {
     (AddWordToTable(idtab,name)->index)=(void*)*exp;
   }
   return FALSE;
 }
}

const Char *InternaliseFormat(const Char *fmt) {
  int i;
  int inarg = 0;

  for (i=0; fmt[i]; i++) {
    if (inarg) {
      if (Strchr(allFmtChars, fmt[i])) {
	inarg = 0;
	if (!Strchr(supFmtChars, fmt[i])) {
	  LT_ERROR1(NEAPPL,"Format character not supported: %c\n",(char)fmt[i]);
	  return NULL;
	};
      };
    }
    else if (fmt[i] == '%') {
      inarg = 1;
    };
  }

  return fmt;
}

expo *InternaliseSubD(NSL_Item *item) {
  expo *exp;
  subqd *sub;
  char *rxs;
  const Char *linkStr;
  if (CheckCRef(item,&exp)) {
    return exp;
  }
  sub=tsalloc(subqd,1);
  if (attr_val_are_re) {
    sub->q=ParseQueryR(dct,GetAttrStringVal(item,qAttr));
  }
  else {
    sub->q=ParseQuery(dct,GetAttrStringVal(item,qAttr));
  }
  rxs=strdup_Char_to_char8(GetAttrStringVal(item,tAttr));
  sub->t=(*rxs)=='\000'?0:hsregcomp(rxs);
  sfree(rxs);
  sub->polarity=(*(GetAttrStringVal(item,polarityAttr)))=='N';
  linkStr=GetAttrStringVal(item,linkAttr);
  sub->link=linkStr[0]=='I'?indep:
           (linkStr[3]=='P'?par:
	    (linkStr[5]=='Q'?seq:ser)); 
  if ((sub->context=(*(GetAttrStringVal(item,contextAttr)))=='P')) {
    preserveEver=1;
  }
  sub->subs=InternaliseDefGroupD(item->data);
  /* May be NULL */
  if( sub->subs && !sub->subs->descr.group->rest) {
    sub->subs=sub->subs->descr.group->first;
  }
  exp->kt=InternaliseKT(item);
  exp->type=subq;
  exp->descr.sub=sub;
  return exp;
}

const Char *InternalisePArg(NSL_Item *item) {
  /* Not all here yet */
  const Char *atype=GetAttrStringVal(item,typeAttr);
  Char *aval,*ptr;
  const Char *p;
  /* efficiency hack */
  switch (*atype) {
  case 'G':			/* gi */
    return giptr;
  case 'D':			/* data */
    return dataptr;
  case 'A':			/* attribute value */
    aval=(Char *)GetAttrStringVal(item,aAttr);
    if (DocumentIsNSGML(dct)) {
      for (ptr=aval;*ptr;ptr++) {
	*ptr=Toupper(*ptr);	/* Yes, we are modifying a const string XXX */
      };
    };
    return AttrUniqueName(dct,aval,0);
  case 'P':			/* regexp match sub-string */
    aval=tsalloc(Char,1);
    /* what a hack */
    *aval = 0;
    for(p=GetAttrStringVal(item,rnAttr); *p >= '0' && *p <= '9'; p++)
	*aval = *aval * 10 + (*p - '0');
    return aval;
  default:
    SHOULDNT;
  }
  return NULL;
}

expo *InternaliseOutD(NSL_Item *item,NSL_Data *adpt,NSL_Data **rptr) {
  int i;
  NSL_Data *dpt;
  const Char *ttype, *p;
  const Char **argv=NULL;
  outd *od=tsalloc(outd,1);
  expo *exp=tsalloc(expo,1);
  exp->kt=one;
  exp->type=out;
  exp->descr.out=od;
  dpt=item->data;
  switch ((ttype=GetAttrStringVal(item,typeAttr))[0]) {
  case 'T':			/* type TEXT */
    od->fmt=InternaliseFormat(MyAV(item,sAttr));
    for (i=0;
	 dpt;
	 dpt=dpt->next,i++);
    if (i) {
      argv=tsalloc(const Char*,i);
      for (i=0,dpt=item->data;
	   dpt && ((NSL_Item*)dpt->first)->label==alab;
	   dpt=dpt->next,i++) {
	if (dpt->type!=NSL_item_data) {
	  continue;
	};
	argv[i]=InternalisePArg(((NSL_Item*)dpt->first));
      }
    }
    od->cnt=i;
    od->argv=argv;
    od->type=text;
    break;
  case 'S':
  case 'E':			/* type ELT, ETAG, STAG
				   Note this ignores any <A ...> daughters */
    od->type=(ttype[1]=='L')?elt:(ttype[0]=='S')?stag:etag;
    od->cnt = 0;
    for(p=GetAttrStringVal(item,dnAttr); *p >= '0' && *p <= '9'; p++)
	od->cnt = od->cnt * 10 + (*p - '0');
    eltEver=1;
    break;
  default:
    SHOULDNT;
  }
  *rptr=adpt;
  return exp;
}

expo *InternaliseOrD(NSL_Item *item) {
  NSL_Data *dtp;
  NSL_Item *sitem;
  ord *tp=NULL;
  expo *exp;
  if (CheckCRef(item,&exp)) {
    return exp;
  }
  exp->kt=InternaliseKT(item);
  exp->type=or;
  for (dtp=item->data;dtp;dtp=dtp->next) {
    if (dtp->type!=NSL_item_data) {
      continue;
    };
    if (tp) {
      tp->rest=tsalloc(ord,1);
      tp=(ord *)tp->rest;
    }
    else {
      exp->descr.ords=tp=tsalloc(ord,1);
    }
    sitem=(NSL_Item*)dtp->first;
    if (sitem->label==slab) {
	tp->first=InternaliseSubD(sitem);
      }
      else if (sitem->label==glab) {
	tp->first=InternaliseGroupD(sitem->data,InternaliseKT(sitem));
      }
    else {
      SHOULDNT;
      return NULL;
    }
    tp->rest=NULL;
  }    
  return exp;
}

/* This can return NULL if dtp is NULL */

expo *InternaliseGroupD(NSL_Data *dtp,ktype kt) {
  NSL_Item *item;
  NSL_Data *tp=NULL;
  rgrp *hgp=NULL,*rgp,*cgp=NULL;
  expo *exp=NULL;
  if (dtp) {
    exp=tsalloc(expo,1);
    exp->kt=kt;
    exp->type=group;
    for (;dtp;dtp=tp) {
      tp=dtp->next;
      if (dtp->type!=NSL_item_data) {
	continue;
      };
      rgp=tsalloc(rgrp,1);
      rgp->rest=0;
      item=(NSL_Item*)dtp->first;
      if (item->label==slab) {
	rgp->first=InternaliseSubD(item);
      }
      else if (item->label==flab) {
	rgp->first=InternaliseOutD(item,dtp->next,&tp);
      }
      else if (item->label==glab) {
	rgp->first=InternaliseGroupD(item->data,InternaliseKT(item));
      }
      else if (item->label==orlab) {
	rgp->first=InternaliseOrD(item);
      }
      else {
	SHOULDNT;
      }
      if (hgp) {
	cgp->rest=rgp;
	cgp=rgp;
      }
      else {
	cgp=hgp=rgp;
      }
    }
    exp->descr.group=hgp;
  }
  return exp;
}

/* This can return NULL if dtp is NULL */

expo *InternaliseDefGroupD(NSL_Data *dtp) {
  expo *exp;
  exp=InternaliseGroupD(dtp,one);
  if (dtp && dtp->next==NULL &&
      (dtp->type==NSL_item_data) && ((NSL_Item*)dtp->first)->label==qlab) {
    /* we only had one q at top level, so pop */
    return (expo*)(exp->descr.group->first);
  }
  else {
    return exp;
  }
}

topqd *InternaliseQueryD(NSL_Item *item) {
  char *rxs;
  const Char *t;
  topqd *tq=tsalloc(topqd,1);
  if (attr_val_are_re) {
    tq->q=ParseQueryR(dct,GetAttrStringVal(item,qAttr));
    tq->vq=ParseQueryR(dct,GetAttrStringVal(item,vqAttr));
  }
  else {
    tq->q=ParseQuery(dct,GetAttrStringVal(item,qAttr));
    tq->vq=ParseQuery(dct,GetAttrStringVal(item,vqAttr));
  }
  t = MyAV(item,vtAttr);
  rxs=strdup_Char_to_char8(t);
  sfree((void *)t);
  tq->vt=(*rxs)=='\000'?0:hsregcomp(rxs);
  sfree(rxs);

  tq->polarity=(*(GetAttrStringVal(item,polarityAttr)))=='N';
  if ((tq->context=(*(GetAttrStringVal(item,contextAttr)))=='P')) {
    preserveEver=1;
  }
  
  tq->subs=InternaliseDefGroupD(item->data);
  return tq;
}

topqd **ReadPatFile(NSL_File patf,NSL_Doctype targdct,
		    int ac,int argc,char **argv) {
  NSL_Query iq;
  NSL_Item *item;
  topqd **queries=NULL;
  int i;
  NSL_Data *dpt,*dph=NULL,*dpc=NULL;
  topqd *mq;
  const char *ptr8;  
  Char *ptr;
  expo *exp=NULL;
  outd *od;

  if (!supFmtChars) {
    allFmtChars=strdup_char8_to_Char("diouxXfeEgGcsSpn%~");
    supFmtChars=strdup_char8_to_Char("sS%~");
  };

  dct=targdct;
  if (patf) {
    /* Initialise unique names we:ll need */
    slab=ElementUniqueName8(sgdct,"S",1);
    flab=ElementUniqueName8(sgdct,"F",1);
    alab=ElementUniqueName8(sgdct,"A",1);
    glab=ElementUniqueName8(sgdct,"G",1);
    qlab=ElementUniqueName8(sgdct,"Q",1);
    orlab=ElementUniqueName8(sgdct,"OR",2);
    expAttr=AttrUniqueName8(sgdct,"EXP",3);
    tAttr=AttrUniqueName8(sgdct,"T",1);
    linkAttr=AttrUniqueName8(sgdct,"LINK",4);
    typeAttr=AttrUniqueName8(sgdct,"TYPE",4);
    aAttr=AttrUniqueName8(sgdct,"A",1);
    rnAttr=AttrUniqueName8(sgdct,"RN",2);
    typeAttr=AttrUniqueName8(sgdct,"TYPE",4);
    dnAttr=AttrUniqueName8(sgdct,"DN",2);
    qAttr=AttrUniqueName8(sgdct,"Q",1);
    vqAttr=AttrUniqueName8(sgdct,"VQ",2);
    vtAttr=AttrUniqueName8(sgdct,"VT",2);
    sAttr=AttrUniqueName8(sgdct,"S",1);
    idAttr=AttrUniqueName8(sgdct,"ID",2);
    refAttr=AttrUniqueName8(sgdct,"REF",3);
    polarityAttr=AttrUniqueName8(sgdct,"POLARITY",8);
    contextAttr=AttrUniqueName8(sgdct,"CONTEXT",7);
    idtab=NewSizedHashStruct(100);
    /* should just read whole thing . . . */
    iq=ParseQuery8(sgdct,".*/Q");
    i=0;
    while ((item=GetNextQueryItem(patf,iq,NULL))) {
      i++;
      dpt=NewNullNSLData(sgdct);
      dpt->type=NSL_item_data;
      dpt->first=item;
      if (dpc) {
	dpc->next=dpt;
      }
      else {
	dph=dpt;
      }
      dpc=dpt;
    }
    queries=tsalloc(topqd*,i);
    for (nq=0,dpt=dph;dpt;nq++,dpt=dpt->next) {
      if (dpt->type!=NSL_item_data) {
	continue;
      };
      queries[nq]=InternaliseQueryD((NSL_Item*)dpt->first);
    }
  }
  else {
    queries=tsalloc(topqd*,1);
    queries[0]=mq=tsalloc(topqd,1);
    nq=1;
    mq->subs=exp=tsalloc(expo,1);
    mq->polarity=neg;
    if (argc<ac+5) {
      fprintf(stderr,"Not enough arguments:\n");
      usage(2);
    }
    if (attr_val_are_re) {
      mq->q=ParseQueryR8(dct,argv[ac++]);
    }
    else {
      mq->q=ParseQuery8(dct,argv[ac++]);
    }
    if (attr_val_are_re) {
      mq->vq=ParseQueryR8(dct,argv[ac++]);
    }
    else {
      mq->vq=ParseQuery8(dct,argv[ac++]);
    }
    /* check for empty regexp meaning anything */
    mq->vt=strlen8(argv[ac++])==0?0:hsregcomp(argv[ac-1]);

    exp->type=out;
    exp->kt=one;
    exp->descr.out=od=tsalloc(outd,1);
    od->type=text;
    od->fmt=InternaliseFormat(strdup_char8_to_Char(argv[ac++]));
    od->cnt=argc-ac;
    od->argv=tsalloc(const Char *, od->cnt);
    for (i=0;i<od->cnt;i++) {
      if (!strcasecmp8(argv[ac+i],"<GI>")) {
	od->argv[i]=giptr;
      }
      else if (!strcasecmp8(argv[ac+i],"<DATA>")) {
	od->argv[i]=dataptr;
      }
      else {
	Char *a;
	ptr8=argv[ac+i];
	if (DocumentIsNSGML(dct)) {
	  a=tsalloc(Char, strlen8(argv[ac+i])+1);
	  for (ptr=a; *ptr8; ptr++,ptr8++) {
	    *ptr=Toupper(*ptr8);
	  };
	  *ptr='\000';
	}
	else {
	  a=strdup_char8_to_Char(ptr8);
	};
	if (!(ptr=(Char *)AttrUniqueName(targdct,a,0))) {
	  LT_ERROR2(NEAPPL,"Attribute name not defined: %s->%s\n",
		    argv[ac+i],a);
	  return NULL;
	}
	sfree(a);
	od->argv[i]=ptr;
      }
    }
  }
  return queries;
}
