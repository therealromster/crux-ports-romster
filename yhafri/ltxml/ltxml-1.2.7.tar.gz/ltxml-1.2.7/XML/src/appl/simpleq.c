#include "nsl.h"
#include "ctype16.h"
#include "string16.h"
#include "lt-memory.h"      /* For sfree */
#ifdef macintosh
#include <console.h>
#endif

static void usage(int exitval)
{
    fprintf(stderr, "usage: simpleq [-he] [-d ddb-file] [-u base-url] [-t type-attr] [-w word-element] [-f format] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_File inf=NULL, outf;
  NSL_Doctype dct=NULL;
  NSL_Query qu;
  NSL_Item *item;
  const Char *tagAttr, *tagVal=NULL;
  char8 qustr[100], *ptr;
  Char buf[100];
  int arg,len;
  char *s;
  NSL_Common_Options *options;

  /* defaults for command line arguments */
  /* Name of attribute carrying tag -- set with -t */
  char* targ= (char *)"TYPE";
  /* Name of word element -- set with -w */
  char* warg= (char *)"W";
  /* Format string for word, tag -- set with -f */
  const char* textFormat="%S/%S";

#ifdef macintosh
  argc = ccommand(&argv);
#endif
  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 't':
	      if(arg+1 == argc)
		  usage(2);
	      targ=argv[++arg];
	      break;
	  case 'w':
	      if(arg+1 == argc)
		  usage(2);
	      warg=argv[++arg];
	      break;
	  case 'f':
	      if(arg+1 == argc)
		  usage(2);
	      textFormat=argv[++arg];
	      break;
	  default:
	      usage(2);
	  }
  }

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf);

  /* If we're reading nSGML, then case-folding upwards may have
     happened, so we need to case-fold our test string */

  if (DocumentIsNSGML(dct)) {
    /* need upper case for attribute lookup */
    ptr=targ;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
  };

  outf=SFFopen(stdout, dct, options->write_type, "stdout");

  strcpy8(qustr,".*/TEXT/.*/P/.*/");
  /* Note ParseQuery handles case-folding if necessary */
  strcat8(qustr, warg);
  qu=ParseQuery8(dct,qustr);
  tagAttr=AttrUniqueName8(dct,targ,0);

  while( ( item=GetNextQueryItem(inf, qu, outf ) ) ) {
    Char *word=(Char*)item->data->first;
    len=Strlen(word);
    while (is_xml_whitespace(word[len-1])) {
      word[--len]='\000';
    }
    tagVal=GetAttrStringVal(item,tagAttr);
    /* construct the tagged word */
    Sprintf(buf,InternalCharacterEncoding,textFormat,word,tagVal);
    /* install it as the item's content */
    item->data->first = buf;
    PrintItem(outf, item);
    item->data->first = 0;	/* so we don't free our buffer */    
    sfree(word);		/* because it's not in the item anymore */
    FreeItem(item);
  } /* end while */

  SFclose(outf);
  return 0;
}
