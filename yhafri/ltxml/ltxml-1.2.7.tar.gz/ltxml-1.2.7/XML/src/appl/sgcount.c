/* 	$Id: sgcount.c,v 1.18 1998/05/01 18:27:51 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sgcount.c,v 1.18 1998/05/01 18:27:51 richard Exp $";
#endif /* lint */

/* Program to count the occurances of SGML elements in an nSGML
   file. Input(stdin) is an nSGML file, Output(stdout) is a 
   series of lines of the form 
   SGML-element-name <tab> No-occurances <tab> No-identfied-occurances
   where No-occurances is the number of times the SGML element 
   occurs in the file, and No-identfied-occurances is the number 
   of occurances which have an ID attribute (an explicit attribute 
   of type ID) */

/* 28 July 1997: Added -t option to only count top level elements */

/* 5 Nov 1997: Added -o option to allow different output formats 
               Also allow multiple files on command line */

/* Copyright 1996 Human Communication Research Centre, 
   Edinburgh University */

#include <stdio.h>
#include "nsl.h"
#include "string16.h"
#include "nsllib.h"		/* XXX for defaultOutputEncoding */
#include "lt-memory.h"
#include "lt-hash.h"

typedef struct pair {
  int occurances;
  int identified_occurances;
} pair;

void print_table( const HashTab *hashtable, int output_format );
int process_file(const char * filename, HashTab *hashtable, int topOnly);

boolean FreePairs(const HashList * hl){
  sfree((unsigned char*)hl->word);
  return sfree(hl->index);
}

CharacterEncoding OutputEncoding;

static void usage(int exitval)
{
    fprintf(stderr, "usage: sgcount [-t] [-o [012]] [filename ...]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  HashTab *hashtable;
  int topOnly = 0, arg , output_format = 0;
  char *s;
  NSL_Common_Options *options;

  NSLInit(0);
  hashtable = NewHashStruct( );

    /* Read command line options */

  options = NSLGetoptions(&argc, argv, "h", usage);
  
  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 't':
	      topOnly = 1;
	      break;
	  case 'o':
	      if(arg+1 == argc)
		  usage(2);
	      output_format = atoi(argv[++arg]);
	      break;
	  default:
	      usage(2);
	  }
  }

  if(argc - arg > 0)
  {
      for(; arg < argc; arg++)
	  process_file(argv[arg], hashtable, topOnly);
  }
  else
      process_file(NULL, hashtable, topOnly);

  print_table(hashtable, output_format);
  MapHashLists(hashtable,&FreePairs);
  FreeHashStruct(hashtable);
  return 0;
}

/* Process one file */

int process_file(const char * filename, HashTab *hashtable, int topOnly){
  NSL_File inf;
  NSL_Doctype dct=NULL;
  NSL_Bit *bit;
  const Char *idval;
  int depth = 0;
  HashList *hashitem;
  static int first_file = 1;

  if( filename ){
    inf=SFopen(filename, dct, NSL_read);
  } else {
    inf=SFFopen(stdin, dct, NSL_read, "stdin");
  }

  if(first_file)
  {
      first_file = 0;
      dct=DoctypeFromFile(inf);
      SetFileEncoding(Stdout, 
		      dct->defaultOutputEncoding); /* XXX add arg for this */
  }

  while( ( bit=GetNextBit(inf) )) {
    switch (bit->type){
    case NSL_start_bit:
    case NSL_empty_bit:
      if( ! topOnly || depth == 0 ){
	idval = GetIdVal(bit->value.item);;
	if( ( hashitem = FindWordInTable(hashtable,bit->label) )){
	  ((pair*)(hashitem->index))->occurances += 1;
	  if( idval ){
	    ((pair*)(hashitem->index))->identified_occurances += 1;
	  }
	} else {
	  /* We need strdup, since as we can process multiple files,
             each potentially with their own doctypes and we are
             deleting the doctypes after we close each file, we need
             to ensure that the element labels are still around by the
             time we print out the table. */
	  hashitem = AddWordToTable(hashtable,Strdup(bit->label));
	  ECNE(hashitem->index = (void *)salloc(sizeof(pair)));
	  ((pair*)(hashitem->index))->occurances = 1;
	  if( idval ){
	    ((pair*)(hashitem->index))->identified_occurances = 1;
	  } else {
	    ((pair*)(hashitem->index))->identified_occurances = 0;
	  }
	}
      }
      if( bit->type == NSL_start_bit ) { depth++; }
      break;
    case NSL_bad:
    case NSL_eof_bit:
      Fprintf(Stderr, "ERROR: bad/eof bit type\n");
      break;
    case NSL_end_bit:
      depth--;
    case NSL_text_bit:
    case NSL_pi_bit:
      break;
    default:
      Fprintf(Stderr, "ERROR: odd bit type %d\n",bit->type);
    }
    FreeBit(bit);
  }
  SFrelease(inf,TRUE);
  return 0;
}

static Char total_label[] = {'*','T','o','t','a','l','*',0};

/* Print one line of output */

void print_line(const Char * word, int occ, int id_occ, int format){
  switch (format){
  case 1:
    /* Dont print id occurances */
    Printf("%S\t%d\n",word,occ); break;
  case 2:
    /* Only print totals and no id occurances */
    if(word == total_label ){
      Printf("%d\n",occ); 
    }
    break;
  default:
    /* Print everything */
    Printf("%S\t%d\t%d\n",word,occ,id_occ); break;
  }
}

/* Print the table of outputs */

void print_table( const HashTab *hashtable, int output_format){
  int i, total_occurances=0, total_identified_occurances=0;
  HashList *hashitem;

  for( i=0; i< hashtable->size; i++){
    for(hashitem = hashtable->table[i]; 
	hashitem; 
	hashitem = (HashList *)hashitem->next){
      total_occurances += 
	((pair*)(hashitem->index))->occurances;
      total_identified_occurances += 
	((pair*)(hashitem->index))->identified_occurances;
      print_line(hashitem->word,
		 ((pair*)(hashitem->index))->occurances,
		 ((pair*)(hashitem->index))->identified_occurances,
		 output_format);
    }
  }
  print_line(total_label,
	     total_occurances,
	     total_identified_occurances,
	     output_format);
}

