#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "lt-comment.h"
#include "lt-safe.h"		/* for sfopen, sopen */
#include "string16.h"		/* for strdup8 */
#include "lt-memory.h"		/* for sfree */

#define STRTOUL(a,b,c) (unsigned long)strtol((a),(b),(c))

static void usage(int exitval)
{
  fprintf(stderr,
    "usage: getindex -i indexFile -f fileIndexFile [-l delimiter] indices...\n");
  exit(exitval);
}

int main(int argc, char **argv) {
  char *indexfile = 0, *fileindexfile = 0;
  int indexfilelen, i, j, filecount;
  unsigned long *index, idxno, idxno1, idxno2,
                start, end, fileno, existingfileno;
  char *error, *filename=0;
  char *delimiter=0;
  char **filenamearray;
  FILE *fd;
  int arg;
  char *s;

  /* Read command line options */

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 'h':
	      usage(0);
	      break;
	  case 'i':
	      if(arg+1 == argc)
		  usage(2);
	      indexfile = argv[++arg];
	      break;
	  case 'f':
	      if(arg+1 == argc)
		  usage(2);
	      fileindexfile = argv[++arg];
	      break;
	  case 'l':
	  case 'd':		/* Deprecated, -d is usually ddb file */
	      if(arg+1 == argc)
		  usage(2);
	      delimiter = argv[++arg];
	      break;
	  default:
	      usage(2);
	  }
  }

  if( !delimiter ){
    delimiter = (char*)"";
  }
  /* Open index file - memory mapped */
  if( !indexfile ){
    fprintf(stderr,
	  "Error in getindex: must specify an index file with -i\n");
    return 1;
  }
  if( !( index = mmapfile(indexfile,&indexfilelen))){
    fprintf(stderr,"Error in getindex: cannot map in index file %s\n",
	    indexfile);
    return 1;
  }
  /* rescale indexfilelen to refer to number of entries */
  indexfilelen = indexfilelen/(3*sizeof(unsigned long));

  if( !fileindexfile ){
    fprintf(stderr,
	  "Error in getindex: must specify a file index file with -f\n");
    return 1;
  }
  /* Read file index file, Scan file index file and find out 
     how many filenames there are */
  filecount = 0;
  if( ( fd = sfopen(fileindexfile, "r"))){
    char str[1000];
    while( fgets(str,1000,fd) ){
      filecount +=1;
    }
    sfclose(fd);
    fd = sfopen(fileindexfile, "r");
    filenamearray = (char **)malloc(filecount*sizeof(char*));
    i = 0;
    while( fgets(str,1000,fd) ){
      ECNE(filenamearray[i] = strdup8(str));
      filenamearray[i][strlen(str)-1] = '\000'; /* chop newline */
      i++;
    }
    sfclose(fd);
  } else {
    fprintf(stderr,
	    "Error in getindex: cannot open file index file %s\n",
	    fileindexfile);
    return 2;
  }
  /* Loop over the index numbers and retrieve the relevant bits */
  argc = argc - arg;
  argv = argv + arg;
  existingfileno = -1;
  for(i=0 ; i<argc ; i++){
    idxno1 = STRTOUL(argv[i],&error,0);
    if( *error == 0 ){
      /* Parsed the whole string as an integer */
      idxno2 = idxno1;
    } else if( *error == '-' ){
      /* Of the form NNN-NNN meaning a range */
      argv[i] = error+1;
      idxno2 = STRTOUL(argv[i],&error,0);
      if( *error == 0 ){
	/* Parsed the whole string as an integer */
	if( idxno1 > idxno2 ){
	  /* Range out of order */
	  fprintf(stderr,
		"Error in getindex: misordered range %s\n",
		argv[i]);
	  continue;
	}
      } else { 
	fprintf(stderr,
		"Error in getindex: invalid integer %s\n",
		argv[i]);
	continue;
      }
    } else {
      fprintf(stderr,
	    "Error in getindex: invalid integer %s\n",
	    argv[i]);
      continue;
    }
    if( idxno2 >= indexfilelen ){
      /* index is out range - print warning */
      fprintf(stderr,
	    "Error in getindex: index %lu out of range\n",
	    idxno2);
      continue;
    } else {
      for( idxno=idxno1; idxno <= idxno2; idxno++){
	/* Look up index number in index */
	fileno = index[3*idxno];
	start  = index[3*idxno+1];
	end    = index[3*idxno+2];
	/* Look up file index no in file index */
	if( fileno >= filecount ){
	  /* file index no is out of range - oops! */
	  fprintf(stderr,
		  "Error in getindex: invalid file number %lu\n",
		  fileno);
	  return 5;
	} else {
	  if( fileno == existingfileno ){
	    /* then we can reuse existing open file */
	  } else {
	    /* Close existing open file if necessary */
	    if( existingfileno > -1 ){
	      sfclose(fd);
	    }
	    /* Get filename and open it */
	    filename = filenamearray[fileno];
	    if( !( fd = sfopen(filename,"r") )){
	      fprintf(stderr,
		      "Error in getindex: cannot open file %s\n",
		      filename);
	      return 6;
	    };
	    existingfileno = fileno;
	  }
	  /* Seek for start position */
	  fseek(fd,start,SEEK_SET);
	  if( start == end ){
	    /* This is a bit messy -and I'm not sure how best to do 
	     this. This case is when we had an empty SGML element.
	     For now: assume that < marks start of markup, and an 
	     unquoted ('"' or '\'') > marks end of markup. */
	    int quoted = 0;
	    while( ( j = getc(fd) ) != '>' || quoted ) {
	      if( quoted ){
		if( j == quoted ){
		  quoted = 0;
		}
	      } else {
		if( j == '"' ) quoted = '"';
		if( j == '\'' ) quoted = '\'';
	      }
	      putc(j,stdout);
	    };
	    putc(j,stdout);
	  } else {
	    /* Read and write until end position */
	    /* NB this does NOW print the end tag */
	    int el = 1;
	    char ch;
	    char eln[100], *elnp = eln;
	    for(j = 0; j< end-start; j++){
	      putc(ch=getc(fd),stdout);
	      if( ( j>0 ) && el ){
		if( ( ch == ' ' ) || ( ch == '>' )){ 
		  *elnp = 0; el = 0;
		} else {
		  *elnp = ch;
		  elnp++;
		}
	      }
	    }
	    /* Write an end tag */
	    fprintf(stdout,"</%s>",eln);
	  }
	  /* Write delimiter */
	  fprintf(stdout,"%s\n",delimiter);
	}
      }
    }
  }
  for(i=0; i<filecount; i++){
    sfree(filenamearray[i]);
  }
  sfree(filenamearray);
  return 0;
}

