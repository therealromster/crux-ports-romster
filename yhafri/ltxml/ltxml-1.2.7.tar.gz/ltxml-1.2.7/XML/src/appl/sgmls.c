/* sgmls.c
   Trivial fake of nsgmls, some attributes but not all info yet
   */

/* Input is an NSGML file */

/* Include the NSL public interface definition */
#include "nsl.h"
/* Need this for Printf, the character-set aware version of printf */
#include "stdio16.h"
/* Need this for sfree */
#include "lt-memory.h"

static void usage(int exitval)
{
    fprintf(stderr, "usage: pesis [-d ddb-file] [-u base-url] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
  NSL_Bit *bit;
  NSL_File inf=NULL;
  NSL_Doctype dct=NULL;
  int arg;
  Char *ptr; /* the standard way of referring to a character for us */
  const NSL_ElementSummary eltsum;
  NSL_AttributeSummary *attrs;
  int i, numattrs;
  const Char *an;
  NSL_Common_Options *options;

  /* Initialise the SAM SGML API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hdeu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      usage(2);
  }

  /* Open the input NSGML file passing in doctype declaration if any */

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf);
  /* if we didn't set it, will have been set by reading from file on opening */

  /* Loop round reading components of the SGML input text */

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
      eltsum = FindElementByName(dct,bit->label);
      attrs  = ElementAttributes(eltsum,dct,&numattrs);
      for(i=0; i<numattrs; i++ ){
	an = AttributeName(attrs[i]);
	Printf("A%S %s %S\n",an,"CDATA",
	       GetAttrVal(bit->value.item,an));
      };
      sfree((void*)attrs);
      if(bit->type == NSL_empty_bit)
	  Printf("(%S\n)%S\n",bit->label,bit->label);
      else
	  Printf("(%S\n",bit->label);
      break;
    case NSL_text_bit:
      Printf("-");
      for (ptr=bit->value.body;*ptr;ptr++) {
	if( *ptr == 10 ){
	  Printf("\\n");
	} else if (*ptr<32) {
	  Printf("\\%03o", *ptr);
	} else {
	  Printf("%.1S", ptr);
	};
      };
      Printf("\n");
      break;
    case NSL_end_bit:
      Printf(")%S\n",bit->label);
      break;
    case NSL_pi_bit:
      break;
    default:
      SHOULDNT;
    };
    /* Bits are fixed, but they are not freed unless we do it ourselves */
    FreeBit(bit);
  };
  SFrelease(inf,TRUE);
  return 0;
}
