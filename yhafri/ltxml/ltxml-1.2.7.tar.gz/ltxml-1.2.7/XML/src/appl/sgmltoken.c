/* quick and dirty tokenising application */
/* Only works for 8-bit data at present */

/* Input is an NSGML file */
/* Output is NSGML */

#include "nsl.h"
#include "nslfile.h"		/* we have to use the private header file
				   because we muck about with the internals of
				   output state */
#include "string16.h"
#include "lt-token.h"
#include "lt-memory.h"

static void usage(int exitval)
{
    fprintf(stderr, "usage: sgmltoken [-he] [-d ddb-file] [-u base-url] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv) {
#if CHAR_SIZE==16
  fprintf(stderr,"Sorry, tokenisation not yet available in 16-bit version\n");
  return 2;
#else

  NSL_Bit *bit;
  NSL_File inf=NULL, outf;
  NSL_Doctype dct=NULL;
  const Char *textLabel;
  const char *fmtString;
  int item=1,in_text=0;
  char sbuf[100];
  int arg;
  NSL_Common_Options *options;

  /* Initialise the SAM SGML API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      usage(2);
  }

  /* Open the input NSGML file passing in doctype declaration if any */

  switch(argc - arg)
  {
    case 0:
	inf = SFFopen(stdin, dct, options->read_type, options->base_url);
	break;
    case 1:
	inf = SFopen(argv[arg], dct, options->read_type);
	break;
    default:
	usage(2);
	break;
  }

  dct=DoctypeFromFile(inf);

  /* Open the output NSGML stream using the same doctype declaration */

  outf=SFFopen(stdout, dct, options->write_type, "stdout");

  /* Get the definition of a <TEXT> element */

  textLabel=ElementUniqueName8(dct,"TEXT",4);

  /* Choose output form based on input file type */

  if (DocumentIsNSGML(dct)) {
    fmtString="C ID=C%d.T%%d";
  }
  else {
    fmtString="C ID='C%d.T%%d'";
  };
  

  /* Loop round reading bits of the SGML input text */

  while ((bit=GetNextBit(inf))) {
    switch (bit->type) {
    case NSL_end_bit:
      if (bit->label==textLabel) {
	/* If we are leaving a <TEXT> then set in_text flag */
	in_text=0;
	/* and change the formatting style back to default */
	outf->type=NSL_write_normal;
      }
      PrintEndTag(outf,bit->label);
      break;
    case NSL_text_bit:
      if (in_text) {
	char8 *text = strdup_Char_to_char8(bit->value.body);
	/* We are inside a <TEXT> element */
	/* Tokenise the bit */
	sprintf(sbuf,fmtString,item++);
	if (outf->state==_elt_begin) {
	  /* unless bogus mixed content this is OK */
	  putchar('\n');
	  outf->state=_elt_unknown;
	}
	if (tokenise((const unsigned char **)&text,-1,0,0,
		     (unsigned char *)sbuf,'\000')) {
	  outf->state=_elt_text; /* will get us an RE where we want one */
	}
	sfree(text);
      } else {
	/* We are not inside a <TEXT> element */
	PrintText(outf, bit->value.body);
      }
      break;
    case NSL_start_bit:
      if (bit->label==textLabel) {
	/* If we are inside a <TEXT> then set in_text flag */
	in_text=1;
	/* and change the formatting style to make things a bit clearer */
	outf->type=NSL_write_pretty;
      };
    case NSL_empty_bit:
      PrintBit(outf, bit);
      break;
    default:
      SHOULDNT;
    }
    FreeBit(bit);
  }
  SFrelease(outf,FALSE);
  SFrelease(inf,TRUE);
  return 0;
#endif
}

