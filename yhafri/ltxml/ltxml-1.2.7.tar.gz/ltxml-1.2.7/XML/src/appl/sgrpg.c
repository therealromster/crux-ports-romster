/* 	$Id: sgrpg.c,v 1.45 2001/11/21 13:36:02 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sgrpg.c,v 1.45 2001/11/21 13:36:02 richard Exp $";
#endif /* lint */
/* sgrpg.c	-- (c) Henry S. Thompson Wed Jun 12 1996
 *
 * Try some simple output formatting of sggrep results
 */

#include <stdio.h>
#include "nsllib.h"
#include "sgrpg.h"
#include "string16.h"
#include "stdio16.h"

extern WIN_IMP SFState PrintStartTagInternal(NSL_File_I *f, SFState state,
					     const NSL_Item *item);
NSL_Doctype dct=NULL;
NSL_Item *item;
int outCnt=0,eltEver=0,preserveEver,nq=0,neg=FALSE;

NSL_File outf=NULL;

void usage(int exitval)
{
    fprintf(stderr, "Usage: \n\
sgrpg [-d ddb-file] [-e] [-r] ([-v] query sub-query regexp out-fmt oargs... | \n\
                           -f pat-file) \n\
   -d ddb-file:  Take Dtd from specified ddb file \n\
   -e: don't expand entities\n\
   -v: invert sense of sub-query+regexp \n\
   -r: attribute values in queries are regular expressions \n\
   -f: pattern-action file, XML (or nSGML) format, \n\
       sgrpg.dtd,xml (resp. sgrpg.dtd) as DTD \n\
   query:  pattern on items to select, basically path based with terms \n\
     separated by /, <term>:=<GI><cond>?'*'? \n\
                     <GI>:=<elementName>|'.' \n\
		     <cond>:='['<index>|<atests>|<index> <atests>']' \n\
		     <index>:=<number> \n\
		     <atests>:=<atest>(' '<atest>)* \n\
		     <atest>:=<aname>('='<aval>)? \n\
     Aname and aval are as per SGML, except that if the -r flag is given,  \n\
     aval are regular expressions. \n\
     A GI of . matches any tag.  A condition with an index matches only the \n\
     indexth sub-element of the enclosing element.  Attribute tests are not \n\
     exhaustive, and will match against both explicitly present and defaulted \n\
     attribute values, using string equality.  Bare anames are satisfied by \n\
     ANY value, explicit or defaulted.  Terms ending with * match \n\
     any number of links in the chain, including 0. \n\
 \n\
   sub-query:  selects sub-elements of query-selected item for \n\
               regexp to match -- use '.' for whole item\n\
 \n\
   regexp:  Regular expression to match against text directly contained in \n\
            query-selected item in sub-query-selected \n\
	    sub-element of query-selected item. \n\
            If empty (i.e. '') matches anything, including empty elements, \n\
            indeed this is the ONLY way to get empty elements if required. \n\
 \n\
   out-fmt:  a FORMAT string \n\
 \n\
   oargs:  arguments to format, either <GI>, <DATA>, or attribute name \n\
");
    exit(exitval);
}

static NSL_Item *MITEM;		/* for multiple return value */
static NSL_Bit *MBIT;
static NSL_Item BAD_ITEM={NULL,NULL,NULL,NULL,NULL,0,0,NULL,NSL_bad,NULL,NULL,NULL,NULL};

Query_Result GMC(NSL_File_I *sgmlfile, topqd **queries, int nq, topqd **hit) {
  /* Version of GetMatchingComponent which takes an array of query descriptors
     Each bit matches at most once */
  int i;
  const topqd *qd;
  CCOMMENT("Getting a bit\n");
    
  for (;;) {
    MBIT=NextBit(sgmlfile);
    switch (MBIT->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
      MITEM=MBIT->value.item;
      if (!AddOpenContext(sgmlfile, MITEM)) {
	goto querr;
      }
      for (i=0;i<nq;i++) {
	qd=queries[i];
	if (ExecQueryUp(qd->q, MITEM->in)) {
	  if (!AddCloseContext(sgmlfile, NULL)) {
	    goto querr;
	  }
	  /* this cuts off downward pointer and frees MITEM->data */
	  /* so we're 'in' the upward chain, but it doesn't point down to us */
	  /* This is to put us in position for the next call */
	  MITEM=ItemParse(sgmlfile, MITEM);
	  if (MITEM->type==NSL_bad) {
	    goto querr;
	  }
	  *hit=(topqd*)qd;
	  return _query_win;
	}
      }
      if (MBIT->type==NSL_empty_bit) {
	if (!AddCloseContext(sgmlfile, MITEM->label)) {
	  goto querr;
	}
      }
      return _query_lose;
    case NSL_end_bit:
      MITEM=sgmlfile->currentbase->in;
      if (!AddCloseContext(sgmlfile, MBIT->label)) {
	goto querr;
      }
      return _query_lose;
    case NSL_text_bit:
      return _query_lose;
    case NSL_pi_bit:
      /* ignored for now */
      FreeBit(MBIT);
      return GMC(sgmlfile, queries, nq, hit);
    case NSL_eof_bit:
      return _query_eof;
    case NSL_bad:
querr:
      FreeBit(MBIT);
      return _query_err;
    default:
      SHOULDNT;
      return _query_lose;
    }
  }
}

NSL_Item *GNQI( NSL_File infile, topqd **queries, int nq, topqd **hit,
		NSL_File outfile) {
  /* version of GetNextQueryItem which takes an array of query descriptors */
  Query_Result qval;

  while ((qval=GMC(infile, queries, nq, hit))!=_query_eof) {
    switch (qval) {
    case _query_win:
      return MITEM;
    case _query_lose:
      if (outfile) {
	if (queries[0]->context) {
	  if (PrintBit(outfile,MBIT)==EOF) {
	    return &BAD_ITEM;
	  }
	}
      }
      switch (MBIT->type) {
      case NSL_end_bit:
	if (!FreeItem(MITEM)) {
	  return &BAD_ITEM;
	}
      case NSL_empty_bit:
      case NSL_text_bit:
	if (!FreeBit(MBIT)) {	/* frees contents only */
	  return &BAD_ITEM;
	}
      default: break;
      }
      break;
    case _query_err:
      return &BAD_ITEM;
    default:
      SHOULDNT;
      return &BAD_ITEM;
    }
  }
  return NULL;
}

/* shamelessly pinched from stdio16, with format changed to Char */

int VfprintfC(FILE16 *file, const Char *format, int escape, Char **args) {
  int c, width, prec;
  const Char *start=0;
  int mflag, pflag, sflag, hflag, zflag;
  int n = 0;
  int argnum = 0;

  while((c = *format++)) {
    if(c != (Char)'%') {
      if (n++==0) {
	start=format-1;
      };
      continue;
    };
    if (n) {
      Fprintf(file,"%.*S",n,start);
      n=0;
    };
    width = 0;
    prec = -1;
    mflag=0, pflag=0, sflag=0, hflag=0, zflag=0;

    while(1)
      {
	switch(c = (char)*format++)
	  {
	  case '-':
	    mflag = 1;
	    break;
	  case '+':
	    pflag = 1;
	    break;
	  case ' ':
	    sflag = 1;
	    break;
	  case '#':
	    hflag = 1;
	    break;
	  case '0':
	    zflag = 1;
	    break;
	  default:
	    goto flags_done;
	  }
      }
  flags_done:

    if(c >= '0' && c <= '9')
      {
	width = c - '0';
	while((c = *format++) >= '0' && c <= '9')
	  width = width * 10 + c - '0';
      }

    if(c == '.')
      {
	c = *format++;
	if(c >= '0' && c <= '9')
	  {
	    prec = c - '0';
	    while((c = *format++) >= '0' && c <= '9')
	      prec = prec * 10 + c - '0';
	  }
	else
	  prec = 0;
      }

    switch(c)
      {
      case '%':
	sPutc((Char)'%',file);
	break;
      case '~':
	sPutc((Char)'\n',file);
	break;
      case 's':
      case 'S':
	if(escape)
	{
	    Char *q = args[argnum++];
	    int l, i, m, s=0;
	    
	    /* & and < only count one towards field width and precision;
	       this is deliberate. */
	    l = Strlen(q);
	    if(prec >= 0 && l > prec)
		l = prec;
	    if(l < width && !mflag)
		Fprintf(file, "%*S", width-l, "");

	    m = 0;
	    for(i=0; i<l; i++)
	    {
		if(q[i] == '<' || q[i] == '&')
		{
		    if(m > 0)
			Fprintf(file, "%.*S", m, q+s);
		    m = 0;
		    if(q[i] == '<')
			Fprintf(file, "&#60;");
		    else
			Fprintf(file, "&#38;");
		}
		else
		{
		    if(m++ == 0)
			s = i;
		}
	    }
	    if(m > 0)
		Fprintf(file, "%.*S", m, q+s);
	    if(l < width && mflag)
		Fprintf(file, "%*S", width-l, "");
	}
	else
	    Fprintf(file, "%*.*S", width, prec, args[argnum++]);
	break;
      default:
	fprintf(stderr, "unsupported format character %c\n", c);
	return -1;
      }
  }

  if (n) {
    Fprintf(file,"%.*S",n,start);
  };

  return 0;
}

boolean ExpoRpg(const NSL_Data *,const expo *,const regexp *,
		boolean,const NSL_Data **);

void OutRpg(const NSL_Data *dptr,const outd *od,const regexp *rx) {
  static Char *fmtArgs[100];
  static int fmtFreeMe[100];
  static Char pseudo[] = {'<','P','S','E','U','D','O','E','L','T','>',0};
  int n,len,i,j;
  switch (od->type) {
  case text:
    for (i=0;i<od->cnt;i++) {
      fmtFreeMe[i] = 0;
      if (od->argv[i]==giptr) {
	switch (dptr->type) {
	case NSL_item_data:
	  fmtArgs[i]=(Char *)((NSL_Item*)(dptr->first))->label;
	  break;
	case NSL_text_data:
	  fmtArgs[i]=pseudo;
	  break;
	default:
	  SHOULDNT;
	}
      }
      else if (od->argv[i]==dataptr) {
	switch (dptr->type) {
	case NSL_item_data:
	  { NSL_Data *xxx = ((NSL_Item*)(dptr->first))->data;
	    if( !xxx ){
	      /* This item has NO children */
	      fmtArgs[i]=(Char *)NSL_Implied_Attribute_Value;
	    } else if( xxx->type == NSL_text_data ){
	      fmtArgs[i]=(Char *)(xxx->first);
	    } else {
	      /* We asked for text content, but we found an item */
	      /* Now we will print out ""                        */
	      fmtArgs[i]=(Char *)NSL_Implied_Attribute_Value;
	    }
	  }
	  /* fmtArgs[i]=(Char *)((NSL_Item*)(dptr->first))->data->first; */
	  /* dangerous in mixed content */
	  break;
	case NSL_text_data:
	  fmtArgs[i]=(Char *)dptr->first;
	  break;
	default:
	  SHOULDNT;
	}
      }
      else if ((int)(od->argv[i][0])<26) {
	/* hack! */
	n=(int)(od->argv[i][0]);
	len=rx->endp[n]-rx->startp[n];
	fmtArgs[i]=salloc((len+1) * sizeof(Char));
	fmtFreeMe[i] = 1;
	for(j=0; j<len; j++)
	     /* convert char8 to Char, being careful not to sign extend */
	    fmtArgs[i][j] = (unsigned char)rx->startp[n][j];
	fmtArgs[i][j] = 0;
      }
      else {
	switch (dptr->type) {
	case NSL_item_data:
	  fmtArgs[i]=(Char *)MyAV((NSL_Item*)dptr->first,od->argv[i]);
	  fmtFreeMe[i] = 1;
	  break;
	case NSL_text_data:
	  LT_ERROR1(NEAPPL,"No attributes on text: %s\n",od->argv[i]);
	  break;
	default:
	  SHOULDNT;
	}
      }
    }
    fmtArgs[i]=NULL;
    if (outf && outf->doctype->XMLMode) {
      VfprintfC(outf->file16,od->fmt,1,fmtArgs);
      }
    else {
      VfprintfC(Stdout,od->fmt,0,fmtArgs);
    }
    for (i=0;i<od->cnt;i++) {
	if(fmtFreeMe[i])
	    sfree(fmtArgs[i]);
    }
    break;
  default:
    if (od->cnt>=0) {
      /* find cntth daughter */
      for (i=od->cnt;
	   (dptr && i);
	   dptr=dptr->next) {
	i--;
      }
    }
    else {
      /* self */
    }
    if (dptr) {
      if (dptr->type==NSL_text_data) {
	PrintText(outf,(Char *)dptr->first);
      }
      else {
	switch (od->type) {
	case elt:
	  PrintItem(outf,(NSL_Item*)dptr->first);
	  break;
	case stag:
	  outf->state=PrintStartTagInternal(outf,outf->state,
					    (NSL_Item*)dptr->first);
	  break;
	case etag:
	  if (((NSL_Item*)dptr->first)->type==NSL_non_empty) {
	    PrintEndTag(outf,((NSL_Item*)dptr->first)->label);
	  }
	  break;
	default:
	  SHOULDNT;
	}
      }
    }
  }
}

extern WIN_IMP NSL_Data *FirstChild( const NSL_Item *, boolean);

boolean RetrieveSeqQueryData(NSL_Item *uitem, NSL_Query query,
			       const NSL_Data **fromRet) {

  /* require sequential matching */
  const NSL_Data *lnext,*ldata,*dptr,*from;
  const NSL_Item *link;
  const NSL_Query_I *rq;

  from=*fromRet;
  if (uitem==NULL || query==NULL) {
    return FALSE;
  }

  link=uitem->in->in;
  ldata=uitem->in;
  lnext=uitem->in->next;
  uitem->in->in=NULL;
  uitem->in->next=NULL;/* Stop the search from going above <uitem> */

  if (from!=NULL) {
    if ((from=NextDFSNoChildren( from, FALSE ))==NULL) {
      uitem->in->in=(NSL_Item*)link;
      uitem->in->next=(NSL_Data*)lnext;
      return FALSE;
    }
  }
  else {
    from=ldata;
  }

  for (dptr=from; dptr; ) {
    if ( (rq=InitSegQueryUp( query, dptr )) ) {
      if ((!rq->next) || ExecQueryUp( rq, dptr )) {
	break;
      }
      else {
	dptr=dptr->type==NSL_item_data?
	  FirstChild((const NSL_Item*)dptr->first,FALSE):
	  NULL;
      }
    }
    else {
      dptr=NULL; /* lose now */
    }
  }

  uitem->in->in=(NSL_Item*)link; /* restore the link */
  uitem->in->next=(NSL_Data*)lnext;
  *fromRet=dptr;
  return dptr?TRUE:FALSE;
}

boolean SubRpg(const NSL_Item *item,const subqd *sq,
	       boolean win,const NSL_Data **prevHit) {
  /* so I think polarity should negate BOTH Q and T, cf. top level */
  const NSL_Data *myHit=NULL;
  NSL_Data *dpt;
  const NSL_Data *dummy;
  boolean retRes;

  switch (sq->link) {
  case indep:
    break;
  case seq:
  case ser:
    myHit=*prevHit;
  case par:
    if (!win) {
      return FALSE;
    }
    break;
  default:
    SHOULDNT;
  }
  win=FALSE;
  while (!win) {
    /* What about preserve?
       Would have to write version of RQI which printed open tags as it went
       down and close tags as it went up after failed matches */
    if (sq->link==seq) {
      retRes=RetrieveSeqQueryData((NSL_Item*)item, sq->q, &myHit);
    }
    else {
      retRes=RetrieveQueryData((NSL_Item*)item, sq->q, &myHit, FALSE);
    }
    if (!retRes) {
      break;
    }
    if (sq->t) {
      if (myHit->type==NSL_text_data) {
	char8 *text = strdup_Char_to_char8(myHit->first);
	if (hsregexec(sq->t,text)) {
	  sfree(text);
	  win=TRUE;
	}
	sfree(text);
      }
      else {
	for (dpt=((NSL_Item*)myHit->first)->data; dpt; dpt=dpt->next) {
	  if (dpt->type==NSL_text_data) {
	    char8 *text = strdup_Char_to_char8(dpt->first);
	    if (hsregexec(sq->t,text)) {
	      sfree(text);
	      win=TRUE;
	      break;
	    }
	    sfree(text);
	  }
	}
      }
    }
    else {
      win=TRUE;
    }
    if (sq->link==seq) {
      /* win or lose on first try */
      break;
    }
  }
  if (win!=sq->polarity) {
    if (retRes) {
      dummy=NULL;
      ExpoRpg(myHit,sq->subs,sq->t,TRUE,&dummy);
      *prevHit=myHit;
    }
    return TRUE;
  }
  return FALSE;
}

boolean GroupRpg (const NSL_Item *item,const rgrp *rgp,const regexp *rx,
		  boolean win, const NSL_Data **prevHit) {
  const NSL_Data *myHit;

  myHit=*prevHit;

  for (;rgp;rgp=rgp->rest) {
    win=ExpoRpg(item->in,rgp->first,rx,win,&myHit);
  }
  if (myHit) {
    *prevHit=myHit;
  }
  return win;
}
      
boolean ExpDRpg(const NSL_Data *dptr,const expo *exp,const regexp *rx,
		boolean win,const NSL_Data **prevHit) {
  /* Implement subquery semantics wrt dptr, a higher-level hit */
  /* rx is the regexp which hit, if any */
  const ord *orptr;
  const NSL_Item *item=dptr->first;
  if (dptr->type==NSL_item_data) {
    switch (exp->type) {
    case subq:
      return SubRpg(item,exp->descr.sub,win,prevHit);
    case out:
      if (win) {
	OutRpg(dptr,exp->descr.out,rx);
      }
      return win;
    case or:
      for (orptr=exp->descr.ords;orptr;orptr=orptr->rest) {
	if (ExpoRpg(dptr,orptr->first,rx,win,prevHit)) {
	  return TRUE;
	}
      }
      return FALSE;
    case group:
      return GroupRpg(item,exp->descr.group,rx,win,prevHit);
    default:
      SHOULDNT;
      return FALSE;
    }
  }
  else {
    if (exp->type==out) {
      if (win) {
	OutRpg(dptr,exp->descr.out,rx);
      }
      return win;
    }
    else {
      LT_ERROR1(NEAPPL,"Sub-structure not allowed under # (sub-)query: %d\n",
	     exp->type);
      return FALSE;
    }
  }
}

boolean ExpoRpg(const NSL_Data *dptr,const expo *exp,const regexp *rx,
		boolean win,const NSL_Data **prevHit) {
  /* Implement exponent semantics */
  const NSL_Data *origHit=*prevHit;
  if (exp) {
    switch (exp->kt) {
    case one:
      return ExpDRpg(dptr,exp,rx,win,prevHit);
    case opt:
      ExpDRpg(dptr,exp,rx,win,prevHit);
      return TRUE;
    case plus:
      if (!ExpDRpg(dptr,exp,rx,win,prevHit)) {
	return FALSE;
      }
      if (!*prevHit || *prevHit==origHit) {
	return TRUE;
      }
    case star:
      while ((win=ExpDRpg(dptr,exp,rx,win,prevHit))&&
	     *prevHit&&*prevHit!=origHit) {
	origHit=*prevHit;
      }
      return TRUE;
    default:
      SHOULDNT;
      return FALSE;
    }
  }
  else {
    /* I think this is right, e.g. for empty subquery */
    return win;
  }
}

void FreeTopqd(topqd ** queries){
  int i;
  /* NB Note use of Global nq to tell us how big the array of queries is */
  for(i=0; i<nq; i++){
    sfree((outd *)(queries[i]->subs->descr.out));
    sfree((struct expo*)(queries[i]->subs));
    sfree(queries[i]);
  }
  sfree(queries);
}

int main(int argc, char **argv) {

  topqd **queries;
  int win;
  const NSL_Data *tdata=NULL;
  int ac=1;
  /* every matched element         */
  NSL_File inf,patf=NULL;
  NSL_Data *dpt;
  const NSL_Data *dummy;
  static NSL_Data holder={0,NSL_item_data,NULL,NULL,NULL};
  topqd *hit;
  const char *sgrpg_ddb_file;
  NSL_Common_Options *options;

#if 0
  /* 
     I've removed the default DDBFILE, because we have no way to stop it
     being used when the rule file is XML.  Now you have to either have
     an NSL declaration or pass the -D flag. (RMT)
   */
  if( !( sgrpg_ddb_file=getenv("LTNSL_SGRPG_DDBFILE"))){
    /* If the environment variable LTNSL_SGRPG_DDBFILE is set, then
       use it as the name of the DDB file for sgrpg rule files. Else
       use the built in SGRPG_DDB_FILE */
    sgrpg_ddb_file = SGRPG_DDB_FILE ;
  }
#else
  sgrpg_ddb_file = NULL;
#endif

  NSLInit(0);

  /* this argument processing should be cleaned up!!! */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  while (ac<argc) {
    if( STREQ(argv[ac],"-D")) {
      /* We are also allowed to Set place where sgrpg ddb file comes from. 
	 If using -f then -D option should appear before -f. */
      sgrpg_ddb_file = argv[++ac];
      ac++;
    } else if (STREQ(argv[ac],"-f")) {
      if(sgrpg_ddb_file)
	  sgdct=DoctypeFromDdb(sgrpg_ddb_file);
      else
	  sgdct = NULL;
      patf=SFopen(argv[++ac],sgdct,NSL_read|NSL_read_validate);
      ReadProlog(patf);
      sgdct=DoctypeFromFile(patf);
      ac++;
    } else if(STREQ(argv[ac],"-v")) {
	neg=TRUE;
	ac++;
    } else if(STREQ(argv[ac], "-r")) {
	ac++;
	attr_val_are_re = TRUE;	/* attribute values are regular expressions */
    } else if (argv[ac][0]=='-') {
	usage(2);
	break;
    } else {
      break;
    }
  }

  inf=SFFopen(stdin, dct, options->read_type, options->base_url);
  dct=DoctypeFromFile(inf);
  queries=ReadPatFile(patf,dct,ac,argc,argv);
  if (eltEver || preserveEver) {
    outf=SFFopen(stdout, dct, options->write_type, "stdout");
  }

  while ((item=GNQI(inf, queries, nq, &hit, outf))) {
    holder.first=item;
    item->in=&holder;
    for (tdata=NULL, win=FALSE;!win;) {
      
      if (!RetrieveQueryData(item, hit->vq, &tdata, FALSE)) {
	break;
      }
      else if (!hit->vt) {
	/* this is efficient and allows e.g. empty elements to match */
	win=TRUE;
	break;
      }
      else {
	if (tdata->type==NSL_text_data) {
	  char8 *text = strdup_Char_to_char8(tdata->first);
	  if (hsregexec(hit->vt,text)) {
	    sfree(text);
	    win=TRUE;
	  }
	  sfree(text);
	}
	else {
	  for (dpt=((NSL_Item*)tdata->first)->data; dpt; dpt=dpt->next) {
	    if (dpt->type==NSL_text_data) {
	      char8 *text = strdup_Char_to_char8(dpt->first);
	      if (hsregexec(hit->vt,text)) {
		sfree(text);
		win=TRUE;
		break;
	      }
	      sfree(text);
	    }
	  }
	}
      }
    }
    if (win!=hit->polarity) {
      dummy=NULL;
      ExpoRpg(&holder,hit->subs,hit->vt,TRUE,&dummy);
    }
    FreeItem(item);
  }
  /* FreeTopqd(queries); */
  if (outf) {
    SFrelease(outf,FALSE);
  }  
  if (patf) {
    SFrelease(patf,TRUE);
  }
  SFrelease(inf,TRUE);
  return 0;
}
