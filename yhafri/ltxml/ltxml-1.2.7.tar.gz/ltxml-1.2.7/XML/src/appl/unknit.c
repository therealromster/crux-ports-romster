/* quick and dirty unknitting application */

#include <stdio.h> /* for optarg etc. */
#include <stdlib.h>   /* for getpid() and unlink() */
#include "nsl.h"
#include "nslfile.h"		/* for encoding XXX */
#include "ctype16.h"
#include "string16.h"

static void usage(int exitval)
{
    fprintf(stderr, 
	  "usage: unknit [-he] [-d ddb] [-u base-url] basefile targetGI [sourceGI] <input-file\n");
    exit(exitval);
}

/* Present version assumes (hopeless hacks)  */
/* (1) we are using TEI.2 DTD                */
/* (2) which is defined in the file mar2.dtd */

int main(int argc, char **argv) {
  NSL_Bit bit,*bit1;
  NSL_Item *item;
  NSL_Data *first,*current;
  NSL_File inf, outf;
  NSL_Doctype dct=NULL;
  const Char *patLabel=0,*sourceLabel=0,*eltLabels[100],
             *docAttr,*idAttr,*toAttr,*fromAttr;
  Char scratch[100],*scp;
  char scratch8[100],tmpf[100];
  char *basefile, *targgi, *sourcegi=0;
  char basef[100],path[CWDBS];
  int arg,i,nelts=0,new,once=1;
  char *s;
  NSL_Common_Options *options;

  /* Initialise SAM API */

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hedu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  default:
	      usage(2);
	  }
  }

  if(argc - arg < 2 || argc - arg > 3)
      usage(2);

  basefile=argv[arg++];
  targgi=argv[arg++];
  if (arg<argc) {
    sourcegi=argv[arg];
  }

  inf=SFFopen(stdin, dct, options->read_type, options->base_url);
  dct=DoctypeFromFile(inf);
  if (DocumentIsNSGML(dct)) {
    char *ptr;
    /* need upper case for tag lookup */
    ptr=targgi;
    while (*ptr) {
      *ptr=Toupper(*ptr);
      ptr++;
    };
  };
  sprintf(tmpf,"/tmp/unk%d",(int)getpid());
  outf=SFopen(tmpf, dct, options->write_type | NSL_write_no_doctype);
  SetFileEncoding(Stdout, GetFileEncoding(outf->file16));
#ifdef GETWD
  sprintf(basef,"%s/%s",GETWD(path),basefile);
#else
  sprintf(basef,"%s",basefile);
#endif
  Fprintf(Stdout,
	  "<!DOCTYPE tei.2 SYSTEM \"mar2.dtd\" [\n"
	  "<!ENTITY dd SYSTEM \"%s\" CDATA SGML>\n"
          "]>\n"
	  "<?NSL LINKS %s",
	  basef, targgi);

  /* Find the unique name of the target element in the doctype declaration */
  patLabel=ElementUniqueName8(dct,targgi,0);
  if( patLabel == NULL ){
    LT_ERROR1(NEAPPL,"Error SGML element %s is not defined in DTD\n",targgi);
  }
  /* If we have specified a source element, then find its definition */
  if (sourcegi) {
    sourceLabel=ElementUniqueName8(dct,sourcegi,0);
    if( sourceLabel == NULL ){
      LT_ERROR1(NEAPPL,"Error SGML element %s is not defined in DTD\n",sourcegi);
    }
  }
  docAttr=AttrUniqueName8(dct,"DOC",3);
  idAttr=AttrUniqueName8(dct,"ID",2);
  fromAttr=AttrUniqueName8(dct,"FROM",4);
  toAttr=AttrUniqueName8(dct,"TO",2);

  CopyBit(&bit,GetNextBit(inf)); /* necessary because return value of
				   GetNextBit is reused */
  while ((bit1=GetNextBit(inf))) {
    switch (bit1->type) {
    case NSL_start_bit:
      if (bit1->label==patLabel &&
	  bit.type==NSL_start_bit &&
	  ((!sourcegi) || bit.label==sourceLabel)) {
	item=bit1->value.item;
	ItemParse(inf,item);
	current=first=NewNullNSLData(dct);
	current->type=NSL_item_data;
	first->first=item;
	while ((bit1=GetNextBit(inf))) {
	  if (bit1->type==NSL_start_bit &&
	      bit1->label==patLabel) {
	    current->next=NewNullNSLData(dct);
	    current=current->next;
	    current->first=bit1->value.item;
	    current->type=NSL_item_data;
	    ItemParse(inf,current->first);
	  } else if (bit1->type==NSL_text_bit &&
		     bit1->value.body[0] == '\n' && bit1->value.body[1] == 0) {
	    /* isolated RS can be ignored */
	    FreeBit(bit1);
	  } else {
	    break;
	  }
	}
	/* so now we have a sequence of target items, better be looking at
	   end of enclosing item */
	if (bit1->type==NSL_end_bit &&
	    bit1->label==bit.label) {
	  /* put pointer in supervening element */
	  item=bit.value.item;
	  if (once) {
	    /* subsequent items default to this one */
	    NewAttrVal(item,docAttr, strdup_char8_to_Char("dd"));
	    once=0;
	  }
	  Sprintf(scp=scratch, InternalCharacterEncoding, "id (%S)",
		  FindAttr(((NSL_Item*)(first->first))->attr,
			   idAttr)->value.string);
	  NewAttrVal(item,fromAttr,Strdup(scratch));
	  if (first!=current) {
	    scp+=Strlen(scratch)+1;
	    Sprintf(scp, InternalCharacterEncoding, "id (%S)",
		    FindAttr(((NSL_Item*)(current->first))->attr,
			     idAttr)->value.string);
	    NewAttrVal(item,toAttr,Strdup(scp));
	  }
	  /* keep track of GIs which have links from */
	  new=1;
	  for (i=0;i<nelts;i++) {
	    if (eltLabels[i]==(item->label)) {
	      new=0;
	      break;
	    }
	  }
	  if (new) {
	    eltLabels[nelts++]=item->label;
	    Fprintf(Stdout," %S", item->label);
	  }
	  PrintBit(outf,&bit);
	  PutAttrVal(item,toAttr,0); /* protect from freeing */
	  if (first!=current) {
	    PutAttrVal(item,fromAttr,0);
	  }
	  FreeBit(&bit); /* note this will NOT free the bit itself, only
			    contents if necessary */
	  CopyBit(&bit,bit1);
	} else {
	  /* arghh, have to put everything out as is */
	  PrintBit(outf,&bit);
	  FreeBit(&bit);
	  CopyBit(&bit,bit1);
	  current=first;
	  do {
	    PrintItem(outf,current->first);
            current=current->next;
	  } while (current);
	}
	FreeData(first, dct);
	continue;
      }
      break;
    case NSL_text_bit:
    case NSL_end_bit:
    case NSL_empty_bit:
      break;
    default:
      SHOULDNT;
      break;
    }
    PrintBit(outf,&bit);
    FreeBit(&bit);
    CopyBit(&bit,bit1);
  }
  PrintBit(outf,&bit);
  ForceNewline(outf);
  SFrelease(outf,FALSE);
  SFrelease(inf,TRUE);
  Fprintf(Stdout, ">\n"); /* end of NSL LINKS pi */
  fflush(stdout);
  /* there must be a way to do this with a system call . . . */
  sprintf(scratch8,"cat %s",tmpf);
  system(scratch8);
  unlink(tmpf);

  return 0;
}
