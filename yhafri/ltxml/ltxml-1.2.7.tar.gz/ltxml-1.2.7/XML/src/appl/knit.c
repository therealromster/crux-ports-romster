/* 	$Id: knit.c,v 1.38 1999/06/03 16:21:13 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: knit.c,v 1.38 1999/06/03 16:21:13 richard Exp $";
#endif /* lint */
/* 
 * knit [-r attr-spec] [-i attr-spec] [input.xml] >output.xml
 *
 * Insert linked-to material specified by a subset of the XML-LINK
 * standard.

 * Elements which have an xml:link="simple" attribute are inspected,
 * and if they have attributes matching an attr-spec they are replaced
 * by the resource specified by the href attribute, which must
 * be of the form url#id(name)[..id(name)].

 * -r means replace the whole element, -i means insert as the content
 * of the element.

 * attr-specs are of the form name=value,name=value,...
 * Quoting should be allowed in them but isn't.

 * If no -r or -i options are given, the default is
 *
 *    -r show=replace,actuate=auto -i show=embed,actuate=auto
 */

#include <assert.h>
#include "nsl.h"
#include "nsllib.h"
#include "hsregexp.h"
#include "ctype16.h"
#include "string16.h"
#include "url.h"

struct document {
    const char *url;
    NSL_File file;
    NSL_Doctype doctype;
    const Char *cached_id;
    size_t cached_offset;
    int seekable;
    int at_start;
    int busy;
    struct attr_spec *attr_specs;
    const Char *href_attr, *xml_link_attr;
    struct document *next;
} *documents = 0;
int ndocuments = 0;

#define MAX_DOCUMENTS 50

struct attr_spec {
    enum action {None, Insert, Replace} action;
    int nattrs;
    struct attr_spec *next;
    struct attval {const Char *name; const Char *value;} attval[1]; /* "struct hack" */
} *attr_specs = 0;

struct document top;

static enum action link_type(struct document *doc, NSL_Bit *bit,
			     char **url, Char **from, Char **to);
static struct document *find_document(const char *url, const char *base);
static void transcribe(struct document *doc, Char *from, Char *to, int levels);
static void process_editarg(const char *arg, enum action action);
static char *submatch(regexp *pattern, int sub);
static void usage(int exitval);
static int ensure_seekable(struct document *doc);
static void skip_item(NSL_File file);
static void set_doc_attr_specs(struct document *doc);
static void discard_document(struct document *doc);
static void recently_used(struct document *doc);
static void prune_documents(void);

static NSL_File outf;

int read_type;

Char *transbuf;

int main(int argc, char **argv)
{
    struct document *doc, *next;
    int spec_present = 0, max_depth = 9999;
    NSL_Doctype dct = 0;
    NSL_Doctype outdct;
    int arg;
    char *s;
    NSL_Common_Options *options;

    /* Initialise the library */

    NSLInit(0);

    /* Read command line options */

    options = NSLGetoptions(&argc, argv, "hdeu", usage);
    dct = options->doctype;
    read_type = options->read_type;

    for(arg = 1; arg < argc; arg++)
    {
	if(argv[arg][0] != '-')
	    break;
	for(s = &argv[arg][1]; *s; s++)
	    switch(*s)
	    {
	    case 'r':
		if(arg+1 == argc)
		    usage(2);
		process_editarg(argv[++arg], Replace);
		spec_present = 1;
		break;
	    case 'i':
		if(arg+1 == argc)
		    usage(2);
		process_editarg(argv[++arg], Insert);
		spec_present = 1;
		break;
	    case '1':
		max_depth = 1;
		break;
	    default:
		usage(2);
	    }
    }

    if(!spec_present)
    {
	process_editarg("show=replace,actuate=auto", Replace);
	process_editarg("show=embed,actuate=auto", Insert);
    }

    /* Open the files */

    switch(argc - arg)
    {
    case 0:
	top.file = OpenStream(stdin, dct, read_type, CE_unknown, 
			      options->base_url);
	break;
    default:
	top.file = OpenURL(argv[arg++], dct, read_type, CE_unknown, 0);
	break;
    }

    outdct=DoctypeFromFile(top.file); 

    top.url = GetFileURL(top.file);
    top.doctype = DoctypeFromFile(top.file);
    set_doc_attr_specs(&top);
    /* other fields not relevant for top-level document */

    outf = OpenStream(stdout, outdct, options->write_type, CE_unknown,
		      "<stdout>");

#ifdef DEBUG
    fprintf(stderr, "base url is %s\n", top.url);
#endif

    transcribe(&top, 0, 0, max_depth);

    while(arg < argc)
    {
	static Char linefeed[] = {'\n',0};
	PrintTextLiteral(outf, linefeed);
	SFrelease(top.file, DoctypeFromFile(top.file) != outdct);
	sfree(top.attr_specs);
	for(doc = documents; doc; doc = next)
	{
	    next = doc->next;
	    SFrelease(doc->file, 1);
	    sfree(doc->attr_specs);
	    sfree((void *)doc->url);
	    sfree(doc);
	}
	documents = 0;
	ndocuments = 0;
	top.file = OpenURL(argv[arg++], dct, read_type, CE_unknown, 0);
	top.url = GetFileURL(top.file);
	top.doctype = DoctypeFromFile(top.file);
	set_doc_attr_specs(&top);
	transcribe(&top, 0, 0, max_depth);
    }

    SFrelease(top.file, DoctypeFromFile(top.file) != outdct);
    sfree(top.attr_specs);
    for(doc = documents; doc; doc = next)
    {
	next = doc->next;
	SFrelease(doc->file, 1);
	sfree(doc->attr_specs);
	sfree((void *)doc->url);
	sfree(doc);
    }
    SFclose(outf);
    FreeDoctype(outdct);

    return 0;
}

/* 
 * Copy the attribute specs into a document structure, uniquifying the
 * names w.r.t. the document's doctype.
 */

static void set_doc_attr_specs(struct document *doc)
{
    struct attr_spec *old, *new;
    int i;

    doc->xml_link_attr = AttrUniqueName8(doc->doctype, "xml:link", 0);
    doc->href_attr = AttrUniqueName8(doc->doctype, "href", 0);

    doc->attr_specs = 0;

    for(old = attr_specs; old; old = old->next)
    {
	new = salloc(sizeof(*new) + (old->nattrs - 1) * sizeof(struct attval));
	new->action = old->action;
	new->nattrs = old->nattrs;
	for(i=0; i<old->nattrs; i++)
	{
	    new->attval[i].name = 
		AttrUniqueName(doc->doctype, old->attval[i].name, 0);
	    new->attval[i].value = old->attval[i].value;
	}
	new->next = doc->attr_specs;
	doc->attr_specs = new;
    }
}


/* 
 * Examine an item.  If it is a relevant link set the URL and start and end
 * IDs of the target and return Insert or Replace, otherwise return None.
 */

static enum action link_type(struct document *doc, NSL_Bit *bit,
			     char **url, Char **from, Char **to)
{
    NSL_Item *item;
    const Char *value;
    static Char simple[] = {'s','i','m','p','l','e',0};
    static regexp *locator_re_0, *locator_re_1, *locator_re_2;
    struct attr_spec *a;
    int i;
    char8 *value8, *fromx, *tox;

    item = bit->value.item;

    if(!locator_re_1)
    {

	/* XXX get rid of this regexp stuff so we can have 16-bit names? */
	locator_re_0 = hsregcomp("^([^#]*)$");
	locator_re_1 = hsregcomp("^([^#]*)#"
				 "[iI][dD]\\(([_a-zA-Z][-._0-9a-zA-Z]*)\\)$");
	locator_re_2 = hsregcomp("^([^#]*)#"
				 "[iI][dD]\\(([_a-zA-Z][-._0-9a-zA-Z]*)\\)"
				 "\\.\\."
				 "[iI][dD]\\(([_a-zA-Z][-._0-9a-zA-Z]*)\\)$");
    }

    /* See if we have an XML-LINK attribute ... */

    value = GetAttrStringVal(item, doc->xml_link_attr);

#ifdef DEBUG
    {
	Char none[] = {'<','n','o','n','e','>',0};
	Fprintf(Stderr, "element %S had %S(%x)=%S\n",
		item->label, doc->xml_link_attr, doc->xml_link_attr, 
		value ? value : none);
    }
#endif

    if(!value)
	return None;

    /* ... and that it's xml:link=simple */

    if(Strcasecmp(value, simple) != 0)
    {
#if 0
	fprintf(stderr, "warning: xml:link attribute for \"%s\" had value "
		        "\"%s\" (only \"simple\" is handled)\n",
		item->label, value);
#endif
	return None;
    }

    /* Do we have a relevant set of attributes? */

    for(a = doc->attr_specs; a; a = a->next)
    {
	for(i=0; i<a->nattrs; i++)
	{
	    value = GetAttrStringVal(item, a->attval[i].name);
	    if(!value || Strcasecmp(value, a->attval[i].value) != 0)
		break;
	}
	if(i == a->nattrs)
	    break;
    }

    if(!a)
	return None;

#if 0
    /* Actually, it's quite reasonable to insert into an empty element
       in XML, since the empty tag syntax isn't restricted to elements
       declared empty in the DTD. */
    /* Check we haven't been asked to insert into an empty element */

    if(a->action == Insert && bit->type == NSL_empty_bit)
    {
	Fprintf(Stderr,
		"warning: attempt to insert into empty element %S ignored\n",
		bit->label);
	return None;
    }
#endif

    /* Yes, we should process this item, so we need a valid HREF */

    value = GetAttrStringVal(item, doc->href_attr);
    
#ifdef DEBUG
    Fprintf(Stderr, "href='%S'\n", value);
#endif
    if(!value || value == NSL_Implied_Attribute_Value)
    {
	Fprintf(Stderr,
		"warning: xml:link attribute for \"%S\" didn't "
		        "have href attribute\n", 
		item->label);
	return None;
    }

    value8 = strdup_Char_to_char8(value);
    if(hsregexec(locator_re_2, value8))
    {
	*url = submatch(locator_re_2, 1);
	fromx = submatch(locator_re_2, 2);
	tox = submatch(locator_re_2, 3);
	sfree(value8);
	*from = strdup_char8_to_Char(fromx);
	sfree(fromx);
	*to = strdup_char8_to_Char(tox);
	sfree(tox);
#ifdef DEBUG
	Fprintf(Stderr,
		"link: URL  <%s> from <%S> to <%S>\n", *url, *from, *to);
#endif
	return a->action;
    }
    else if(hsregexec(locator_re_1, value8))
    {
	*url = submatch(locator_re_1, 1);
	fromx = submatch(locator_re_1, 2);
	sfree(value8);
	*from = strdup_char8_to_Char(fromx);
	sfree(fromx);
	*to = Strdup(*from);
#ifdef DEBUG
	Fprintf(Stderr, "link: URL <%s> element <%S>\n", *url, *from);
#endif
	return a->action;
    }
    else if(hsregexec(locator_re_0, value8))
    {
	*url = submatch(locator_re_0, 1);
	sfree(value8);
	*from = *to = 0;
#ifdef DEBUG
	Fprintf(Stderr, "link: URL <%s>\n", *url);
#endif
	return a->action;
    }
    else
    {
	sfree(value8);
	Fprintf(Stderr,
		"warning: xml:link attribute for \"%S\" had "
		        "invalid locator \"%S\"\n", 
		item->label, value);
	return None;
    }
}

/* 
 * Open a URL unless we already have it open.
 */

static struct document *find_document(const char *url, const char *base)
{
    struct document *doc;
    const char *p;
    
    /* If the URL is an empty string, we want the containing document.
       Otherwise normalise the URL */

    if(url[0] == '\0')
	url = strdup8(base);
    else
    {
	url = url_merge(url, base, 0, 0, 0, 0);
	if(!url)
	    return 0;
    }

    /* Do we already have the file open? */

    for(doc = documents; doc; doc = doc->next)
	if(strcmp8(url, doc->url) == 0  && !doc->busy)
	    break;

    /* If not, open it */

    if(!doc)
    {
#ifdef DEBUG
	fprintf(stderr, "opening URL %s\n", url);
#endif
	prune_documents();
	doc = salloc(sizeof(*doc));
	doc->url = url;
	p = url+strlen8(url);
	if(strncasecmp8(doc->url, "file:", 5) == 0 &&
	   strcmp8(p-2, ".Z") != 0 && strcmp8(p-3, ".gz") != 0)
	    doc->seekable = TRUE;
	else
	    doc->seekable = FALSE;
	doc->busy = 0;
	doc->file = OpenURL(url, 0, read_type, CE_unknown, "");
	if(!doc->file)
	{
	    Fprintf(Stderr, "warning: can't open URL %s\n", url);
	    return 0;
	}
	doc->doctype = DoctypeFromFile(doc->file);
	set_doc_attr_specs(doc);
	doc->cached_id = 0;
	doc->cached_offset = 0;
	doc->next = documents;
	documents = doc;
	ndocuments++;
    }

    return doc;
}

/* 
 * Transcribe part or all of a document.
 */

static void transcribe(struct document *doc, Char *from, Char *to, int level)
{
    NSL_Bit *bit = 0;
    int depth;
#ifdef DEBUG
    Fprintf(Stderr, "transcribing URL <%s> from <%S> to <%S>\n",
	    doc->url, from, to);
#endif
#if 0
    if(doc->busy)
    {
	Fprintf(Stderr, "warning: rejecting link loop involving URL \"%s\"\n",
		doc->url);
	return;
    }
#endif
    /* Find the start item */

    if(!from)
    {
	/* We're already there */
    }
    else if(doc->cached_id && Strcmp(from, doc->cached_id) == 0)
    {
	/* We know where it is */
	if(!ensure_seekable(doc))
	    return;
#ifdef DEBUG
	Fprintf(Stderr, "seeking to ID %S in %s\n", from, doc->url);
#endif
	if(SFseek(doc->file, doc->cached_offset) == -1)
	{
	    Fprintf(Stderr, "seek failed\n");
	    exit(1);
	}
	assert(SFtell(doc->file) == doc->cached_offset);
    }
    else
    {
	/* We don't know where it is, read until we find it */
	/* Two passes: from current to end, and from start to current */

	int pass;

#ifdef DEBUG
	Fprintf(Stderr, "searching for start ID %S\n", from);
#endif
	for(pass = 1; pass <= (doc->at_start ? 1 : 2); pass++)
	{
	    if(pass == 2)
	    {
		/* We reached end of file, start again at the beginning */
#ifdef DEBUG
		fprintf(stderr, "rewinding %s\n", doc->url);
#endif
		if(!ensure_seekable(doc))
		    return;
		if(SFseek(doc->file, 0) == -1)
		{
		    Fprintf(Stderr, "rewind failed\n");
		    exit(1);
		}
	    }
	    
	    if(doc->seekable)
		doc->cached_offset = SFtell(doc->file);
	    while((bit = GetNextBit(doc->file)))
	    {
		Char *id;

#ifdef DEBUG
		if(bit->type == NSL_start_bit ||
		   bit->type == NSL_empty_bit)
		{
		    if((id = GetIdVal(bit->value.item)))
			Fprintf(Stderr, "id %S: %s\n",
				id, Strcasecmp(id, from) ? "no" : "yes");
		    else
			Fprintf(Stderr, "%S has no id\n", bit->label);
		}
#endif
		if((bit->type == NSL_start_bit || 
		    bit->type == NSL_empty_bit) &&
		   (id = GetIdVal(bit->value.item)) &&
		   Strcasecmp(id, from) == 0)
		    goto found;
		FreeBit(bit);
		if(doc->seekable)
		    doc->cached_offset = SFtell(doc->file);
	    }
	}

	/* We didn't find it */

	Fprintf(Stderr, "warning: start ID %S not found in %s\n", 
		from, doc->url);
	doc->cached_id = 0;
	doc->at_start = 0;

	return;

    found:
	/* We found the start (or only) ID */

	if(doc->cached_id)
	    sfree((Char *)doc->cached_id);
	if(doc->seekable)
	    doc->cached_id = Strdup(from);
    }

    doc->at_start = 0;
    doc->busy = 1;

    /* Copy bits until we reach the end ID */

    if(!bit)
	bit = GetNextBit(doc->file);

#ifdef DEBUG
    if(from)
	assert(Strcasecmp(GetIdVal(bit->value.item), from) == 0);
#endif

    depth = 0;			/* becomes >0 inside end item */
    while(bit)
    {
	Char *id;
	char *new_url;
	Char *new_from, *new_to;
	struct document *new_doc;
	enum action action;

	switch(bit->type)
	{
	case NSL_start_bit:
	case NSL_empty_bit:
	    id = GetIdVal(bit->value.item);
	    if(level > 0)
		action = link_type(doc, bit, &new_url, &new_from, &new_to);
	    else
		action = None;
	    if(action == None)
	    {
		PrintBit(outf, bit);
		if(id && to && Strcasecmp(id, to) == 0)
		{
		    if(bit->type == NSL_empty_bit)
		    {
			FreeBit(bit);
			doc->busy = 0;
			recently_used(doc);
#ifdef DEBUG
			Fprintf(Stderr,
	       "finished transcribing URL <%s> at empty tag <%S>\n",
				doc->url, to);
#endif
			return;
		    }
		    else
		    {
#ifdef DEBUG
			Fprintf(Stderr,
	        "almost finished transcribing URL <%s>; in item <%S>\n",
				doc->url, to);
#endif
			depth = 1;
			break;
		    }
		}
		if(bit->type == NSL_start_bit && depth > 0)
		{
		    depth++;
#ifdef DEBUG
		    Fprintf(Stderr, "incrementing depth to %d\n", depth);
#endif
		}
		break;
	    }
	    if(action == Insert)
	    {
		if(bit->type == NSL_start_bit)
		{
		    NSL_Bit save = *bit;
		    skip_item(doc->file);
		    *bit = save;
		}
		else		/* bit->type == NSL_empty_bit */
		{
		    /* It's going to be non-empty now */
		    bit->type = NSL_start_bit; 
		    bit->value.item->type = NSL_inchoate;
		}
		PrintBit(outf, bit);
	    }
	    else if(bit->type == NSL_start_bit)
		skip_item(doc->file);
	    new_doc = find_document(new_url, doc->url);
	    if(new_doc)
		transcribe(new_doc, new_from, new_to, level-1);
	    sfree(new_url);
	    sfree(new_from);
	    sfree(new_to);
	    if(action == Insert)
		PrintEndTag(outf, bit->value.item->label);
	    if(id && to && Strcasecmp(id, to) == 0)
	    {
		doc->busy = 0;
		recently_used(doc);

#ifdef DEBUG
		Fprintf(Stderr,
	       "finished transcribing URL <%s> at linked tag <%S>\n",
				doc->url, to);
#endif
		return;
	    }
	    break;
	case NSL_end_bit:
	    PrintBit(outf, bit);
#ifdef DEBUG
	    if(depth > 0)
		Fprintf(Stderr, "decrementing depth to %d\n", depth-1);
#endif
	    if(depth > 0 && --depth == 0)
	    {
		FreeBit(bit);
		doc->busy = 0;
		recently_used(doc);

#ifdef DEBUG
		Fprintf(Stderr, "finished transcribing URL <%s> at tag <%S>\n",
				doc->url, to);
#endif
		return;
	    }
	    break;
	default:
	    PrintBit(outf, bit);
	}
	
	FreeBit(bit);
	bit = GetNextBit(doc->file);
    }

    if(to)
	/* Oops, we reached end of file without seeing the end ID */
	Fprintf(Stderr, "warning: end ID %S not found in %s\n", to, doc->url);

    /* When we finish at the end of a file, throw it away to save
       file descriptors, since we probably won't want it again. */
    discard_document(doc);
}

static void skip_item(NSL_File file)
{
    int depth = 1;
    NSL_Bit *bit;
    
    while(depth > 0 && (bit = GetNextBit(file)))
    {
#ifdef DEBUG
	Fprintf(Stderr, "skipping ");
	switch(bit->type)
	{
	case NSL_start_bit:
	    Fprintf(Stderr, "start bit: %S\n", bit->label);
	    break;
	case NSL_empty_bit:
	    Fprintf(Stderr, "empty bit: %S\n", bit->label);
	    break;
	case NSL_end_bit:
	    Fprintf(Stderr, "end bit: %S\n", bit->label);
	    break;
	default:
	    Fprintf(Stderr, "other bit\n");
	    break;
	}
#endif
	if(bit->type == NSL_start_bit)
	    depth++;
	else if(bit->type == NSL_end_bit)
	    depth--;
	FreeBit(bit);
    }
}

static int ensure_seekable(struct document *doc)
{
    FILE *local;
    FILE16 *remote;
    int n;
    unsigned char buf[1024];

    if(doc->seekable)
	/* Already copied */
	return 1;

#ifdef DEBUG
    fprintf(stderr, "copying URL %s\n", doc->url);
#endif

    /* Need to copy it */

    /* This code was written aassuming we can get a FILE * connected to
     * the URL, which might not be true.  XXX.
     */

    if(!(remote = url_open(doc->url, "", "r", 0)))
    {
	Fprintf(Stderr, "warning: can't re-open URL %s\n", doc->url);
	return 0;
    }

    local = tmpfile();
    if(!local)
    {
	Fprintf(Stderr, "warning: can't create temporary copy of URL %s\n",
		doc->url);
	Fclose(remote);
	return 0;
    }

    while((n = Readu(remote, buf, sizeof(buf))) > 0)
	fwrite(buf, 1, n, local);

    if(n < 0 || ferror(local))
    {
	Fprintf(Stderr, "warning: error copying URL %s\n", doc->url);
	Fclose(remote);
	fclose(local);
	return 0;
    }

    SFrelease(doc->file, 1);

    Fclose(remote);
    rewind(local);

    doc->file = OpenStream(local, 0, read_type, CE_unknown, doc->url);
    doc->doctype = DoctypeFromFile(doc->file);
    set_doc_attr_specs(doc);
    doc->cached_id = 0;
    doc->at_start = 0;
    doc->seekable = 1;

    return 1;
}

#if 0

/* 
 * GetAttrStringVal won't let us look for undeclared attributes, so
 * do it by hand.
 */

static const char *MyGetAttrStringVal(NSL_Item *item, char *name)
{
    NSL_Attr *attr = FindAttr(item->attr, name);

#if 0
    AttributeSummary *sum=(AttributeSummary *)(item->defn + 1);
    int i;

    fprintf(stderr, "attributes for %s: ", item->label);
    for(i=0; i<item->defn->numAttr; i++)
	fprintf(stderr, "%s[%s] ",
		(char *)&sum[i] + sum[i].namePtr,
		sum[i].defaultPtr ? (char *)&sum[i] + sum[i].defaultPtr : "none");
    fprintf(stderr, "\n");
#endif

    if(attr) {
	return attr->value.string;
    } else {
	const AttributeSummary *atsum = FindAttrSpec(item->defn,
						     item->doctype,
						     name);
	if(atsum) {
	    const Char *def = GetAttrDefVal(atsum);
	    if(def != NSL_Implied_Attribute_Value)
		return def;
	}
    }
    return 0;
}

#endif

static void process_editarg(const char *arg, enum action action)
{
    struct attr_spec *spec;
    static regexp *pattern = 0;
    char *p;
    int i, nattrs = 0;

    if(!pattern)
	pattern = 
	    hsregcomp("^([_a-zA-Z][-._0-9a-zA-Z]*)=([^,]+),?");

    for(p=(char *)arg; hsregexec(pattern, p); p=pattern->endp[0])
	nattrs++;
    if(*p)
	usage(2);

    spec = salloc(sizeof(*spec) + (nattrs - 1) * sizeof(struct attval));
    spec->nattrs = nattrs;
    spec->action = action;
    spec->next = attr_specs;
    attr_specs = spec;

    for(i=0, p=(char *)arg; hsregexec(pattern, p); i++, p=pattern->endp[0])
    {
	char8 *t = submatch(pattern, 1);
	spec->attval[i].name = strdup_char8_to_Char(t);
	sfree(t);
	t = submatch(pattern, 2);
	spec->attval[i].value = strdup_char8_to_Char(t);
	sfree(t);
    }
}

static void usage(int exitval)
{
    fprintf(stderr, "usage: knit [-hdeu] [-1] [-r name=value,...] "
	    "[-i name=value,...] [input-file]\n");
    exit(exitval);
}

/* Also defined in sgmlfiles.c */

static char *submatch(regexp *pattern, int sub)
{
    int len = pattern->endp[sub] - pattern->startp[sub];
    char *new = salloc(len + 1);
    strncpy(new, pattern->startp[sub], len);
    new[len] = '\0';
    return new;
}

/* Move a document to the front of the list, since it may well be
   used again and shouldn't be pruned. */

static void recently_used(struct document *doc)
{
    struct document *d, *p;

    /* Find the document and its predecessor */

    for(p=0, d=documents; d != doc; p=d, d=d->next)
	;

    assert(d);

    /* Move it to the start */

    if(!p)
	return;			/* it's already there */

    p->next = doc->next;
    doc->next = documents;
    documents = doc;
}

/* Discard a document if we have too many open */

static void prune_documents(void)
{
    struct document *d, *doc = 0;

    while(ndocuments >= MAX_DOCUMENTS)
    {

	/* Find the least-recently used document */

	for(d=documents; d; d=d->next)
	    if(!d->busy)
		doc = d;

	if(!doc)
	{
	    fprintf(stderr, "warning: MAX_DOCUMENTS exceeded, you may run out "
			    "of file descriptors\n");
	    return;
	}

	/* and get rid of it */
	
	discard_document(doc);
    }
}

/* Close a no-longer-required document and remove it from the list */

static void discard_document(struct document *doc)
{
    struct document *d, *p;

    if(doc == &top)
	return;

#ifdef DEBUG
    fprintf(stderr, "discarding URL %s\n", doc->url);
#endif

    /* Find the document and its predecessor */

    for(p=0, d=documents; d != doc; p=d, d=d->next)
	;

    assert(d);

    /* Remove doc from list */

    if(p)
	p->next = doc->next;
    else
	documents = doc->next;

    ndocuments--;

    /* Close and free doc */

    SFrelease(doc->file, 1);
    sfree(doc->attr_specs);
    sfree((void *)doc->url);
    sfree(doc);
}

