/* ============================================================== */
/* SGWHERE    version 1.2                                         */
/* ============================================================== */

#include "nsl.h"
#include "nsllib.h"		/* for defaultOutputEncoding XXX */
#include "string16.h"
#include "hsregexp.h"

void PrintItemPath(FILE16 *f, CharacterEncoding enc, NSL_Item *item){
  if( item ){
    if( ! item->in){
      fprintf(stderr,"Item not in anything\n");
    } else {
      PrintItemPath(f, enc, item->in->in);
      Fprintf(f, "/%S[%d]",item->label,item->in->ref);
    }
  }    
}

static void usage(int exitval)
{
    fprintf(stderr, "usage:\n\
\n\
   nslwhere [-d ddb-file] [-u base_url] [-e] [-v] [-n] [-r] \n\
             -q query [ -s sub-query] [-t regexp] [file]\n\
\n\
   -d ddb-file:  Take Dtd from specified ddb file\n\
   -e: don't expand entities\n\
   -v: invert sense of sub-query+regexp\n\
   -n: don't force a newline between output matches\n\
   -r: attribute values in queries are regular expressions\n\
   -q query:  Main query\n\
   -s sub-query: Sub query\n\
   -t regexp:  Regular expression\n\
"); 
    exit(exitval);
}

int main(int argc, char **argv) {
  int neg=FALSE, print, start;
  NSL_Item *item, *titem=NULL;
  NSL_Query pos;
  regexp *rexp;
  int arg, 
      attr_val_are_re = FALSE,  /* If TRUE then attribute values in queries are
				   regular expressions, if FALSE then they are
				   just literal strings */
      nlSep=TRUE;		/* Add newline separator between */
  /* every matched element         */
  NSL_File inf = NULL;
  NSL_Doctype dct=NULL;
  NSL_Query q;
  NSL_Data *dpt;
  /* static NSL_Data holder={0,NSL_item_data,NULL,NULL,NULL}; */
  char *posstr = NULL, *qstr = NULL, *rexpstr = NULL;
  CharacterEncoding enc;
  char *s;
  NSL_Common_Options *options;

  NSLInit(0);

  /* Read command line options */

  options = NSLGetoptions(&argc, argv, "hdeu", usage);
  dct = options->doctype;

  for(arg = 1; arg < argc; arg++)
  {
      if(argv[arg][0] != '-')
	  break;
      for(s = &argv[arg][1]; *s; s++)
	  switch(*s)
	  {
	  case 'v':
	      neg = TRUE;
	      break;
	  case 'n':
	      nlSep=FALSE;	/* NO nl separator between elements */
	      break;
	  case 'r':
	      attr_val_are_re = TRUE;	/* attribute values are regexps */
	      break;
	  case 'q':
	      if(arg+1 == argc)
		  usage(2);
	      posstr = argv[++arg]; /* Main query */
	      break;
	  case 's':
	      if(arg+1 == argc)
		  usage(2);
	      qstr = argv[++arg];   /* Sub query */
	      break;
	  case 't':
	      if(arg+1 == argc)
		  usage(2);
	      rexpstr = argv[++arg]; /* regular expression */
	      break;
	  default:
	      usage(2);
	  }
  }

  if(argc - arg > 1)
      usage(2);

  if( argc > arg)
      inf=SFopen(argv[arg], dct, options->read_type);
  else
      inf=SFFopen(stdin, dct, options->read_type, options->base_url);

  dct=DoctypeFromFile(inf);
  enc = dct->defaultOutputEncoding;

  if( attr_val_are_re ){
    pos=ParseQueryR8(dct,posstr);
  } else {
    pos=ParseQuery8(dct,posstr);
  }

  if( qstr ) {
    if( attr_val_are_re ){
      q=ParseQueryR8(dct,qstr);
    } else {
      q=ParseQuery8(dct,qstr);
    }
  } else {
    if( attr_val_are_re ){
      q=ParseQueryR8(dct,(char*)".");
    } else {
      q=ParseQuery8(dct,(char*)".");
    }
  }

  /* check for empty regexp meaning anything */
  if( rexpstr ){
    rexp=strlen(rexpstr)==0?NULL:hsregcomp(rexpstr);
  } else {
    rexp=NULL;
  }

  for (start=0; (item=GetNextQueryItem(inf, pos, NULL)); ) {

    for(titem=NULL, print=FALSE;!print;) {
      titem=RetrieveQueryItem(item, q, titem);
      if(titem==NULL) {
	break;
      } else if (!rexp) {
	/* this is efficient and allows e.g. empty elements to match */
	print=TRUE;
	break;
      } else {
	for(dpt=titem->data; dpt; dpt=dpt->next){
	  if(dpt->type==NSL_text_data) {
	    char8 *text = strdup_Char_to_char8(dpt->first);
	    if (hsregexec(rexp,text)) {
	      sfree(text);
	      print=TRUE;
	      break;
	    }
	    sfree(text);
	  }
	}
      }
    }
    if (print) {
      if(!neg) {
	PrintItemPath(Stdout, enc, item);
	fprintf(stdout,"\n");
      }
    } else if (neg) {
      PrintItemPath(Stdout, enc, item);
      fprintf(stdout,"\n");
    }
    FreeItem(item);
    /* ResetSource(inf); For efficiency on large files */
    /*                   - but not yet tested fully    */
  }
  /* These calls of FreeQuery and SFrelease are not strictly necessary,
     but they cleanup memory leaks. */
  FreeQuery(pos);
  FreeQuery(q);
  SFrelease(inf,TRUE);
  return 0;
}

