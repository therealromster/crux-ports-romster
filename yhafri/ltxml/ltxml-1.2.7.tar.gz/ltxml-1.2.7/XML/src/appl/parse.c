/* The simplest possible LT NSL program (just about)
   Read an nSGML input stream, as a sequence of NSLBits
   and write it back out again */

#include "nsllib.h"


static void usage(int exitval)
{
    fprintf(stderr, "usage: xmlnorm [-d ddb-file] [-u base-url] [-hesVxX] [input-file]\n");
    exit(exitval);
}

int main(int argc, char **argv){
    NSL_Bit *nslbit;
    NSL_File_I *sf=0, *outf=0;
    NSL_Doctype dct = NULL;
    NSL_FType intype = NSL_read, outtype = NSL_write_normal;
    CharacterEncoding enc = CE_unknown;
    int silent = 0;
    int arg;
    char *s;
    NSL_Common_Options *options;

    NSLInit(0);

    /* Read command line options */

    options = NSLGetoptions(&argc, argv, "heduV", usage);
    dct = options->doctype;
    intype = options->read_type;
    outtype = options->write_type;

    for(arg = 1; arg < argc; arg++)
    {
	if(argv[arg][0] != '-')
	    break;
	for(s = &argv[arg][1]; *s; s++)
	    switch(*s)
	    {
	    case 's':
		silent = 1;
		break;
	    case 'x':
		/* Or with existing mode to allow -Vx */
		intype |= (NSL_read_strict|NSL_read_all_bits|
			   NSL_read_no_consume_prolog);
		break;
	    case 'X':
		outtype = (NSL_write|NSL_write_canonical|NSL_write_no_doctype);
		enc = CE_UTF_8;
		break;
	    default:
		usage(2);
	    }
    }

    switch(argc - arg)
    {
    case 0:
	sf = SFFopen(stdin, dct, intype, options->base_url);
	break;
    case 1:
	sf = SFopen(argv[arg], dct, intype);
	break;
    default:
	usage(2);
	break;
    }
    dct  = DoctypeFromFile(sf);

    if(!silent)
	outf = OpenStream(stdout, dct, outtype, enc, "<stdout>");
    while( ( nslbit = GetNextBit(sf) )){
	  if(!silent)
	  {
	      if(nslbit->type == NSL_doctype_bit)
	      {
		  if(!(outtype & NSL_write_no_doctype))
		      PrintBit(outf,nslbit);
	      }
	      else if (nslbit->type==NSL_bad) {
		  PrintText(outf,(Char *) "!\n!!bad bit!!!\n");
		  return -1;
	      } else {
		  PrintBit(outf,nslbit);
	      }
	  }
	  FreeBit(nslbit);
    }

    if(!silent)
	SFclose(outf);
    SFrelease(sf, 1);

    NSLClose();

    return 0;
}

