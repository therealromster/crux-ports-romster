#ifndef _sggrep_h
#define _sggrep_h
/* sggrep.h */
#ifdef __cplusplus
extern "C"{
#endif
#ifdef macintosh
#pragma export on
#endif



typedef enum SgMatchSense { sgNegativeMatch = 0,sgPositiveMatch = 1} SgMatchSense;
typedef enum SgReMatchType {sgMatchString = 0, sgMatchRe = 1} SgReMatchType;

typedef struct SearchRequestRec * SearchRequest;
 


/* Public interface to SearchRequests */

SearchRequest EXPRT NewSearchRequest (void);

SearchRequest EXPRT SearchRequestFromArgcArgv (int argc,char * argv[]);

void EXPRT FreeRequest (SearchRequest theRequest);

void EXPRT SetNewlineSep (SearchRequest theRequest,
			  int newlinesWanted);

void EXPRT SetMatchSense (SearchRequest theRequest, 
			  SgMatchSense matchType);

void EXPRT SetAttrValAreRe (SearchRequest theRequest, 
			    SgReMatchType matchIsRe);

void EXPRT SetTopLevelString (SearchRequest theRequest,
			      const char * topLevelString);

void EXPRT SetQueryString (SearchRequest theRequest,
			   const char * queryString);

void EXPRT SetSubQueryString (SearchRequest theRequest,
			      const char * subQueryString);

void EXPRT SetRegexpString (SearchRequest theRequest,
			    const char *regexpString);

void EXPRT SetMarkerQueryString (SearchRequest theRequest,
				 const char *markerQueryString);

void EXPRT SetMarkerTagString (SearchRequest theRequest,
			       const char *markerTagString);

void EXPRT SetDdbFileString (SearchRequest theRequest,
			     const char * ddbFileString);

void EXPRT SetOutputFileString (SearchRequest theRequest, 
				const char * outputFileString);

void EXPRT SetInputFileString (SearchRequest theRequest, 
			       const char * inputFileString);
void EXPRT SetSecondaryInputFiles (SearchRequest theRequest,
				   int numInputFiles,
				   const char ** inputFileStrings); 
 
 
 /* 
  Internally, sggrep uses a Search to maintain context during its search. This isn't part of the
  public interface.
  */
 
typedef struct SearchRec * Search;



/* Public interface to Searches */
Search EXPRT  SGGOpen (SearchRequest theRequest);
void EXPRT SGGSearch (Search theSearch);
void EXPRT SGGClose (Search theSearch);

#ifdef macintosh
#pragma export off
#endif
#ifdef __cplusplus
}
#endif

#undef P



#endif /* _sggrep_h */

