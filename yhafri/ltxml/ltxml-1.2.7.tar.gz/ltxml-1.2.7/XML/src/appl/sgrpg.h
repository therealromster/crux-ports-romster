/* sgrpg.h	-- Henry Thompson
 *
 */

#ifndef _SGRPG_H

#include "nsllib.h"
/* On compilation NSLROOT should be (the value of) ${exec_prefix}/lib/ltnsl */
#define SGRPG_DDB_FILE NSLROOT "/sgrpg.ddb"

typedef struct topqd {
  NSL_Query q;
  NSL_Query vq;
  const regexp *vt;
  int polarity;			/* 1 for no, 0 for yes */
  int context;			/* 1 for preserve, 0 for discard */
  const struct expo *subs;
} topqd;

typedef enum {indep, ser, seq, par} slink;

typedef struct subqd {
  NSL_Query q;
  slink link;
  const regexp *t;
  int polarity;			/* 1 for no, 0 for yes */
  int context;			/* 1 for preserve, 0 for discard */
  const struct expo *subs;
} subqd;

typedef enum {text,elt,stag,etag} otype;

typedef struct outd {
  otype type;
  const Char *fmt;
  int cnt;
  const Char **argv;
} outd;

struct ord;
typedef struct ord {
  const struct expo *first;
  const struct ord *rest;
} ord;

typedef struct rgrp {
  /* groups */
  const struct expo *first;
  const struct rgrp *rest;
} rgrp;

typedef enum {subq, or, out, group} rtype;
typedef enum {one,opt,plus,star} ktype;

typedef struct expo {
  /* container for everything, holds exponent */
  rtype type;
  ktype kt;
  union {
    const subqd *sub;
    const outd *out;
    const ord *ords;
    const rgrp *group;
  } descr;
} expo;

extern const Char giptr[],dataptr[];
void usage(int exitval);
extern NSL_Doctype sgdct;
extern NSL_Doctype dct;
extern int attr_val_are_re,preserveEver,eltEver,nq,neg;
extern topqd ** ReadPatFile(NSL_File,NSL_Doctype,int,int,char **);
extern const Char *IdExpansion(const NSL_Doctype, const Char *);

const Char *MyAV(const NSL_Item *item, const Char *aname);

#define _SGRPG_H

#endif
