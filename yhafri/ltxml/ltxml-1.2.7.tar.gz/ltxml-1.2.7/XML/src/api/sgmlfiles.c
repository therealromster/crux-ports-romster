/* 	$Id: sgmlfiles.c,v 1.162 2003/09/01 17:46:11 ht Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sgmlfiles.c,v 1.162 2003/09/01 17:46:11 ht Exp $";
#endif /* lint */

/* sgmlfiles.c	-- Henry Thompson Tue Jan 30 1996
 * Basic file processing for XML/NSL
 */

/* This version using Richard's XML aware parser */

#include <assert.h>

#include "lt-memory.h"
#include "nsllib.h"
#include "string16.h"
#include "stdio16.h"
#include "lt-safe.h"
#include "lt-umalloc.h"
#include "dtd.h"
#include "input.h"
#include "url.h"
#include "xmlparser.h"
#include "readddb.h"

static boolean doctype_init_alloc(NSL_Doctype_I *doctype,
				 int nitems, int ndata, int nattr);

/* XXX to be removed asap */
         
boolean ParseAttributeString( NSL_Doctype_I *doctype, NSL_Item *item,
			      struct attribute *source, int do_ns);

size_t BufCopyMax=BUFCOPYMAX,BufMargin=BUFMARGIN;

static NSL_File_I *open_output(FILE16 *fp, NSL_Doctype dtype, NSL_FType type,
			       CharacterEncoding encoding);
static NSL_File_I *open_source(InputSource source, NSL_Doctype dtype,
			       NSL_FType type);

static int CheckFlags(int type);

/*--- File handling ---*/

static int CheckFlags(int type)
{
    if(((type & NSL_read) && (type & NSL_write_flags)) ||
       ((type & NSL_write) && (type & NSL_read_flags)) ||
       (type & (NSL_read | NSL_write)) == 0)
    {
	LT_ERROR(NEIO,
		    "Bad flag combination when opening file or stream\n");
	return -1;
    }
    return 0;
}

NSL_File OpenURL(const char8 *url, NSL_Doctype dtype, NSL_FType type,
		 CharacterEncoding encoding, const char8 *base)
{
    char8 *m_url;
    Entity entity;
    InputSource source;
    FILE16 *f16;
    NSL_File_I *file;

    ECEN(CheckFlags(type));

    if(type & NSL_read)
    {
	ECNN(entity = NewExternalEntity(0, 0, url, 0, 0));
	entity->encoding = encoding;
	ECNN(source = EntityOpen(entity));
	return open_source(source, dtype, type);
    }
    else
    {
	ECNN(f16 = url_open(url, base, "w", &m_url));
	SetCloseUnderlying(f16, 1);
	file = open_output(f16, dtype, type, encoding);
	return file;
    }
}

NSL_File OpenStream(FILE *fp, NSL_Doctype dtype, NSL_FType type, 
		    CharacterEncoding encoding, const char8 *name)
{
    InputSource source;
    FILE16 *f16;

    ECEN(CheckFlags(type));

    if(type & NSL_read)
    {
	source = SourceFromStream(name, fp);
	source->entity->encoding = encoding;
	return open_source(source, dtype, type);
    }
    else
    {
	ECNN(f16 = MakeFILE16FromFILE(fp, "w"));
	return open_output(f16, dtype, type, encoding);
    }
}

static void SetMode(NSL_File_I *file, int xml)
{
    Parser p = file->pstate;

    ParserSetFlag(p, XMLSyntax, xml);
    ParserSetFlag(p, XMLPredefinedEntities, xml);
    ParserSetFlag(p, XMLExternalIDs, xml);
    ParserSetFlag(p, XMLMiscWFErrors, xml);
    ParserSetFlag(p, ErrorOnUnquotedAttributeValues, xml);
    ParserSetFlag(p, NormaliseAttributeValues, xml);
    ParserSetFlag(p, XMLLessThan, xml);
    ParserSetFlag(p, IgnoreEntities, !xml);
    ParserSetFlag(p, ExpandCharacterEntities, xml);
    ParserSetFlag(p, ExpandGeneralEntities, xml);
    /* The parser must not check end tags in nSGML mode, because it
       doesn't have real ElementDefinition records. */
    ParserSetFlag(p, MaintainElementStack, xml);
    /* We set these to stop the parser trying to auto-declare undeclared
       elements and attributes in nSGML mode, which wouldn't work. */
    ParserSetFlag(p, ErrorOnUndefinedElements, !xml);
    ParserSetFlag(p, ErrorOnUndefinedAttributes, !xml);
}

/* Open a string for input or output. */

NSL_File OpenString(Char *text, NSL_Doctype dtype, NSL_FType type)
{
    NSL_File_I *file;
    static Char string[] = {'<','s','t','r','i','n','g','>',0};

    ECEN(CheckFlags(type));

    if(type & NSL_read)
    {
	Entity entity;
	InputSource source;

	entity = NewInternalEntity(string, text, 0, 0, 0, 0);
	ECNN(source = EntityOpen(entity));
	/* Don't read prolog yet, we want to set flag first */
	file = open_source(source, dtype, type|NSL_read_no_consume_prolog);
	/* So we don't get warnings about xml declaration in internal entity */
	ParserSetFlag(file->pstate, IgnorePlacementErrors, 1);
	/* Now we can read the prolog */
	if(!(type & NSL_read_no_consume_prolog))
	    ReadProlog(file);
    }
    else
    {
	FILE16 *f16;

	ECNN(f16 = MakeFILE16FromString(text, -1, "w"));
	file = open_output(f16, dtype, type, CE_unknown);
    }
	
    return file;
}

/* Open a string for input and read a single Item from it.
 */

NSL_Item *GetItemFromString(const Char *text, NSL_Doctype dtype)
{
    NSL_File file;
    NSL_Item *item;

    ECNN(file = OpenString((Char *)text, dtype, NSL_read));
    item = GetNextItem(file);
    SFclose(file);
    return item;
}

/* Manipulate the base URL of the root entity of a file */

const char8 *GetFileURL(NSL_File file)
{
    return EntityBaseURL(ParserRootEntity(file->pstate));
}

void SetFileURL(NSL_File file, const char8 *url)
{
    EntitySetBaseURL(ParserRootEntity(file->pstate), url);
}


/* Backward compatibility functions.
 * These are superseded by OpenURL and OpenStream.
 */

NSL_File_I *SFopen(const char8 *urlname, NSL_Doctype_I *dtype,
		   NSL_FType type)
{
    return OpenURL(urlname, dtype, type, CE_unknown, 0);
}

NSL_File_I *SFFopen( FILE *fp, NSL_Doctype_I *dtype,
		     NSL_FType type, const char8 *fname)
{
    return OpenStream(fp, dtype, type, CE_unknown, fname);
}

void NSL_Parser_declaration(XBit bit, void *callback_arg);

static const char* sddNames[]={"unspecified","no","yes"};



/* utility to ensure all fields of sf filled in sensibly */
/* and seen to be filled in sensibly */

static NSL_File_I * NewNullFile () {
	NSL_File_I *sf;
	
  ECNN(sf=tsalloc(NSL_File_I, 1));
  sf->file16 = NULL;
  sf->fileToClose = NULL;
  sf->doctype = NULL;
  sf->type = NSL_write;
  sf->cnum = 0;
  sf->pstate = NULL;
  sf->currentbase = NULL;
  sf->_bit1.type=NSL_bad;
  sf->_bit1.nsc=0;
  sf->_bit1.nsowned = 0;
  sf->peekBit=0;
  sf->currentItemCharPosn = -1;
  sf->currentBitOffset = -1;
   
  /* rest only valid for output files */
  sf->state=_elt_unknown;
	
	return sf;
	}

#define NELEMENTS 1024
#define ELEMENTNAMES 16384
#define NATTRS 1024
#define ATTRNAMES 16384

RHTEntry* xrinsert(NSL_Doctype_I *doctype,
		   const Char* name,int len,RHashTableHdr* tbl,RHVal val) {
  if (!len) {
    len=Strlen(name);
  };
  if ((len+tbl->freekey)>tbl->length) {
    LT_ERROR(NEMEM,"hash table keychars overflow\n");
    return NULL;
  };
				/* Should make this less left-handed */
  if (tbl==doctype->attrNames) {
    if (doctype->attrNameCount++==(NATTRS/2)) {
      WARN(NEMEM,"attr hash table half full!\n");
    }
    else if (doctype->attrNameCount>NATTRS) {
      LT_ERROR(NEMEM,"attr hash table entry overflow\n");
      return NULL;
    };
  }
  else if (tbl==doctype->elements) {
    if (doctype->elementCount++==(NELEMENTS/2)) {
      WARN(NEMEM,"element hash table half full!\n");
    }
    else if (doctype->elementCount>NELEMENTS) {
      LT_ERROR(NEMEM,"element hash table entry overflow\n");
      return NULL;
    };
  }
  else {
    SHOULDNT;
  };
  return rinsert(name,len,tbl,val);
}

static int eltSpace=64*(sizeof(NSL_ElementSummary_I)+
			 (4*sizeof(AttributeSummary))+16);

char *NewEltTable(NSL_Doctype_I *doctype,const char *oldTbl) {
				/* called when XML overflows doc/attr
				   summary table */
  ECNN(doctype->elementPtr=doctype->elementBase=(char*)salloc(eltSpace));
  /* ground forwarding pointer */
#if 0
  /* XXX check this change is right */
  *((const char**)doctype->elementPtr)++=oldTbl;
#else
  *((const char**)doctype->elementPtr) = oldTbl;
  doctype->elementPtr += sizeof(const char **);
#endif
  doctype->elementLimit=doctype->elementBase+eltSpace;
  return (char*)doctype->elementPtr;
}

/* Open an entity for reading */

static NSL_File_I *open_source(InputSource source, NSL_Doctype dtype, NSL_FType type)
{
    NSL_File_I *sf = NewNullFile();
    static NSL_ElementSummary_I rootElt = {0,dc_element,0,0};
    MarkupLanguage ml;

    sf->type = type;
    sf->doctype = dtype;

    sf->pstate = NewParser();
    ParserSetFlag(sf->pstate, ReturnDefaultedAttributes, 0);
    ParserSetFlag(sf->pstate, MergePCData, 1);
    ParserSetFlag(sf->pstate, ReturnComments, 0);
    ParserSetFlag(sf->pstate, TrustSDD, 0); /* we want to decide ourselves */
    ParserSetFlag(sf->pstate, AllowMultipleElements, 1);

    if(type & NSL_read_strict)
	/* Need this *before* we do the push, which may parse the XML decl.
	   But must postpone setting other flags, so they aren't undone
	   by SetMode later. */
	ParserSetFlag(sf->pstate, XMLStrictWFErrors, 1);

    if(ParserPush(sf->pstate, source) != 0)
    {
	ParserPerror(sf->pstate, &sf->pstate->xbit);
	LT_ERROR(NEPARSE, "Error opening source\n");
	return 0;
    }

    /* Choose xml mode unless there's an NSL declaration, or we were
       passed an NSL doctype. */

    ml = source->entity->ml_decl;

    switch(ml)
    {
    case ML_xml:
	SetMode(sf, 1);
	if(dtype && !dtype->XMLMode)
	    WARN(NWMLMIXUP,
		 "You are trying to read an XML document with an nSGML\n"
		 "doctype.  Expect a bus error.\n"
    "LTG makes no representations about the suitability of this software\n"
    "and data for any purpose.  It is provided \"as is\" without express or\n"
    "implied warranty.  LTG disclaims all warranties with regard to this\n"
    "software and data, including all implied warranties of merchantability\n"
    "and fitness, in no event shall LTG be liable for any special, indirect\n"
    "or consequential damages or any damages whatsoever, action of\n"
    "contract, negligence or other tortious action, arising out of or in\n"
    "connection with the use or performance of this software.\n");
	break;
    case ML_nsl:
	SetMode(sf, 0);
	if(dtype && dtype->XMLMode)
	    WARN(NWMLMIXUP,
		 "You are trying to read an nSGML document with an XML\n"
		 "doctype.  Who knows what will happen?  Good luck.\n")
	break;
    case ML_unspecified:
	SetMode(sf, !dtype || dtype->XMLMode);
	break;
    }

    if(type & NSL_read_no_expand) {
	ParserSetFlag(sf->pstate, ExpandCharacterEntities, 0);
	ParserSetFlag(sf->pstate, ExpandGeneralEntities, 0);
	ParserSetFlag(sf->pstate, MergePCData, 0);
    };

    if(type & NSL_read_no_normalise_attributes) {
	ParserSetFlag(sf->pstate, NormaliseAttributeValues, 0);
    }

    if(type & NSL_read_all_bits) {
	ParserSetFlag(sf->pstate, ReturnComments, 1);
	ParserSetFlag(sf->pstate, MergePCData, 0);
    }

    {
	int w = (type & NSL_read_declaration_warnings);
	ParserSetFlag(sf->pstate, WarnOnRedefinitions, w);
    }

    if(type & NSL_read_relaxed_any) {
	ParserSetFlag(sf->pstate, RelaxedAny, 1);
    }

    if(type & NSL_read_allow_undeclared_nsattributes) {
	ParserSetFlag(sf->pstate, AllowUndeclaredNSAttributes, 1);
    }

    if(type & NSL_read_strict)
    {
#if 0
	/* Doesn't work, fix it on output instead */
	/* Actually, it does work now for XML, but we won't change it */
	ParserSetFlag(sf->pstate, ReturnDefaultedAttributes, 1);	
#endif
	ParserSetFlag(sf->pstate, AllowMultipleElements, 0);
	ParserSetFlag(sf->pstate, ErrorOnBadCharacterEntities, 1);	
	ParserSetFlag(sf->pstate, ErrorOnUndefinedEntities, 1);
	ParserSetFlag(sf->pstate, XMLStrictWFErrors, 1);
    }

    if(type & NSL_read_validate)
    {
	if((dtype && !dtype->XMLMode) || ml == ML_nsl)
	    ;
	else
	{
	    /* Must set this so that RXP keeps an element stack */
	    ParserSetFlag(sf->pstate, MaintainElementStack, 1);
	    ParserSetFlag(sf->pstate, Validate, 1);
	}
    }

    if(type & NSL_read_namespaces)
    {
	if(ml == ML_nsl || (dtype && !dtype->XMLMode))
	    /* namespace don't make sense for nSGML */
	    type &= ~NSL_read_namespaces;
	else
	    ParserSetFlag(sf->pstate, XMLNamespaces, 1);
    }

    if(type & NSL_read_defaulted_attributes)
    {
	if(ml == ML_nsl || (dtype && !dtype->XMLMode))
	    /* won't work for nSGML */
	    type &= ~NSL_read_defaulted_attributes;
	else
	    ParserSetFlag(sf->pstate, ReturnDefaultedAttributes, 1);
    }

    ECNF(sf->eltContent.base =
	 sf->eltContent.current = NEWSTACK(StackSize));
    sf->eltContent.end=sf->eltContent.base+StackSize;
    PUSH(sf->eltContent,&rootElt); /* fencepost, true if off the top */

    ParserSetDtdCallback(sf->pstate, NSL_Parser_declaration);
    ParserSetDtdCallbackArg(sf->pstate, sf);
   
    if(dtype)
    {
	FreeDtd(sf->pstate->dtd);
	sf->pstate->dtd = dtype->rxp_dtd;
	sf->pstate->have_dtd = 1;
    }
    else
    {
	if(ml == ML_nsl)
	{
	    SetMode(sf, 0);
	    ECNN(sf->doctype = dtype = 
		 DoctypeFromDdb(source->entity->ddb_filename));
	    /* DoctypeFromDdb allocates an RXP dtd but we already have one */
	    FreeDtd(dtype->rxp_dtd);
	    sf->pstate->have_dtd = 1;
	}
	else
	{
	    /* Create a fake doctype for an XML document */
	    /* This is common code from DoctypeFromDdb */
	    ECNN(sf->doctype=dtype=tsalloc(NSL_Doctype_I,1));
	    dtype->doctype=NULL;
	    dtype->XMLMode = TRUE;
	    dtype->ddb=NULL;
	    dtype->ddbfile=NULL;
	    dtype->seenDTD = FALSE;
	    dtype->sdd = (sddCode)sf->pstate->standalone;
	    ECFN(doctype_init_alloc(dtype, 100, 100, 100));

	    ECNN(dtype->attrNames=rcreate(NATTRS,ATTRNAMES));/*(4096,65536));*/
	    ECNN(dtype->elements=rcreate(NELEMENTS,ELEMENTNAMES)); /*1024,16384));*/
	    dtype->attrNameCount=dtype->elementCount=0;
	    ECNN(NewEltTable(dtype,0));
	    dtype->permanentBase=dtype->elementBase;
	    ECNN(dtype->offAttrsBase=salloc(sizeof(OffboardAttrs)*128));
	    dtype->offAttrsIndex=0;
	    dtype->offAttrsLimit=128;
	    dtype->entities=NULL; /* handled separately */
	    dtype->entityBase=NULL;
	}
	dtype->rxp_dtd = sf->pstate->dtd;
	dtype->root_entity = source->entity;
	dtype->doctypeStatement=NULL;
	dtype->defaultOutputEncoding = source->entity->encoding;
	dtype->fallbackEncodingDeclaration = source->entity->encoding_decl;
    }

    sf->pstate->dtd->doctype = dtype;

    sf->currentbase=NewNullNSLData(dtype);

    if(!(type & NSL_read_no_consume_prolog))
	ReadProlog(sf);

    return sf;
}

int ReadProlog(NSL_File_I *sf)
{
    while(1)
    {
	NSL_Bit *bit = NextBit(sf);
	switch(bit->type)
	{
	case NSL_start_bit:
	case NSL_empty_bit:
	case NSL_eof_bit:
	case NSL_bad:
	    /* We've reached the end of the prolog */
	    /* XXX just leave an error to be read later - is that right? */
	    sf->peekBit = bit;
	    return 0;

	default:
	    FreeBit(bit);
	    break;
	}
    }
}

static boolean SynthesizePIBit(NSL_File_I * sf) {
    const NSL_Doctype_I * dtype = sf->doctype;
    Char *buffer;

    ECNF(buffer = salloc(1024 * sizeof(Char)));
    sf->_bit1.type = NSL_pi_bit;
    sf->_bit1.value.body = buffer;

    if( dtype->XMLMode ){
	char sdds[24];
	char ecs[50];
	if (dtype->sdd!=sdd_unspecified) {
	    sprintf(sdds," standalone='%s'",sddNames[dtype->sdd]);
	}
	else {
	    sdds[0]=0;
	};
	if (GetFileEncoding(sf->file16)!=CE_unspecified_ascii_superset) {
	    sprintf(ecs," encoding='%s'",
		    CharacterEncodingName[GetFileEncoding(sf->file16)]);
	}
	else {
	    if(dtype->fallbackEncodingDeclaration != CE_unknown)
		sprintf(ecs," encoding='%s'", 
			CharacterEncodingName[dtype->fallbackEncodingDeclaration]);
	    else
		ecs[0]=0;
	};
	Sprintf(buffer, InternalCharacterEncoding,
		"xml version='1.0'%s%s",
		ecs,
		sdds);
    } else {
	Sprintf(buffer, InternalCharacterEncoding,
		"NSL DDB %s 0", dtype->ddbfile);
    }

    return TRUE;
}

#include "nsl-ibit.h"

static void SynthesizeDoctypeBit(NSL_File_I * sf) {
    NSL_Doctype_I * dtype = sf->doctype;
    /* record the data in the bit */
    sf->_bit1.type = NSL_doctype_bit;
    sf->_bit1.value.body = (void *)dtype->doctypeStatement;
}

    
/* Set up a file for writing, but don't actually write anything
   yet. 
 */

static NSL_File_I *open_output(FILE16 *f16, NSL_Doctype dtype, NSL_FType type,
			       CharacterEncoding encoding)
{
    NSL_File_I *sf = NewNullFile();
    static NSL_ElementSummary_I rootElt = {0,dc_mixed,0,0};
  
    sf->type = type;
    sf->file16 = f16;
    sf->doctype = dtype;
    if(encoding)
	SetFileEncoding(sf->file16, encoding);
    else if(dtype)
	SetFileEncoding(sf->file16, dtype->defaultOutputEncoding);

    encoding = GetFileEncoding(sf->file16);
    if(encoding == CE_UTF_16B || encoding == CE_UTF_16L)
	/* Byte-order mark */
	Fprintf(sf->file16, "%c", 0xfeff);

    /* Set up element-only content stack if we're going to pretty-print */

    if((type & NSL_write_style) == NSL_write_canonical ||
       (type & NSL_write_style) == NSL_write_plain)
    {
	sf->eltContent.base=0;
    }
    else
    {
	if(dtype)
	{
	    ECNN(sf->eltContent.base = 
		 sf->eltContent.current=NEWSTACK(StackSize));
	   /* N.B. now have two pointers to same storage in sf->elementContent,
	      let's hope we eventually free exactly one of them 
	      */
	    sf->eltContent.end=sf->eltContent.base+StackSize;
	    PUSH(sf->eltContent,&rootElt);	/* fencepost */
	}
	else
	{
	    WARN(NWOFND,
		 "NSL Output file needs doctype for normal or pretty output\n"
	       "but none supplied or defaulted:  minimal output will ensue\n");
	    sf->type &= ~NSL_write_style;
	    sf->type |= NSL_write_plain;
	    sf->eltContent.base=0;
	}
    }

    /* Print PI and doctype, if we want it */

    if(!(type & NSL_write_no_doctype) && dtype)
    {
	static Char newline[] = {'\n',0};
	/* The call to SynthesizePIBit is made in order
	 * that all output pass through PrintBit.
	 */
	ECFN(SynthesizePIBit(sf));
	/* XXX -- use a global to ensure that PrintBit
	 * doesn't output the DOCTYPE statement. Ugly
	 * temporary patch
	 */
	PrintBit(sf,&(sf->_bit1));
	FreeBit(&sf->_bit1);
	PrintTextLiteral(sf, newline);
	    
	/* ... in the same way we synthesise and print
	 * a doctype bit if there is one...
	 */
	if(dtype->doctypeStatement) {
	    SynthesizeDoctypeBit(sf);
	    PrintBit(sf,&(sf->_bit1));
	}
    }

    return sf;
}    

/* XML DTD call backs */

void NSL_Parser_declaration(XBit bit, void *callback_arg){
#if 0
    NSL_File_I *sf = (NSL_File_I*)callback_arg;
#endif
    switch(bit->type) {
    case XBIT_comment:
	COMMENT1("CB:XBIT_comment %s\n", bit->comment_chars);
	FreeXBit(bit);
	break;

    case XBIT_pi:
      COMMENT1("CB:XBIT_pi %s", bit->pi_name);
      COMMENT1(" %s\n",bit->pi_chars);
      FreeXBit(bit);
      break;

    default:
      SHOULDNT;
      break;
    }
}

/* This should not be called directly now.  Use DefineElement[N]. */
RHTEntry *DeclareElement(NSL_Doctype_I *doctype, const Char *name,
			 int length, const char *data, ctVals modelType) {
  RHTEntry *res;
  NSL_ElementSummary_I *value=(NSL_ElementSummary_I *)doctype->elementPtr;
  if ((char*)(value+1)>doctype->elementLimit) {
    ECNN(value=(NSL_ElementSummary_I *)NewEltTable(doctype,
						   doctype->elementBase));
  };
  res=xrinsert(doctype,name, length, (RHashTableHdr*)doctype->elements,
	      ((char*)value)-doctype->permanentBase);
  COMMENT1("Inserting element %s into doctype\n",name);
  value->numAttr=value->omitStart=value->omitEnd=0;
  value->contentType=modelType;
    
  doctype->elementPtr=(char*)(value+1);
  return res;
}

/* This should not be called directly now.  Use DefineAttribute[N]. */
const Char *DeclareAttr(NSL_Doctype_I *doctype, const Char *name,
			int length,
			NSL_Attr_Declared_Value declared_value,
			const Char *allowed_values, int allowed_values_count,
			NSL_ADefType default_type, const Char *default_value,
			NSL_ElementSummary_I **eltptr,
			const Char *eltName) {
  /* Only called in XML mode */
  RHTEntry *attr;
  AttributeSummary *value;
  ASPtr *asp;
  OffboardAttrs *oa;
  NSL_ElementSummary_I *oPtr,*elt=*eltptr;
  if (!eltName) {
    SHOULDNT;
  };
  if (!(attr=rsearch(name,length,doctype->attrNames))) {
    attr=xrinsert(doctype,name,length,(RHashTableHdr*)doctype->attrNames,1);
  }
  value=(AttributeSummary *)doctype->elementPtr;
  if ((char*)(value+1)>doctype->elementLimit) {
    value=(AttributeSummary *)NewEltTable(doctype,doctype->elementBase);
  };
  oPtr=(NSL_ElementSummary_I *)doctype->elementPtr;
  doctype->elementPtr=(char*)(value+1);
    /* what value? */
  value->namePtr=((Char*)doctype->attrNames+attr->keyptr)-(Char*)value;
  value->defaultPtr=default_value?default_value-(Char*)value:0;
  value->allowedValuesPtr=allowed_values?allowed_values-(Char*)value:0;
  value->numAV=allowed_values_count;
  value->declaredValue=(char)declared_value;
  value->defaultValueType=(char)default_type;
  if (elt->numAttr<0) {
    /* Some summaries are already offboard, add to them */
    oa=(OffboardAttrs*)doctype->offAttrsBase+(-1-elt->numAttr);
    asp=(ASPtr *)doctype->elementPtr;
    if ((char*)(asp+1)>doctype->elementLimit) {
      asp=(ASPtr *)NewEltTable(doctype,doctype->elementBase);
    };
    doctype->elementPtr=(char*)(asp+1);
    asp->next=oa->asp;
    asp->as=value;
    oa->asp=asp;
  }
  else if ((char*)elt!=(char*)((AttributeSummary*)
			  (oPtr-1)-
			  elt->numAttr)) {
    /* Not contiguous with pre-existing ASs for this elt, if any,
       either because of intervening allocation or change in table */
    /* Shift to offboard attr sums */
    if (doctype->offAttrsIndex==doctype->offAttrsLimit) {
      /* No more room: reallocate and move offboard table */
      int newLimit=doctype->offAttrsLimit=doctype->offAttrsLimit+128;
      ECNN(doctype->offAttrsBase=(const OffboardAttrs *)srealloc(
                                          (void *)doctype->offAttrsBase,
					  sizeof(OffboardAttrs)*newLimit));
    };
    oa=(OffboardAttrs *)doctype->offAttrsBase+(doctype->offAttrsIndex++);
    asp=(ASPtr *)doctype->elementPtr;
    if ((char*)(asp+1)>doctype->elementLimit) {
      asp=(ASPtr *)NewEltTable(doctype,doctype->elementBase);
    };
    doctype->elementPtr=(char*)(asp+1);
    asp->next=0;
    asp->as=value;
    oa->asp=asp;
    oa->oldNumAttr=elt->numAttr;
    elt->numAttr=-doctype->offAttrsIndex; /* Note this is, correctly,
					   -1-(the index of the new entry) */
  }
  else {
    elt->numAttr+=1;
  };
  return (const Char*)doctype->attrNames+attr->keyptr;
}

#if 0
void CheckinElement(NSL_Doctype_I *doctype, Char *element_name,
		    const char *element_data, ctVals modelType) {
  size_t len;

  if (!rsearch(element_name, (len=Strlen(element_name)), doctype->elements)) {
    DeclareElement(doctype,element_name,len,element_data,modelType);
  }
  return;
}
#endif

extern NSL_Item *NNI(const NSL_ElementSummary_I *elt,
		     const NSL_Doctype_I *doctype,
		     const Char *name);

#if 0
int CheckInEntity(NSL_Doctype_I *doctype, const char *entity_name, int length){
  RHTEntry* entry;
  RHVal value = 0;

  if( !length ){ length = strlen(entity_name); };
  entry=rsearch(entity_name, length, doctype->entities);
  if (entry) {
    COMMENT1("Entity %s already in doctype\n",entity_name);
  } else {
    xrinsert(doctype,
	     entity_name, length, (RHashTableHdr*)doctype->entities,value);
    COMMENT1("Inserting entity %s into doctype\n",entity_name);
  }
  return 0;
}
#endif

/* ================================================= */

/* XXX this function is broken, given the XML parser. */

boolean SFFreopen( NSL_File_I *file, FILE *filep ) {
#if 1
    LT_ERROR(NEUNSUP,
		"The function SFFreopen has been removed from the library\n");
    return FALSE;
#else
  ECEF(sfclose(file->filep));
  file->filep=(FILE *)filep;
  return TRUE;
#endif
}

int SFclose( NSL_File_I *f) {

  if (f->type & NSL_read) {
    Entity docent = 0;
    FreeBit(f->peekBit);
    FreeData(f->currentbase, f->doctype);
    /* Free the document entity only if it's not needed by the dtd.
       This will be true only when we got the doctype from another file.
       Don't free it until after FreeParser, because FreeParser looks
       at the entities. */
    if(f->pstate->document_entity != f->doctype->root_entity)
	docent = f->pstate->document_entity;
    FreeParser(f->pstate);
    if(docent) {
	/* Don't free strings passed in to OpenString */
	docent->text = 0; 
	FreeEntity(docent);
    }
  } else {
      if((f->type & NSL_write_style) == NSL_write_default ||
	 (f->type & NSL_write_style) == NSL_write_fancy) {
	  ForceNewline(f);
      }
      ECEE(ForceOutput(f)); /* will do FlushRe */
      ECEE(Fclose(f->file16));
      if(f->fileToClose)
	  ECEE(stdfclose(f->fileToClose)); /* Only close what we opened */
  }
  /* We don't free the doctype, because some other file may use it.
     Tough tittie, but you have to call FreeDoctype yourself. */
  if (f->eltContent.base) {
    ECFE(sfree(f->eltContent.base));
  }
  ECFE(sfree(f));
  return 0;
}

/* An unsafe (see documentation) version of SFclose which cleans up
   all heap storage associated with the file.
   The DOCTYPE is released iff releaseDoctype is TRUE */

int SFrelease( NSL_File_I *f, boolean releaseDoctype) {  
  NSL_Doctype_I *dct = f->doctype;

  ECEE(SFclose(f));

  if( releaseDoctype ){
    FreeDoctype(dct);
  }

  return 0;
}

#if 0
void SetFileDoctype( NSL_File_I *f, NSL_Doctype_I *d ) {
    f->doctype=d;
}
#endif

/* Given a NSL_File_I *return the NSL_Doctype_I *associated with it */

NSL_Doctype_I *DoctypeFromFile( NSL_File_I *file) {
  return (NSL_Doctype_I *)file->doctype;
}

/* Opens three standard files streams as NSGML streams */

NSL_File_I *sgstdin, *sgstdout, *sgstderr;

boolean StdFiles(NSL_FType type) {
  ECNF(sgstdin=SFFopen(stdin, NULL, NSL_read, "stdin"));
  ECNF(sgstdout=SFFopen(stdout, DoctypeFromFile(sgstdin), type, "stdout"));
  ECNF(sgstderr=SFFopen(stderr, NULL, NSL_write_plain|NSL_write_no_doctype,
			"stderr"));
  return TRUE;
}

#if 0
void MakeFilesSameDoctype( NSL_File_I *ffrom, NSL_File_I *fto ) {
    fto->doctype=ffrom->doctype;
}
#endif

/* Return the byte offset in the file of the current read position */
/* XXX only works for root entity; need a better interface */
/* Why does this return size_t???  Should be long (like ftell) or
  off_t (like lseek). */

size_t SFtell(NSL_File_I *sf) {
    return SourceTell(ParserRootSource(sf->pstate));
}

/* Move read position in file to pos bytes in */
/* XXX only works for root entity; need a better interface */

int SFseek(NSL_File_I *sf,size_t pos) {
    Parser p = sf->pstate;

    if (sf->peekBit) {
	FreeBit(sf->peekBit);
	sf->peekBit=0;
    }

    while(p->source->parent)
	ParserPop(p);

    p->state = PS_body;		/* What else could we do? */
    ParserSetFlag(p, IgnorePlacementErrors, 1);

    return SourceSeek(p->source, pos);
}

/* Called by NSL_Init          */

boolean ParseInit( void ) {
  init_parser();
  return TRUE;
}

/* Read and return the next NSL_Bit in the input file */

NSL_Bit *NextBit(NSL_File_I *sf) {

  XBit bit;
  NSL_Bit *nslbit;
  NSL_BI_Type lastType;
  int n;
  NSL_Doctype_I *doctype;
  boolean XMLMode;
  char8 *sysid=0;
  Char  *dtdchars=0, *intsubset=0;
  Char *data;
  static Char empty_string[] = {0};

  if (sf->peekBit) {
    NSL_Bit *tmp=sf->peekBit;
    sf->peekBit=0;
    return tmp;
  }

  doctype=(NSL_Doctype_I *)sf->doctype;
  nslbit = &(sf->_bit1);
  bit = ReadXBit(sf->pstate);

  sf->currentBitOffset = bit->byte_offset;

  XMLMode=doctype?doctype->XMLMode:FALSE;
  lastType=nslbit->type;

  nslbit->nsc = 0;
  nslbit->nsowned = 0;

  switch(bit->type) {
  case XBIT_error:
    ParserPerror(sf->pstate, bit);
    LT_ERROR(NEPARSE, "");
    nslbit->type = NSL_bad;
    FreeXBit(bit);
    break;
  case XBIT_start:
  case XBIT_empty:
    if( bit->type == XBIT_empty ){
      nslbit->type = NSL_empty_bit;
    } else {
      nslbit->type = NSL_start_bit;
    }

    nslbit->value.item=NNI(bit->element_definition->eltsum,
			   doctype,
			   bit->element_definition->name);
    nslbit->value.item->prefix=bit->element_definition->prefix;

    nslbit->label=nslbit->value.item->label;
    nslbit->prefix=nslbit->value.item->prefix;
	
    ParseAttributeString(doctype,nslbit->value.item, bit->attributes,
			 sf->type & NSL_read_namespaces);
    
    if(sf->type & NSL_read_namespaces)
    {
	if(bit->ns_element_definition)
	{
	    nslbit->llabel = nslbit->value.item->llabel =
		bit->ns_element_definition->name;
	    nslbit->nsuri = nslbit->value.item->nsuri =
		bit->ns_element_definition->namespace->nsname;
	}
	else
	{
	    nslbit->llabel= nslbit->label;
	    nslbit->nsuri = 0;
	}

	nslbit->value.item->ns_dict = nslbit->ns_dict = bit->ns_dict;
	nslbit->value.item->nsc = nslbit->nsc = bit->nsc;

	/* Take ownership of the ns records */
	if(bit->type == XBIT_empty)
	{
	    nslbit->value.item->nsowned = 1;
	    bit->nsowned = 0;
	}
    }

    if (XMLMode) {
	if (bit->type==XBIT_empty) {
	    nslbit->value.item->type=NSL_empty;
	}
    } else {
	if (nslbit->value.item->defn->contentType==dc_empty) {
	    nslbit->type=NSL_empty_bit;
	    nslbit->value.item->type=NSL_empty;
	} else if ( nslbit->value.item->type == NSL_empty ){
	    /* item type may have been set to NSL_empty if we */
	    /* came across an explicit CONREF attribute value */
	    nslbit->type = NSL_empty_bit;
	}
    }

    if( nslbit->type == NSL_start_bit ){
	PUSH(sf->eltContent,
	     bit->element_definition->eltsum);
    }
    else if(sf->eltContent.current - 1 == sf->eltContent.base)
	/* See comment below under XBIT_end */
	sf->pstate->state = PS_epilog;

    break;
  case XBIT_pi:
    /* A processing instruction */
    COMMENT1("%s", xbit_type_name[bit->type]);
    COMMENT1(" %s",bit->pi_name);
    COMMENT1(" %s\n", bit->pi_chars);
    nslbit->type=NSL_pi_bit;
    { Char *new;
    ECNN(new=salloc((Strlen(bit->pi_name)+1+Strlen(bit->pi_chars)+1)*sizeof(Char)));
    if (bit->pi_chars[0]) {
      Sprintf(new,InternalCharacterEncoding,"%S %S",bit->pi_name,bit->pi_chars);
    }
    else {
      Sprintf(new,InternalCharacterEncoding,"%S",bit->pi_name);
    };
    nslbit->value.body = new;
    }
#if 0
    /* NSL PIs are now handled in the low-level parser */
    if (HandlePi(bit,sf) < 0) {
      nslbit->type=NSL_bad;
    }
#endif
    /* Since we copied them, we should free the originals */
    FreeXBit(bit);
    break;
  case XBIT_pcdata:
    COMMENT1("%s", xbit_type_name[bit->type]);
    COMMENT1(" [%s]\n", bit->pcdata_chars);
    if (!(sf->type & NSL_read_all_bits) &&
	(TOP(sf->eltContent))->contentType==dc_element) {
      /* this assumes any PCData in the wrong place is white . . . */
      /* and that eltOnly is true outside the document element */
      FreeXBit(bit);
      return NextBit(sf);
    }
    data=bit->pcdata_chars;
    if(data[0] == '&' && (sf->type & NSL_read_no_expand))
	nslbit->flags = NSL_text_isERef;
    else
	nslbit->flags = 0;
    if (!XMLMode) {
      int incr=0;
      Char *realdata=data;

      if ( data[0] == '\n' ) {
	switch (lastType) {
	case NSL_start_bit:
	case NSL_pi_bit:
	  /* one RE is ignored after start tag or pi */
	  if (*(++(data))=='\0') {
	    /* skip the whole thing */
	    sfree(realdata);
	    return NextBit(sf);
	  } else {
	    incr=1;
	  }
	  break;
	default:
	  break;
	}
      }

      n=Strlen(data);
      if (n--==0) {
	sfree(realdata);
	return NextBit(sf);
      }
      /* check last char if before end tag */
      /* what about PIs? */
      if (PeekXBit(sf->pstate)->type==XBIT_end) {
	if (n==0 && data[0]=='\n') {
	  /* empty, try again */
	  sfree(realdata);
	  return NextBit(sf);
	} else if (data[n]=='\n') {
	  data[n]='\000';
	}
      }
      if (incr) {
	/* o bother, hope this is rare because it's STUPID */
	data=Strdup(data);
	sfree(realdata);
      }
    } 

    nslbit->type = NSL_text_bit;
    nslbit->value.body = (Char*)data;
    break;

  case XBIT_end:
    nslbit->type = NSL_end_bit;
    COMMENT1("%s", xbit_type_name[bit->type]);
    COMMENT1(" %s\n", bit->element_definition->name);
    if ((NSL_ElementSummary_I *)TOP(sf->eltContent)!=
	bit->element_definition->eltsum) {
      char buf[100];
      bit->type=XBIT_error;
      Sprintf(buf,CE_ISO_8859_1,"unmatched end tag %.70S",
	      bit->element_definition->name);
      bit->error_message=buf;
      ParserPerror(sf->pstate, bit);
      LT_ERROR(NEPARSE,"")
    };
    POPNV(sf->eltContent);
    nslbit->label = bit->element_definition->name;
    nslbit->prefix = bit->element_definition->prefix;
    nslbit->value.item = NULL;
    if(sf->eltContent.current - 1 == sf->eltContent.base)
	/* Have to do this here, because the low-level parser doesn't keep
	   an element stack when used with NSL.  The stack is empty when
	   there is only one element on it (sigh). */
	sf->pstate->state = PS_epilog;

    if(sf->type & NSL_read_namespaces)
    {
	if(bit->ns_element_definition)
	{
	    nslbit->llabel = bit->ns_element_definition->name;
	    nslbit->nsuri = bit->ns_element_definition->namespace->nsname;
	}
	else
	{
	    nslbit->llabel= nslbit->label;
	    nslbit->nsuri = 0;
	}

	/* Take ownership of the ns records */
	nslbit->ns_dict = bit->ns_dict;
	nslbit->nsc = bit->nsc;
	nslbit->nsowned = 1;
	bit->nsowned = 0;
    }

    FreeXBit(bit);
    break;

  case XBIT_eof:
    nslbit->type = NSL_eof_bit;
    COMMENT1("%s\n", xbit_type_name[bit->type]);
    break;

  case XBIT_comment:
    COMMENT1("%s", xbit_type_name[bit->type]);
    COMMENT1(" %s\n", bit->comment_chars);
    nslbit->type = NSL_comment_bit;
    nslbit->value.body = bit->comment_chars;
    break;

  case XBIT_dtd:
    if (XMLMode && !doctype->seenDTD) {
      COMMENT1("%s", xbit_type_name[bit->type]);
      doctype->seenDTD = TRUE;
      {
	struct xbit oldbit = *bit;
	if (sf->pstate->dtd->internal_part) {
	    bit = ParseDtd(sf->pstate, sf->pstate->dtd->internal_part);
	    if (bit->type==XBIT_error) {
		ParserPerror(sf->pstate, bit);
		LT_ERROR(NEPARSE, "");
		nslbit->type = NSL_bad;
		FreeXBit(&oldbit);
		FreeXBit(bit);
		break;
	    }
	}
	if ((doctype->sdd!=sdd_yes || sf->type & NSL_read_validate) &&
	    sf->pstate->dtd->external_part) {
	    bit = ParseDtd(sf->pstate, sf->pstate->dtd->external_part);
	    if (bit->type == XBIT_error) {
		ParserPerror(sf->pstate, bit);
		LT_ERROR(NEPARSE, "");
		nslbit->type = NSL_bad;
		FreeXBit(&oldbit);
		FreeXBit(bit);
		break;
	    }
	    FreeXBit(bit);
	}
	*bit = oldbit;
      }
    } else {
      COMMENT1("%s", xbit_type_name[bit->type]);
    }
    if (sf->pstate->dtd->external_part &&
	sf->pstate->dtd->external_part->systemid) {
	sysid=salloc(strlen(sf->pstate->dtd->external_part->systemid)+4);
	sprintf(sysid,"\"%s\" ",sf->pstate->dtd->external_part->systemid);
    }
    if (sf->pstate->dtd->internal_part) {
      intsubset=salloc((Strlen(sf->pstate->dtd->internal_part->text)+3)*
		       sizeof(Char));
      Sprintf(intsubset, InternalCharacterEncoding,
	      "[%S]",sf->pstate->dtd->internal_part->text);
    }
    if (sf->pstate->dtd->external_part && 
	sf->pstate->dtd->external_part->publicid) {
      dtdchars=salloc((Strlen(sf->pstate->dtd->name)+
		      9+
		      strlen8(sf->pstate->dtd->external_part->publicid)+
		      2+
		      (sysid?strlen8(sysid):0)+
		      (intsubset?Strlen(intsubset):0)+
		      1) * sizeof(Char));
      Sprintf(dtdchars, InternalCharacterEncoding, "%S PUBLIC \"%s\" %s%S",
	      sf->pstate->dtd->name,
	      sf->pstate->dtd->external_part->publicid,
	      sysid?sysid:(char8 *)"",
	      intsubset?intsubset:empty_string);
    } else {
      dtdchars=salloc((Strlen(sf->pstate->dtd->name)+
		      1+
		      (sysid?7:0)+
		      (sysid?strlen8(sysid):0)+
		      (intsubset?Strlen(intsubset):0)+
		      1) * sizeof(Char));
      Sprintf(dtdchars, InternalCharacterEncoding, "%S %s%s%S",
	      sf->pstate->dtd->name,
	      sysid?"SYSTEM ":"",
	      sysid?sysid:(char8 *)"",
	      intsubset?intsubset:empty_string);
    }
    sfree(sysid);
    sfree(intsubset);
    FreeXBit(bit);

    doctype->doctypeStatement = dtdchars;

    nslbit->type = NSL_doctype_bit;
    nslbit->value.body = Strdup(dtdchars);
    break;

  case XBIT_cdsect:
    COMMENT1("%s\n", xbit_type_name[bit->type]);
    nslbit->type=NSL_text_bit;
    nslbit->value.body=bit->cdsect_chars;
    if(sf->type & NSL_read_all_bits)
	nslbit->flags = NSL_text_isCData;
    else
	nslbit->flags = 0;
    break;

  default:
    SHOULDNT;
  }
  return nslbit;
}

/* NB, this should be tied much more closely in with Richard's code,
   since his attribute and our NSL_Attr are VERY similar */

static const AttributeSummary ConstAtSum={0,0,0,0,0,0};

static boolean PAS1(NSL_Doctype_I *dct, NSL_Item *item,
		    struct attribute *source, int do_ns, NSL_Attr **prev) {
  NSL_Attr *refvar, *res;
  const AttributeSummary *atsum;

  /* If no attributes then we are finished */
  if (!source) {
    item->attr=NULL;
    return TRUE;
  }

  /* Recurse down list of attributes - in effect we are starting at
     the end and working backwards (So that order of attributes is
     reversed twice, and hence in the same order as in the source
     file) */
  if (source->next) {
    ECFF(PAS1(dct, item, source->next, do_ns, &res));
  }

  /* Now we process this attribut/value pair */

  if(dct->XMLMode)
      atsum = source->definition->attrsum;
  else
      /* In NSL mode the attribute summary itself is returned */
      atsum = (AttributeSummary *)source->definition;

  ECNF(refvar=AttrFromSpec(atsum, dct));

  /* We have an explicit #CONREF attribute, this means that
     The item is of type NSL_empty, despite what the DTD says */
  if( refvar->deft == NSL_defval_conref ){
    item->type = NSL_empty;
  }

  ECFF(SetAttrValue(refvar, source->value));

  if(do_ns)
  {
      if(source->ns_definition && !source->ns_definition->element)
      {
	  refvar->lname = source->ns_definition->name;
	  refvar->nsuri = source->ns_definition->namespace->nsname;
      }
      else
      {
	  refvar->lname = source->definition->name;
	  refvar->nsuri = 0;
      }
  }

  if( !(source->next) ){
    item->attr=refvar;
  } else {
    res->next=refvar;
  }
  if (prev) {
    *prev=refvar;
  }

  sfree(source);
  return TRUE;
}

int ParseAttributeString(NSL_Doctype_I *dct, NSL_Item *item,
			 struct attribute *source, int do_ns) {
  return PAS1(dct, item, source, do_ns, 0);
}

boolean DocumentIsNSGML(NSL_Doctype_I *dct)
{
    return !dct->XMLMode;
}

/* ======================================================================== */
/* Moved from sgmldef.c */

NSL_Doctype_I *DoctypeFromDdb(const char8 *filename) {
  
  NSL_Doctype_I *doctype;
  DDBHeader* ddb;
  ECNN(ddb=readddb(filename));

  checkddb(filename,ddb,FALSE);    

  ECNN(doctype=tsalloc(NSL_Doctype_I, 1));

  doctype->doctype=(char*)(ddb+1);
  COMMENT1("[!DOCTYPE %s ",doctype->doctype);
  COMMENT1("from DDB %s]\n",filename);

  doctype->ddb=ddb;
  doctype->ddbfile=filename;

  doctype->attrNames=(RHashTableHdr*)(((char*)ddb)+ddb->anameTableOffset);
  doctype->elements=(RHashTableHdr*)(((char*)ddb)+ddb->elementTableOffset);
  doctype->elementBase=((char*)doctype->elements)+doctype->elements->length;
  doctype->permanentBase=doctype->elementBase;
  doctype->entities=(RHashTableHdr*)(((char*)ddb)+ddb->entityTableOffset);
  doctype->entityBase=((char*)doctype->entities)+doctype->entities->length;
  doctype->doctypeStatement = NULL;
  doctype->XMLMode=FALSE;
  doctype->seenDTD = TRUE;

  ECFN(doctype_init_alloc(doctype, 100, 100, 100));

  doctype->defaultOutputEncoding = CE_UTF_8; /* XXX is this a good default? */
  doctype->fallbackEncodingDeclaration = CE_unknown;
  doctype->rxp_dtd = NewDtd();
  doctype->root_entity = 0;

  return doctype;
}

static boolean doctype_init_alloc(NSL_Doctype_I *doctype,
				  int nitems, int ndata, int nattr)
{
  if ((doctype->itemstack=Uinit(sizeof(NSL_Item), nitems, 30))!=NULL &&
      (doctype->datastack=Uinit(sizeof(NSL_Data), ndata, 30))!=NULL &&
      (doctype->attrstack=Uinit(sizeof(NSL_Attr), nattr, 30))!=NULL) {
    NameUmalloc(doctype->itemstack, "NSL_Item");
    NameUmalloc(doctype->datastack, "NSL_Data");
    NameUmalloc(doctype->attrstack, "NSL_Attr");
    return TRUE;
  } else {
    return FALSE;
  }
}

NSL_Doctype_I *LoadDoctype(const char8 *filename)
{
    int len;
    NSL_File_I *sf;
    NSL_Doctype_I *dct;

    /* If it's a .ddb file, use DoctypeFromDdb */

    len = strlen(filename);
    if(len > 4 && strcmp(filename+len-4, ".ddb") == 0)
	return DoctypeFromDdb(filename);

    /* Otherwise, open as an nSGML/XML file, and get its doctype */

    /* Open in no_consume_prolog mode, so we don't attempt to read the first
      element (we want it to work for files just containing <!DOCTYPE ... >) */

    ECNN(sf = SFopen(filename, 0, NSL_read|NSL_read_no_consume_prolog));

    /* If it's a nSGML file, we should now have read the doctype */

    dct = sf->doctype;
    if(!dct->XMLMode)
    {
	SFclose(sf);
	return dct;
    }

    /* Otherwise we must read until we get the doctype bit */

    while(1)
    {
	NSL_Bit *bit = NextBit(sf);
	switch(bit->type)
	{
	case NSL_bad:
	    SFrelease(sf, 1);
	    return 0;

	case NSL_start_bit:
	case NSL_empty_bit:
	case NSL_eof_bit:	    
	    /* We've reached the end of the prolog without seeing <!DOCTYPE>.
	       Just return the empty doctype. */
	case NSL_doctype_bit:
	    /* We found it. */
	    FreeBit(bit);
	    SFclose(sf);
	    return dct;

	default:
	    /* Ignore other bits (PIs, comments). */
	    FreeBit(bit);
	    break;
	}
    }
}

/* ======================================================================== */
/* Moved from sgmldef.c */

const char8 *MakeSpec(const NSL_Doctype_I *doctype) {
  char *spstr;

  ECNN(spstr=salloc(200));
  sprintf(spstr, "<?NSL DDB %s 0>\n",doctype->ddbfile);
  return spstr;
}

/* ======================================================================== */

extern int CurrentBitOffset( NSL_File_I *sf ){
  if (sf->currentBitOffset<0) {
    LT_ERROR(NEOFFST,"No bit offset yet\n");
  };
  return sf->currentBitOffset;
}

/* end of file */

