#include "nsllib.h"
#include "string16.h"
#include "dtd.h"

/* 
 * This set of routines allows the positioning and selection of 
 * elements from an SGML information structure.  It makes use of the
 * routine UnifyItem(), which unifies two SGML items.
 *
 * The aim is to allow SGML structures to be used as C structures.
 *
 */

/* Functions defined in this file */

const void *GetAttrDefaultValue(const AttributeSummary *atsum);
NSL_Item *UnifyItem(NSL_Item *baseitem, const NSL_Doctype_I *bdoctype,
		    NSL_Item *uitem, const Char *spath);
NSL_Data *NextDFSElement ( const NSL_Data *dptr, boolean noText );

NSL_Data *FirstChild( const NSL_Item *item, boolean noText );

NSL_Item *FollowItem( const NSL_Item *item);

NSL_Item *ObtainItem(const NSL_Data *data, const Char *itemname, size_t len) {
    if (data==NULL || itemname==NULL)
	return NULL;
    for (;data!=NULL;data=data->next)
	if (data->type==NSL_item_data)
	    /* Fix from phancox@dtc.com.au */
	    if (Strlen(((NSL_Item *)(data->first))->label) == len &&
		Strncmp(((NSL_Item *)(data->first))->label,itemname,len)==0) /* a hit ! */
		return (NSL_Item *)data->first;
    return NULL; /* not present */
}

NSL_Item *UnifyItem(NSL_Item *baseitem, const NSL_Doctype_I *bdoctype,
		    NSL_Item *uitem, const Char *spath) {
  Char ch;
  const Char *ptr, *rest;
  int len;
  NSL_Item *nextitem;
  NSL_Data *datap=0, *dptr;
  boolean lastpath;

  for (ptr=spath; *ptr!='/' && *ptr!=0; ptr++) 
    ; /* Find first component of the path */
  ch=*ptr;
  len=ptr-spath;

  lastpath=(ch==0)?1:0;

  if (lastpath) {  /* Unify on components */
    if (baseitem!=NULL && uitem==NULL) {
      return baseitem;
    };

    if (baseitem==NULL && uitem!=NULL) {
      ECNN(baseitem=CopyItem(uitem));
      ECNN(spath=ElementUniqueNameI(bdoctype,spath,len));
      baseitem->label=spath;

      return baseitem;
    };

    if (baseitem==NULL && uitem==NULL) {
      ECNN(baseitem=NewNullNSLItem(bdoctype,spath,len));
      return baseitem;
    };
    /*
     * Here we have that neither baseitem nor uitem are NULL,
     * so we might get a conflict.
     */
    if (baseitem->data!=NULL) { /* the basic structure is not an empty entry */
      if (uitem->data!=NULL) {
	/* and the something is not empty, add it to the end of data */
	for (dptr=baseitem->data; dptr!=NULL; dptr=dptr->next)
	  datap=dptr;

	ECNN(datap->next=CopyData(uitem->data, baseitem));

	return baseitem;
      }
      else {
	/* but the something is empty */
	return baseitem;
      };
    }
    else {
      /* baseitem has no content */
      if (uitem->data!=NULL) {
	/* but the unificand does */
	ECFN(FreeItem(baseitem));
	ECNN(baseitem=CopyItem(uitem));
	ECNN(spath=ElementUniqueNameI(bdoctype,spath,len));
	baseitem->label=spath;

	return baseitem;
      }
      else {
	/* both are empty, so don't do anything */
	return baseitem;
      };
    };
  };

  if (baseitem==NULL) {
    ECNN(baseitem=NewNullNSLItem(bdoctype,spath,len));
  }
  else {
    if (Strncmp(spath, baseitem->label,len)!=0) {
      /* name of baseitem isn't name */
      REPORT("Unification failure --- incompatable names\n");

      return NULL;
    };
  };

  rest=ptr+1; /* the rest of the path */

  for (ptr=rest; *ptr!='/' && *ptr!=0; ptr++) 
    ; /* Find second component of the path */
  ch=*ptr;
  len=ptr-rest;

  /* Fix from phancox@dtc.com.au, was ECNN(...) */
  nextitem=ObtainItem(baseitem->data, rest,len);

  if (nextitem==NULL) {
    ECNN(datap=NewNullNSLData(bdoctype));
    datap->type=NSL_item_data;
    if (baseitem->data==NULL) {
      baseitem->data=datap; /* make a data list */
      baseitem->type=NSL_non_empty;
    }
    else {
      /* Put new data at end of list */
      for (dptr=baseitem->data; dptr->next!=NULL; dptr=dptr->next)
	;
      baseitem->type=NSL_non_empty;
      dptr->next=datap;
    }

    if (uitem && rest) {
      /* guessing here -- ht 26/2/96 */
      ECNN(datap->first=UnifyItem(NULL, bdoctype, uitem, rest));
    };

    return baseitem;
  }
  else {

    if ((nextitem || uitem) && rest) {
      ECNN(UnifyItem(nextitem, bdoctype, uitem, rest));
    };

    return baseitem;
  }
}

NSL_Item *AddPCdata(NSL_Item *uitem, NSL_Doctype_I *doctype,
		    const Char *pcdata, const Char *path) {
  NSL_Data *data, *dptr=NULL;
  NSL_Item *item, *ritem;
  const Char *optr=0;
  int flag=FALSE;
  const NSL_Query_I *q, *q2;

  if (path==NULL)
    return NULL;

  ECNN(q=ParseQuery( doctype, path ));
    

  if ((item=RetrieveQueryItem(uitem, q, NULL))) {
      flag=TRUE;
    }
  else {
      for (q2=q; q2->next; q2=q2->next)
	/* EMPTY */;
      optr=q2->elname;
      ECNN(item=NewNullNSLItem(doctype,optr,0)); /* make item with name
						    of last * component
						    in the path */
    }

  ECFN(FreeQuery(q));
  for (data=item->data; data; dptr=data, data=data->next)
    /*EMPTY*/;
  ECNN(data=NewNullNSLData(doctype));

  if (dptr)
    dptr->next=data;
  else
    item->data=data;

  data->type=NSL_text_data;
  item->type=NSL_non_empty;
  ECNN(data->first=Strdup(pcdata));
  data->in=item;
  data->next=NULL;

  if (!flag) {
      ECNN(ritem=UnifyItem(uitem, doctype, item, path));
      ECFN(FreeItem(item));
    }
  else
    ritem=uitem;

  return ritem;
}


NSL_Item *FollowItem( const NSL_Item *item) {
  NSL_Data *dptr;
  if (item->in)
    if ((dptr=item->in->next)) {
      for (;dptr;dptr=dptr->next) {
	if (dptr->type==NSL_item_data) {
	  return (NSL_Item *)dptr->first;
	};
      };
    };
  return NULL;
}

NSL_Item *ParentItem( const NSL_Item *item) {
  if (item->in)
    return item->in->in;
  return NULL;
}

/* Returns the first data child of item (first non pcdata one if noText is true)

 */

NSL_Data *FirstChild( const NSL_Item *item, boolean noText ) {
  NSL_Data *dptr;
  if( !item ){
    LT_ERROR(NEARGNL,"item=NULL in FirstChild\n");
    return NULL;
  }
  if (item->data) {
    for (dptr=item->data; dptr; dptr=dptr->next) {
      if ((!noText) || dptr->type==NSL_item_data) {
	return dptr;
      }
    }
  }
  return NULL;
}

/*
Returns next data in a top-down left-to-right traversal of the tree
*/

NSL_Data *NextDFSElement ( const NSL_Data *dptr, boolean noText ) {
  NSL_Data *rval;

  if (dptr->type==NSL_item_data && 
      (rval=FirstChild((NSL_Item*)dptr->first,noText))) {
      return rval;
  }
  do {
    for (rval=dptr->next;rval;rval=rval->next) {
      if ((!noText) || rval->type==NSL_item_data) {
	return rval;
      }
    }
  } while (dptr->in && (dptr=dptr->in->in)); /* == NextDFSNoChildren */

  return NULL;
}

/* Returns next data in a top-down left-to-right traversal of the tree
// But ignoring children of dptr
*/

NSL_Data *NextDFSNoChildren( const NSL_Data *dptr, boolean noText ) {
  const NSL_Data *rval;
  do {
    for (rval=dptr->next;rval;rval=rval->next) {
      if ((!noText) || rval->type==NSL_item_data) {
	return (NSL_Data*)rval;
      }
    }
  } while (dptr->in && (dptr=dptr->in->in));
  return NULL;
}

boolean RetrieveQueryData(NSL_Item *uitem, NSL_Query query,
			    const NSL_Data **fromRet, boolean noText) {
  const NSL_Data *lnext,*ldata,*dptr,*from;
  const NSL_Item *link;
  const NSL_Query_I *rq;
  boolean relinked = FALSE;

  from=*fromRet;
  if (uitem==NULL || query==NULL) {
    return FALSE;
  }

  if( !uitem->in ){
    /* uitem has no data as its parent
       so create one - we dont delete this one here
       so may be a memory leak */
    uitem->in = NewNullNSLData(uitem->doctype);
    uitem->in->first = uitem;
    uitem->in->type  = NSL_item_data;
  } else if( !uitem->in->first ) {
    /* In this case the item's data does not point back to the item
       This may be the case with items returned by GetNextQueryItem
       So relink it, and remember to unlink it at the end */
    relinked = TRUE;
    uitem->in->first = uitem;
  }

  link=uitem->in->in;
  ldata=uitem->in;
  lnext=uitem->in->next;
  uitem->in->in=NULL;
  uitem->in->next=NULL;/* Stop the search from going above <uitem> */

  if (from!=NULL) {
    if ((from=NextDFSElement( from, noText ))==NULL) {
      uitem->in->in=(NSL_Item*)link;
      uitem->in->next=(NSL_Data*)lnext;
      if( relinked ) uitem->in->first = NULL;
      return FALSE;
    }
  } else {
    from=ldata;
  }

  for (dptr=from; dptr; ) {
    if ( (rq=InitSegQueryUp( query, dptr )) ) {
      if ((!rq->next) || ExecQueryUp( rq, dptr )) {
	break;
      } else {
	dptr=NextDFSElement(dptr,noText);
      }
    } else {
      dptr=NextDFSNoChildren( dptr,noText ); /* cut */
    }
  }

  uitem->in->in=(NSL_Item*)link; /* restore the link */
  uitem->in->next=(NSL_Data*)lnext;
  if( relinked ) uitem->in->first = NULL;
  *fromRet=dptr;
  return dptr?TRUE:FALSE;
}


NSL_Item *RetrieveQueryItem(NSL_Item *uitem, NSL_Query query,
			    const NSL_Item *from) {
  NSL_Data holder={0,NSL_item_data,NULL,NULL,NULL};
  const NSL_Data *in=NULL;

  if (uitem==NULL || query==NULL) {
    return NULL;
  };

  if (from) {
    if (from->in) {
      in=from->in;
    } else {
      holder.first=(NSL_Item*)from;
      in=&holder;
    };
  };
  if (RetrieveQueryData(uitem,query,&in,TRUE)) {
    if( in->first ){
      return (NSL_Item*)in->first;
    } else {
      /* I assert that this will only happen if the matching item
	 == uitem and we had to relink in RetrieveQueryData.
	 If so, then the answer is uitem */
      return uitem;
    }
  };
  return NULL;
}

/* ================================================== */
/*    Attributes                                      */
/* ================================================== */

const void *GetAttrValue(const NSL_Attr *refvar) {
    return refvar->value.string;
}

/* DMCK: Modified GetAttrDefVal to return */
/* NSL_Implied_Attribute_Value (a constant empty string) if */
/* The attribute has no default value             */

static Char imp = 0;
const Char *NSL_Implied_Attribute_Value = &imp;

const Char *GetAttrDefVal(const AttributeSummary *atsum) {
  if( atsum->defaultPtr ){
    return ((const Char*)atsum)+atsum->defaultPtr;
  } else {
    return (Char*)NSL_Implied_Attribute_Value;
  }
}

const void *GetAttrDefaultValue(const AttributeSummary *atsum) {
  return (void*)GetAttrDefVal(atsum);
}

const Char *GetAttrStringVal( const NSL_Item *item, const Char *name ) {
  const NSL_Attr *attr;
  const AttributeSummary *atsum;

  attr=FindAttr(item->attr, name);
  if (attr==NULL) {
    atsum=FindAttrSpec(item->defn,
		       item->doctype, name); /* default attributes */
    if (atsum==NULL) {
#if 0
	/* Remove this error because we want to be able to test whether
	   an element has an attribute without checking whether it is
           allowed by the DTD first, and in the case of XML when there
	   is no dtd. */
      LT_ERROR2(NEUNDEF,"** GetAttrVal: Trying to reference unknown attribute %s\n               in item type: %s\n",
	     name,item->label);
#endif
      return NULL;
    }
    else {
      return GetAttrDefVal(atsum);
    };
  }
  else {
    return attr->value.string;
  };
}

/* 
 * Get the specified value of an attribute.  If no value is specified,
 * NULL is returned
 */
const Char *GetAttrSVal(const NSL_Item *item, const Char *name) {
  NSL_Attr *attr;
  ECNN(attr=FindAttr(item->attr, name)); /* specified attributes */

  return GetAttrValue(attr);
}

/* Given an item - return the value of its ID - you do not need to know */
/* what the name of the ID attribute is for this to work                */
/* Returns NULL if the item has no ID attribute                         */
Char *GetIdVal( const NSL_Item *item ){
  const NSL_Attr *attr;
  for( attr = item->attr; attr; attr = attr->next ){
    if( attr->valuetype == NSL_attr_id ){
      return (Char*)(attr->value.string);
    }
  };
  return NULL;
}

/* This function takes an element summary and searches the doctype */
/* for an attribute with the given name                            */
/* The "AndNumber" version also returns its position in the        */
/* element's list of attributes, for indexing RXP's attr table     */

const AttributeSummary* FindAttrSpec(const NSL_ElementSummary_I *elts,
				     const NSL_Doctype_I *doctype,
				     const Char *name) {
    return FindAttrSpecAndNumber(elts, doctype, name, 0);
}

const AttributeSummary* FindAttrSpecAndNumber(const NSL_ElementSummary_I *elts,
				     const NSL_Doctype_I *doctype,
				     const Char *name,
				     int *attrnum) {
  int count;
  AttributeSummary *attrBase=(AttributeSummary*)(elts+1),*ptr;
  const OffboardAttrs *oa=0;
  ASPtr *asp;
  int numAttr;
  if (elts->numAttr<0) {
    /* if numAttr is <0, it's an inverted index offset by -1 and there
       are offboard att sums */
    oa=doctype->offAttrsBase+(-1-elts->numAttr);
    numAttr=oa->oldNumAttr;
  }
  else {
    numAttr=elts->numAttr;
  };
  if( NSL_Global_Names == NSL_use_strings ){
    for (ptr=attrBase+numAttr-1;ptr>=attrBase;ptr--) {
      if ( Strcasecmp(((Char*)ptr)+ptr->namePtr,name) == 0 ) {
	if(attrnum)
	  *attrnum = ptr - attrBase;
	return ptr;
      }
    };
    if (elts->numAttr<0) {
      /* only if XMLmode */
      count = -1;
      for (asp=oa->asp;asp;asp=asp->next) {
	ptr=(AttributeSummary *)(asp->as);
	if ( Strcasecmp(((Char*)ptr)+ptr->namePtr,name) == 0 ) {
	  if(attrnum)
	    *attrnum = count;
	  return ptr;
	};
	count--;
      };
    };
  } else {
    /* requires unique name */
    for (ptr=attrBase+numAttr-1;ptr>=attrBase;ptr--) {
      if (((Char*)ptr)+ptr->namePtr==name) {
	if(attrnum)
	  *attrnum = ptr - attrBase;
	return ptr;
      }
    };
    if (elts->numAttr<0) {
      /* only if XMLmode */
      count = -1;
      for (asp=oa->asp;asp;asp=asp->next) {
	ptr=(AttributeSummary *)(asp->as);
	if (((Char*)ptr)+ptr->namePtr==name) {
	  if(attrnum)
	    *attrnum = count;
	  return ptr;
	};
      count--;
      };
    };
  }
  return NULL;
}

const AttributeSummary *FindAttrSumAndName(NSL_Doctype_I *doctype,
					   NSL_ElementSummary_I **eltptr,
					   const Char *eltname,
					   const Char **name, int length) {
  RHTEntry* entry;
  size_t len;
  NSL_ElementSummary_I *elt=*eltptr;
  if( !doctype ){
    LT_ERROR1(NEARGNL,"FindAttrSumAndName(%s) called with a NULL doctype\n",
	      name);
    return NULL;
  };
  if (doctype->XMLMode) {
    const AttributeSummary *atsum;
    if ((entry=rsearch(*name, (len=(length?length:Strlen(*name))),
		       doctype->attrNames))) {
	*name=(Char*)doctype->attrNames+entry->keyptr;
    }
    /* note we may have name but no spec yet */
    if (entry && (atsum=FindAttrSpec(elt,doctype,*name))) {
      return atsum;
    }
    else {
      AttributeDefinition atdef;
      ElementDefinition eltdef;
      eltdef = doctype->rxp_dtd->elements[*(short *)&(elt->omitEnd)];
      ECNN(atdef = DefineAttributeN(eltdef, *name, len,
				    AT_cdata, 0, DT_implied, 0, 0));
      *name = atdef->name;
    }
  } else {
    if ((entry=rsearch(*name, (len=(length?length:Strlen(*name))),
		       doctype->attrNames))) {
      *name=(Char*)doctype->attrNames+entry->keyptr;
    } else {
      return NULL;
    }
  }

  return FindAttrSpec(elt,doctype,*name);
}

const Char *AttrUniqueName8(NSL_Doctype_I *doctype,
			   const char8 *name, int length ) {
#if CHAR_SIZE == 8
    return AttrUniqueName(doctype, name, length);
#else
    Char *n1;
    const Char *n2;
    int i;

    if(!length)
	length = strlen8(name);
    ECNN(n1 = salloc(length * sizeof(Char)));
    /* Don't use translate_latin1_utf16 as name may not be null-terminated */
    for(i=0; i<length; i++)
	n1[i] = name[i];
    n2 = AttrUniqueName(doctype, n1, length);
    sfree(n1);
    return n2;
#endif
}

const Char *AttrUniqueName(NSL_Doctype_I *doctype,
			   const Char *name, int length ) {
  RHTEntry* entry;
  size_t len;
  if( !doctype ){
    /* If no doctype, then return the name we were given */
    /* Give a warning if we are not running with NSL_use_strings */
    if( NSL_Global_Names != NSL_use_strings ) {
      LT_ERROR1(NEARGNL,"AttrUniqueName(%s) called with a NULL doctype\n",
		name);
      return NULL;
    }
    return name;
  }
  entry=rsearch(name,(len=(length?length:Strlen(name))), doctype->attrNames);
  if (!entry) {
    if (doctype->XMLMode) {
      entry=xrinsert(doctype,name,len,(RHashTableHdr*)doctype->attrNames,1);
    } else {
      return NULL;
    }
  }
  return (Char*)doctype->attrNames+entry->keyptr;
}

boolean AttrExists(const NSL_Doctype_I *doctype, const Char *name,
		   int length, const NSL_ElementSummary_I *elts) {
  RHTEntry *entry;
  if ((entry=rsearch(name, length?length:Strlen(name), doctype->attrNames))) {
    if ((!elts) || FindAttrSpec(elts,doctype,
				(Char*)doctype->attrNames+entry->keyptr)) {
      return TRUE;
    };
  };
  return FALSE;
}

/* ================================================= */
/* SGML Elements                                     */
/* ================================================= */

NSL_ElementSummary_I *FindElementAndName(NSL_Doctype_I *doctype,
					       const Char **name, int length) {
  const NSL_ElementSummary_I *res;
  size_t len=length?length:Strlen(*name);
  RHTEntry* entry=rsearch(*name, len, doctype->elements);

  if (!entry) {
    if (doctype->XMLMode) {
	ElementDefinition e;
	ECNN(e = TentativelyDefineElementN(doctype->rxp_dtd, *name, len));
	*name = e->name;
	return e->eltsum;
    }
    else {
	return NULL;
    };
  }

  res=(const NSL_ElementSummary_I*)(doctype->permanentBase+entry->eval);
  *name=(Char*)doctype->elements+entry->keyptr;
  return (NSL_ElementSummary_I *)res;
}

NSL_ElementSummary_I *FindElementByName(const NSL_Doctype_I *doctype,
					      const Char *name) {
  RHTEntry* entry=rsearch(name, Strlen(name), doctype->elements);
  if (entry) {
    const NSL_ElementSummary_I *res=(const NSL_ElementSummary_I*)
      (doctype->permanentBase+entry->eval);
    return (NSL_ElementSummary_I *)res;
  } else {
    return NULL;
  }
}

const Char *ElementUniqueName8(NSL_Doctype_I *doctype, const char *name,
			      int length) {
#if CHAR_SIZE == 8
    return ElementUniqueName(doctype, name, length);
#else
    Char *n1;
    const Char *n2;
    int i;

    if(!length)
	length = strlen8(name);
    ECNN(n1 = salloc(length * sizeof(Char)));
    /* Don't use translate_latin1_utf16 as name may not be null-terminated */
    for(i=0; i<length; i++)
	n1[i] = name[i];
    n2 = ElementUniqueName(doctype, n1, length);
    sfree(n1);
    return n2;
#endif
}

const Char *ElementUniqueName(NSL_Doctype_I *doctype, const Char *name,
			      int length) {
  size_t len=length?length:Strlen(name);
  RHTEntry* entry=rsearch(name, len, doctype->elements);

  if (!entry) {
    if (doctype->XMLMode) {
	ElementDefinition e;
	ECNN(e = TentativelyDefineElementN(doctype->rxp_dtd, name, len));
	return e->name;
    } else {
      return NULL;
    }
  }

  return (Char *)doctype->elements+entry->keyptr;
}

const Char *ElementUniqueNameI(const NSL_Doctype_I *doctype, const Char *name,
			       int length) {
  RHTEntry* entry;
  entry=rsearch(name, length?length:Strlen(name), doctype->elements);
  if (entry) {
    return (Char *)doctype->elements+entry->keyptr;
  } else {
    return NULL;
  }
}

boolean ElementExists(const NSL_Doctype_I *doctype, const Char *name,
		       int length) {
  if (rsearch(name, length?length:Strlen(name), doctype->elements)) {
    return TRUE;
  } else {
    return FALSE;
  }
}

/* Given an item, return the first child of it which is text data */
/* Next three functions added for Andrei: indexing support        */

Char *GetPCDataBelow(NSL_Item *item) {
  NSL_Data *data;

  data=item->data;
  for (;data; data=data->next) {
    if (data->type==NSL_text_data) {
      return (Char *)data->first;
    };
  };
  return NULL;
}

NSL_Data *LinkItem(const NSL_Doctype_I *doctype, NSL_Data *dptr, NSL_Item *item )
{
    NSL_Data *dp;

    dp=NewNullNSLData(doctype);
    dp->type=NSL_item_data;
    dp->in=dptr->in;
    dp->first=item;
    item->in=dp;
    dptr->next=dp;
    dp->ref=dptr->ref+1;
    
    return dp;
}

/* Adds cdata text after dptr, making a new NSL_Data. */
/* Copies cdata, assumes that dptr->next is NULL      */
/* No longer copies to make it similiar to LinkItem */

NSL_Data *LinkText(const NSL_Doctype_I *doctype, NSL_Data *dptr, const Char* cdata)
{
    NSL_Data *dp;

    dp=NewNullNSLData(doctype);
    dp->type=NSL_text_data;
    dp->in=dptr->in;
    dp->first= (void *)cdata; /* instaed of strdup-ing it */
    /*
    ECNN(dp->first=sstrdup(cdata));
    */
    dptr->next=dp;
    dp->ref=dptr->ref+1;
    
    return dp;
}

/* Add item titem as the last child of item */

NSL_Data *AddItemToEnd(NSL_Item *item, NSL_Item *titem)
{
    NSL_Data *dptr;

    if(item->type==NSL_non_empty && item->data){
	for(dptr=item->data; dptr->next; dptr=dptr->next)
	    /* EMPTY */;
	return LinkItem(item->doctype, dptr, titem);
    } else {
	dptr=NewNullNSLData(item->doctype);
	dptr->type=NSL_item_data;
	dptr->in=item;
	dptr->first=titem;
	item->type=NSL_non_empty;
	titem->in=dptr;
	item->data=dptr;
	item->data->ref=0;
    }
    
    return dptr;
}

/* end of file */
