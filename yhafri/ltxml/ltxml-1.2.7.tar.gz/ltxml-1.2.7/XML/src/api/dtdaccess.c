/*
  Functions which allow one to access information in the DTD 

  Copyright LTG Edinburgh 1996, 1997

*/

#include "nsllib.h"
#include "ddb.h"
#include "string16.h"
#include "dtd.h"

/* Implementation */

/* Elements */

const AttributeSummary **ElementAttributes(const NSL_ElementSummary_I *eltsum,
					   const NSL_Doctype_I *doctype,
				    int *numAttr ) {
  int i, n = eltsum->numAttr, locNumAttr;
  const OffboardAttrs *oa=0;
  const ASPtr *asp;
  const AttributeSummary **array; /* a pointer to an array of pointers */
                            /* to AttributeSummaries             */

  if (n<0) {
    oa=doctype->offAttrsBase+(-1-n);
    n=locNumAttr=oa->oldNumAttr;
    for (asp=oa->asp;asp;asp=asp->next) {
      n++;
    };
  }
  else {
    locNumAttr=n;
  };
  *numAttr = n;
  if( n>0 ){
    ECNN(array = (const AttributeSummary**)salloc(n*sizeof(AttributeSummary*)));
    for(i=0; i<locNumAttr; i++){
      array[i] = (const AttributeSummary*)(eltsum+1)+i;
    }
    if (i<n) {
      for (asp=oa->asp;i<n;i++,asp=asp->next) {
	if (!asp) {
	  SHOULDNT;
	};
	array[i] = asp->as;
      };
    };
    return (const AttributeSummary **)array;
  } else {
    return NULL;
  }
}

NSL_Element_Content ElementContent(NSL_Doctype doctype, 
				   NSL_ElementSummary eltsum, 
				   const Char **model)
{
    return ElementFullContent(doctype, eltsum, model, 0);
}

NSL_Element_Content ElementFullContent(NSL_Doctype doctype, 
				   NSL_ElementSummary eltsum, 
				   const Char **model,
				   const struct content_particle **particle)
{
    NSL_Element_Content type = (NSL_Element_Content)eltsum->contentType;

    if(model)
	*model = 0;
    if (particle)
	*particle=0;

    if(doctype->XMLMode &&
       (model || particle) &&
       (type == NSL_Content_mixed || type == NSL_Content_element))
    {
	Dtd dtd = ((NSL_Doctype_I *)doctype)->rxp_dtd;
	ElementDefinition e = dtd->elements[*(short *)&(eltsum->omitEnd)];
	if(model)
	    *model = e->content;
	if (particle)
	    *particle = e->particle;
    }

    return type;
}

/* Attributes */

const Char *AttributeName(const AttributeSummary *atsum){
  return (Char*)atsum+atsum->namePtr;
}

/* There is a 1-1 mapping between public NSL_Attr_Dec_Value */
/* and private NSL_Attr_Declared_Value (in ddb.h)           */

NSL_Attr_Dec_Value GetAttrDeclaredValue(const AttributeSummary *atsum) {
  return (NSL_Attr_Dec_Value)atsum->declaredValue;
}

/* NB Needs DefltType[] which is defined in sgmlparse.c */
/* Actually since there is a 1-1 mapping we dont need to convert anything */
/* Order should be { NSL_defval_required,NSL_defval_current,NSL_defval_implied, */
/*		     NSL_defval_conref,NSL_defval_optional,NSL_defval_value}    */

NSL_ADefType GetAttrDefaultValueType(const AttributeSummary *atsum){
    return atsum->defaultValueType;
}

/* Allocates and returns a pointer to an array of string pointers */
/* which point to the allowed values of this attribute (if the    */
/* attribute is a enumeration type, otherwise returns NULL )      */
/* The last element of the array is a NULL pointer.               */

const Char **GetAttrAllowedValues(const AttributeSummary *atsum,
				  int *numVals){
  const Char **pvp;
  Char *pv;
  int i,nv;
  if ( atsum->numAV ){
    /* If this attribute is an enumeration type then */
    /* return a pointer to an array of strings       */
    *numVals = nv = atsum->numAV;
    pv=((Char*)atsum) + atsum->allowedValuesPtr;
    ECNN(pvp=(const Char**)tsalloc(Char*,nv+1));
    for (i=0;i<nv;i++) {
      pvp[i]=pv;
      pv+=Strlen(pv)+1;
    };
    pvp[i]=0;
    return pvp;
  } else {
    /* Otherwise return NULL */
    * numVals = 0;
    return NULL;
  }
}

/* Entities */

NSL_Entity_DataType GetEntityDataType(const EntitySummary *entsum){
  return (int)(entsum->dataType);
}

const Char *GetEntityValue(const EntitySummary *entsum){
  return (const Char*)(entsum+1);
}



