
/* Map in a .ddb file and provide access to the information there */

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>

#include "nsl-defs.h"
#include "lt-comment.h"
#include "readddb.h"
#include "lt-rhash.h"
#include "lt-safe.h"
#include "string16.h"

static boolean ShowElement(RHTEntry*,const Char*,void*);
static boolean ShowEntity(RHTEntry*,const Char*,void*);
static boolean putqs(const Char*);

const char8* ContentType[]={ "mixedGroup", "any", "cdata",
			"rcdata", "empty", "elementOnlyGroup" };
const char8* DeclaredValue[]={ "cdata", "name", "number", "nmtoken", "nutoken",
			"entity", "idref", "names", "numbers", "nmtokens",
			"nutokens", "entities", "idrefs", "id", "notation",
			"nameTokenGroup" };
const char8* DefaultValueType[]={ "required", "current", "implied", "conref",
			   "defaulted", "fixed" };
const char8* DeclType[]={ "", "% ", "{dkt}", "{lkt}" };
const char8* DataType[]={ "sgmlText", "pi", "cdata",
			 "sdata", "ndata", "subdoc" };
const char8* DefType[]={ "internal", "unresolved system",
		  "unresolved public", "resolved" };

/* readddb(filename): Read a DDB file and return its contents as a
   pointer to a DDBHeader */

DDBHeader* readddb(const char8* filename) {
  int length;
  DDBHeader* ddb;
  ECNN(ddb=(DDBHeader*)mmapfile(filename,&length));
  if (ddb->cookie==CookieVal) {
    return ddb;
  } else if ((ddb->cookie & 0xffffff00)==(CookieVal & 0xffffff00)) {
    LT_ERROR1(LEDDB, "%s is an old incompatible .ddb file --\n"
		        "remake it (e.g. by deleting and re-running mknsg) "
		        "and try again\n",filename);
    return NULL;
  } else if ((ddb->cookie & 0xffff0000)==(CookieVal & 0xffff0000)) {
    LT_ERROR1(LEDDB,"%s is a .ddb file built with the wrong CHAR_SIZE --\n"
		       "remake it (e.g. by deleting and re-running mknsg) "
		       "and try again\n",filename);
    return NULL;
  } else if(((ddb->cookie >> 24) & 0xff) == (CookieVal & 0xff) &&
	    ((ddb->cookie >> 16) & 0xff) == ((CookieVal >> 8) & 0xff))
  {
    LT_ERROR1(LEDDB,"%s is a ddb file with the wrong byte order --\n"
		       "remake it (e.g. by deleting and re-running mknsg) "
		       "and try again\n",filename);
    return NULL;
  } else {
    LT_ERROR1(LEDDB,
	   "%s is not a .ddb file\n",
	   filename);
    return NULL;
  }
}

/* Print a DDBHeader structure to stdout in a human readable format */

boolean showddb(const DDBHeader* ddb) {
  RHashTableHdr *eltHdr,*entHdr;
  char *eltBase,*entBase;
  char *sBase=(char*)ddb;
  ECEF(sFprintf(Stdout,"DDB file for %s dumped at %s",
	       sBase+(ddb->sourceFileNameOffset),
	       ctime( &ddb->timestamp)));
  ECEF(sFprintf(Stdout,"   DTD: %S, based on %s.\n",
	       sBase+sizeof(DDBHeader),
	       (ddb->dtdFileNameOffset)?sBase+(ddb->dtdFileNameOffset):"<no external dtd file>"));
  eltHdr=(RHashTableHdr*)(sBase+(ddb->elementTableOffset));
  eltBase=((char*)eltHdr)+eltHdr->length;
  ECFF(rmaphash(ShowElement,eltHdr,(void*)eltBase));
  if (ddb->entityTableOffset) {
    entHdr=(RHashTableHdr*)(sBase+(ddb->entityTableOffset));
    entBase=((char*)entHdr)+entHdr->length;
    ECFF(rmaphash(ShowEntity,entHdr,(void*)entBase));
  }
  return TRUE;
}

/* Internal function (of showddb) to display SGML element definitions */

boolean ShowElement(RHTEntry* entry,const Char* key,void *eltBase) {
  int i,nAttr,j,prefix;
  AttributeSummary* attrBase;
  Char *lab;
  
  NSL_ElementSummary_I* eltSum=(NSL_ElementSummary_I*)(((char*)eltBase)
						       +entry->eval);
  
  ECEF(sFprintf(Stdout, "<!ELEMENT %S %s %s %s>\n",
	       key,
	       eltSum->omitStart?"o":"-",
	       eltSum->omitEnd?"o":"-",
	       ContentType[(int)(eltSum->contentType)]));
  if ((nAttr=eltSum->numAttr)) {
    prefix=11+Strlen(key);
    ECEF(sFprintf(Stdout,"<!ATTLIST %S ",key));
    attrBase=(AttributeSummary*)(eltSum+1);
    for (i=0;i<nAttr;i++) {
      int n, declaredValue = (int)(attrBase[i].declaredValue);
      Char *avp;
      ECEF(sFprintf(Stdout, "%S %s",
		   (lab=(Char*)&attrBase[i])+attrBase[i].namePtr,
		   DeclaredValue[declaredValue]));
      if( (n=(int)attrBase[i].numAV) ){
	/* If this attribute is an enumeration type then */
	/* print out the allowed values                  */
	avp=lab+attrBase[i].allowedValuesPtr;
	ECEF(sFprintf(Stdout,":("));
	ECEF(sFprintf(Stdout,"%S",avp));
	while( --n > 0 ){
	  avp = avp + Strlen(avp) + 1 ;
	  ECEF(sFprintf(Stdout,"|%S",avp));
	}
	ECEF(sFprintf(Stdout,")"));
      }
      ECEF(sFprintf(Stdout, " %s",
		    DefaultValueType[(int)(attrBase[i].defaultValueType)]));
      if (attrBase[i].defaultPtr) {
	ECEF(sFprintf(Stdout,":%S",
		     lab+attrBase[i].defaultPtr));
      }
      if ((i+1)<nAttr) {
	ECEF(sPutc('\n', Stdout));
	for (j=0;j<prefix;j++) {
	  ECEF(sPutc(' ', Stdout));
	}
      }
    }
    ECEF(sFprintf(Stdout,">\n"));
  }
  return TRUE;
}

/* Internal function (of showddb) to display SGML entity definitions */

boolean ShowEntity(RHTEntry* entry,const Char* key, void *entBase) {

  /* note we never see parameter entities, as they're not dumped,
     because they're not public */
  
  EntitySummary* entSum=(EntitySummary*)(((char*)entBase)+entry->eval);

  ECEF(sFprintf(Stdout,"<!ENTITY %s%S %s:(%s)",
	       DeclType[(int)(entSum->declType)],
	       (Char*)key,
	       DataType[(int)(entSum->dataType)],
	       DefType[(int)(entSum->defType)]));
  ECFF(putqs((Char*)(entSum+1)));
  ECEF(sFprintf(Stdout,">\n"));
  return TRUE;
}

/* Internal function (of ShowEntity) to display SGML element definitions
   Prints (to stdout) a properly quoted version of the input string */

boolean putqs(const Char* str) {
  int i,len;
  if (Strchr(str,'\'')) {
    if (Strchr(str,'"')) {
      ECEF(sPutc('\'', Stdout));
      len=Strlen(str);
      for (i=0;i<len;i++) {
	if (str[i]=='\'') {
	  ECEF(sFprintf(Stdout,"&dq;"));
	}
	else {
	  ECEF(sPutc(str[i], Stdout));
	}
      }
      ECEF(sPutc('\'', Stdout));
    }
    else {
      ECEF(sFprintf(Stdout,"\"%S\"",str));
    }
  }
  else {
    ECEF(sFprintf(Stdout,"\'%S\'",str));
  }
  return TRUE;
}

/* New function which checks that any external DTD files referred to
   by DDB file have not been changed later than the DDB file.
   Returns FALSE if ddbFile is older than its external DTD.
   Can only be a heuristic check. */

boolean checkddb(const char8* ddbFile, const DDBHeader* ddb, boolean quiet){
  struct stat buf;
  const char * extDtd = (char*)ddb+(ddb->dtdFileNameOffset);
  char actualextDtdFile[300];
  size_t len;
  int NWAPPL = 3+LENERR;

  if( ddb->dtdFileNameOffset ){
    if( ( strstr(extDtd,"SYSTEM ") || strstr(extDtd,"system ") ) && 
	( strstr(extDtd,"\"")      || strstr(extDtd,"'"))){
      extDtd += strcspn(extDtd,"\"\'")+1;
      len = strcspn(extDtd,"\"\'");
      if( len > 299 ){
	if( !quiet ){
	  WARN1(NWAPPL,"Warning: external DTD filename too long %s.\n", extDtd);
	}
	return TRUE;
      }
      strncpy(actualextDtdFile,extDtd,len);
      actualextDtdFile[len] = '\000';
      if( stat(actualextDtdFile,&buf) == 0 ){
	time_t dtdTime = buf.st_mtime;
	if( stat(ddbFile,&buf) == 0 ){
	  if( dtdTime > buf.st_mtime ){
	    /* External DTD file newer than DDB file - DDB file may be
	       outofdate */
	    if( !quiet ){
	      WARN2(NWAPPL,"Warning: external DTD file %s is newer than DDB file %s.\n",
		    actualextDtdFile,ddbFile);
	    }
	    return FALSE;
	  }
	} else {
	  if( !quiet ){
	    WARN1(NWAPPL,"Warning: couldn't stat() DDB file %s.\n", ddbFile);
	  }
	}
      } else {
	/* We couldnt stat() the external DTD file */
	if( !quiet ){
	  WARN1(NWAPPL,"Warning: stat() couldn't access external DTD file '%s'\n",
		actualextDtdFile);
	  WARN1(NWAPPL,"referenced from DDB file %s.\n",ddbFile);
	}
      }
    } else {
      /* Nothing - we're not going to start resolving PUBLIC identifiers */
      /* What about URLs ? */
    }
  } else {
    /* No external DTD file specified in DDB - so we need not do any
       checking */
  }
  return TRUE;
}

