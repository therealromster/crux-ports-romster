#include "nsllib.h"
#include "nsl-ibit.h"
#include "ctype16.h"
#include "string16.h"
#include <assert.h>

/* Functions defined in this file */

static SFState FlushRe(NSL_File_I *f,SFState state);
SFState PrintStartTagInternal(NSL_File_I *f, SFState state,
			      const NSL_Item *item);
static SFState PrintProcessingInstructionInternal(NSL_File_I *f, SFState state,
					   const Char *text);
static SFState PrintEndTagInternal(NSL_File_I *f, SFState state,
				   const Char *label);
static SFState PrintTextInternal(NSL_File_I *f, SFState state,
				 const Char *text);
static SFState PrintItemInternal (NSL_File_I *f, SFState state,
			   const NSL_Item *item);
static SFState PrintCommentInternal(NSL_File_I *f, SFState state,
				    const Char *text);
static SFState PrintDoctypeInternal(NSL_File_I *f, SFState state,
				    const Char *text);
static SFState PrintCDataInternal(NSL_File_I *f, SFState state,
				  const Char *text);
static SFState PrintERefInternal(NSL_File_I *f, SFState state,
				 const Char *text);
static int PrintCanonical(const Char *text, FILE16 *file16);
static int PrintAllAttrs(NSL_File_I *f, const NSL_Item *item);
static int AttrCompare(const void *a, const void *b);

/* Note that for the time being all the external entry points return 0 on
   success rather than an actual character count, as would be preferable.
   EOF is always used for failure. */

int PrintAttrVal(const NSL_Attr *refvar, FILE16 *output, NSL_File_I *f);
static SFState PrintDataInternal(NSL_File_I *f, SFState state, const NSL_Data *data);

static SFState FlushRe(NSL_File_I *f,SFState state) {
  if (state==_pending_re) {
    ECEE(sPutc('\n',f->file16));
    return _elt_unknown;
  } else {
    return state;
  }
}

void ForceNewline(NSL_File_I *f) {
  f->state=_pending_re;
}

int ForceOutput(NSL_File_I *f) {
  ECEE(f->state=FlushRe(f,f->state));
  return sFflush(f->file16);
}
/*
 * Added to API to balance PrintEndTag. It creates an item
 * and maybe an ElementSummary (so is only for special occasions)
 */

int PrintStartTag(NSL_File_I *f, const Char *label) {
  NSL_Item * item;
  int len = Strlen(label);

  if(!f->doctype)
  {
      ECEE(sFprintf(f->file16, "<%S>", label));
      return 0;
  }

  if(FindElementAndName(f->doctype,&label,len) == NULL){
    /* 
     * This only occurs when processing NSL documents
     */
    LT_ERROR1(NEAPPL,"You must provide a label which is in the DTD (found %s)\n",label);
  }

  ECNE(item = NewNullNSLItem(f->doctype,label,len));
  ECEE(f->state=PrintStartTagInternal(f, f->state, item));
  FreeItem(item);
  return 0;
}

/*
 * PrintItemStartTag
 * Added to API as another way of balancing PrintEndTag. 
 * Prints the start tag of an existing item (with 
 * any attributes that are present)
 */

int PrintItemStartTag(NSL_File_I *f,const NSL_Item *item) {
  ECEE(f->state=PrintStartTagInternal(f, f->state, item));
  return 0;

}


SFState PrintStartTagInternal(NSL_File_I *f, SFState state,
			      const NSL_Item *item) {
  NSL_Attr *attr;

  /* The assumption is that in XMLMode, we only know about eltContent
     if we have read a useful DTD, so in that case we can output it as well.
     Note this will do the WRONG thing if we feed a dumb application
     which ignores the DTD */

  if(f->type & NSL_read)
  {
      /* An Error- trying to write to an input file */
      LT_ERROR(NEIO,"Trying to write to an input file");
      return state;
  }

  switch (f->type & NSL_write_style) {
  case NSL_write_default:
  case NSL_write_fancy:
      /* The output is more readable if, within element content,
	 tags begin on a new line. */

      if (TOP(f->eltContent)->contentType==dc_element) {
	  ECEE(sPutc('\n',f->file16));
      }
      PUSH(f->eltContent,item->defn);
      ECEE(FlushRe(f,state));
      state=_elt_begin; /* jjc pushes onto an os stack here, but that's
			   only necessary if handling PIs and included items,
			   which we're NOT */
  }

  ECEE(sFprintf(f->file16,"<%S", item->label));
  if(f->type & NSL_write_canonical) {
      ECEE(PrintAllAttrs(f, item));
  } else {
      for (attr=item->attr; attr!=NULL; attr=attr->next)
	  ECEE(PrintAttrVal(attr, f->file16, f));
  }
  if (item->type==NSL_empty && (!f->doctype || f->doctype->XMLMode)) {
      if(f->type & NSL_write_canonical)
      {
	  ECEE(sFprintf(f->file16, "></%S>", item->label));
      }
      else
      {
	  ECEE(sFprintf(f->file16,"/>"));
      }
  } else {
    ECEE(sFprintf(f->file16,">"));
  }
  return state;
}

/* Printing processing instructions */
/* This code is now responsible for printing the
   initial processing instruction in NSL and XML
   files. We want this to have a newline after it
   but not one before it. The code relies on the
   assumption that the eltContent stack of the 
   relevant file will be empty when this processing 
   instruction is printed. The original code would
   have accessed garbage if it had ever been called
   with an empty eltContent stack, since TOP does not
   check. 
   */



static SFState PrintProcessingInstructionInternal(NSL_File_I *f, SFState state,
					   const Char *text) {
  FILE16* file16=f->file16;
  int xmlmode = f->doctype ? f->doctype->XMLMode : 1;

  switch (f->type & NSL_write_style) {
  case NSL_write_plain:
  case NSL_write_canonical:
    break;
  default:
    /* The output is more readable if, within element content,
       PIs begin on a new line. */

    
    if (NONEMPTY(f->eltContent) &&
	TOP(f->eltContent)->contentType==dc_element) {
      ECEE(sPutc('\n',file16));
    }
    ECEE(f->state=state=FlushRe(f,state));
  }

  if((f->type & NSL_write_style) == NSL_write_canonical && !Strchr(text, ' '))
  {
      /* In canonical mode, put a space after the name even if no body */
      ECEE(sFprintf(file16,"<?%S %s>", text, xmlmode?"?":""));
  } else {
      ECEE(sFprintf(file16,"<?%S%s>", text, xmlmode?"?":""));
  }
      

  switch (f->type & NSL_write_style) {
  case NSL_write_plain:
  case NSL_write_canonical:
    break;
  default:
    /* The output is more readable if, within element content,
       PIs end on a new line. */
    if (EMPTY(f->eltContent) || TOP(f->eltContent)->contentType==dc_element) {
      sPutc('\n',file16);
    }
  }
  return f->state;
}


static SFState PrintDoctypeInternal(NSL_File_I *f, SFState state,
				    const Char *text) {
  FILE16 * file16 = f->file16;
  
  ECEE(sFprintf(file16, "<!DOCTYPE %S>\n", text));
  return f->state;
}

static SFState PrintCommentInternal(NSL_File_I *f, SFState state,
				    const Char *text) {
  FILE16 * file16 = f->file16;
  if(!(f->type & NSL_write_canonical))
      /* XXX do we want any newlines here? */
      ECEE(sFprintf(file16, "<!--%S-->", text));
  return f->state;
}




static SFState PrintEndTagInternal(NSL_File_I *f, SFState state, const Char *label) {
  /* see StartTag above for comment on XMLmode */
  switch (f->type & NSL_write_style) {
  case NSL_write_plain:
  case NSL_write_canonical:
    break;
  case NSL_write_fancy:
    switch (state) {
    case _pending_re:
      ECEE(sPutc('\n',f->file16));
    case _elt_text:
      ECEE(sPutc('\n',f->file16));
      POPNV(f->eltContent);
      break;
    default:
      if (POP(f->eltContent)->contentType==dc_element) {
	/* The output is more readable if, within element content,
	   tags begin on a new line. */
	ECEE(sPutc('\n',f->file16));
      }
    }
    break;
  default:
    if (state==_pending_re) {
      ECEE(sFprintf(f->file16,"\n\n"));
      POPNV(f->eltContent);
    } else if (POP(f->eltContent)->contentType==dc_element) {
      /* The output is more readable if, within element content,
	 tags begin on a new line. */
      ECEE(sPutc('\n',f->file16));
    }
    state=_elt_end; /* jjc pops the os stack here, see comment above */
  }
  ECEE(sFprintf(f->file16,"</%S>", label));

  return state;
}

int PrintEndTag(NSL_File_I *f, const Char *label) {
  ECEE(f->state=PrintEndTagInternal(f, f->state, label));
  return 0;
}

static SFState PrintERefInternal(NSL_File_I *f, SFState state, const Char *text) {
    FILE16 * file16 = f->file16;

    /* What should we do for canonical output?  Forget it, it doesn't make
       sense to combine it with no_expand input. */

    ECEE(sFputs(text,file16));
  
    return state;
}

static SFState PrintCDataInternal(NSL_File_I *f, SFState state, const Char *text) {
    FILE16 * file16 = f->file16;

    if((f->type & NSL_write_style) == NSL_write_canonical)
	PrintTextInternal(f, state, text);
    else
	ECEE(sFprintf(file16, "<![CDATA[%S]]>", text));
  
    return state;
}

static SFState PrintTextInternal(NSL_File_I *f, SFState state, const Char *text) {
  FILE16 * file16 = f->file16;
  size_t len;
  int style = (f->type & NSL_write_style);
  int xmlmode = f->doctype ? f->doctype->XMLMode : 1;

  if(xmlmode &&
     (style == NSL_write_default || style == NSL_write_fancy))
      style = NSL_write_plain;

  switch (style) {
  case NSL_write_plain:
    if (xmlmode && (Strchr(text,'&') || Strchr(text,'<'))) {
      register const Char *ptr=text;
      for (;*ptr;ptr++) {
	switch (*ptr) {
	case '&': ECEE(sFprintf(file16,"&#38;"));
	  break;
	case '<': ECEE(sFprintf(file16,"&#60;"));
	  break;
	default: ECEE(sPutc(*ptr,file16));
	}
      }
    } else {
      ECEE(sFputs(text,file16));
    }
    break;

  case NSL_write_canonical:
      ECEE(PrintCanonical(text, file16));
      break;

  default:
    switch (*text) {
    case '\n':
      ECEE(state=FlushRe(f,state));
      if (state==_elt_begin) {
	ECEE(sPutc('\n',file16));
      }
      state=_pending_re;
      text++;
      break;
    default:
      if (style==NSL_write_fancy &&
	  state==_elt_begin) {
	ECEE(sPutc('\n',file16));
      }
    }
    if ((len=Strlen(text))) {
      ECEE(state=FlushRe(f,state));
      if (text[len-1]=='\n') {
	state=_pending_re;
	ECEE(sFprintf(file16,"%.*S",len-1,text)); /* leave off the trailing RE */
      } else {
	state=_elt_text;
	ECEE(sFputs(text,file16));
      }
      /* note if we've output NO text we leave the state alone --
	 may be _pending_re or _elt_begin */
    }
  }
  return state;
}

int PrintText(NSL_File_I *f, const Char *text) {
  ECEE(f->state=PrintTextInternal(f, f->state, text));
  return 0;
}

/* Print test without any regard for embedded markup. 
 * Use at your own risk!
 */
int PrintTextLiteral(NSL_File_I *f, const Char *text) {
    ECEE(sFputs(text, f->file16));
    return 0;
}

static SFState PrintItemInternal (NSL_File_I *f, SFState state,
			   const NSL_Item *item) {
  ECEE(state=PrintStartTagInternal(f, state, item));
  switch (item->type) {
  case NSL_empty:
    POPNV(f->eltContent);
    state=_elt_end;
    break;
  case NSL_non_empty:
    ECEE(state=PrintDataInternal(f, state, item->data));
    ECEE(state=PrintEndTagInternal(f, state, item->label));
    break;
  case NSL_inchoate:
    break;
  default:
    SHOULDNT;
    return state;
  }
  return state;
}

SFState PrintDataInternal(NSL_File_I *f, SFState state, const NSL_Data *data) {
  while (data) {
    switch (data->type) {
    case NSL_item_data:
      ECEE(state=PrintItemInternal(f, state, (NSL_Item *) data->first));
      break;
    case NSL_pi_data:
      ECEE(state=PrintProcessingInstructionInternal(f, state, (Char *) data->first));
      break;
    case NSL_comment_data:
      ECEE(state=PrintCommentInternal(f, state, (Char *) data->first));
      break;
    case NSL_text_data: 
      ECEE(state=PrintTextInternal(f, state, (Char *) data->first));
      break;
    case NSL_eref_data:
      ECEE(state=PrintERefInternal(f, state, (Char *) data->first));
      break;
    case NSL_cdata_data:
      ECEE(state=PrintCDataInternal(f, state, (Char *) data->first));
      break;
    default:
      SHOULDNT;
      return state;
    }
    data=data->next;
  }
  return state;
}

/* 
 * this check is necessary at the moment because there may be
 * several processing instructions and/or comments before the
 * XML doctype announces itself. See data/torture.xml for an
 * example where this happens. In this example it will _not_ be
 * the case that open_output picks up the doctype, as it usually
 * does, but it will at some point be picked up by a subsequent
 * call of NextBit. 
 */

int PrintItem(NSL_File_I *f, const NSL_Item *item) {
  if( !item ) return -1;
#if 0
  ECEE(CheckDCT(f));
#endif

  ECEE(f->state=PrintItemInternal(f, f->state, item));
  return 0;
}

int PrintBit(NSL_File_I *f, const NSL_Bit *bit) {
#if 0
  ECEE(CheckDCT(f));
#endif
  switch (bit->type) {
  case NSL_start_bit:
  case NSL_empty_bit:
    ECEE(f->state=PrintItemInternal(f, f->state, bit->value.item));
    break;
  case NSL_text_bit:
    if(bit->flags & NSL_text_isCData) {
	ECEE(f->state=PrintCDataInternal(f, f->state, bit->value.body));
    } else if(bit->flags & NSL_text_isERef) {
	ECEE(f->state=PrintERefInternal(f, f->state, bit->value.body));
    } else {
	ECEE(f->state=PrintTextInternal(f, f->state, bit->value.body));
    }
    break;
  case NSL_end_bit:
    ECEE(f->state=PrintEndTagInternal(f, f->state, bit->label));
    break;
  case NSL_doctype_bit:
    ECEE(f->state=PrintDoctypeInternal(f, f->state, bit->value.body));
    break;
  case NSL_comment_bit:
    ECEE(f->state=PrintCommentInternal(f, f->state, bit->value.body));
    break;
  case NSL_pi_bit:
    ECEE(f->state=PrintProcessingInstructionInternal(f, f->state, bit->value.body));
    break;
  default:
    WARN1(NEUNSUP,"Type not handled for PrintBit: %d\n",(int)(bit->type));
  }
  return 0;
}

int PrintAttrVal(const NSL_Attr *refvar, FILE16 *output, NSL_File_I *f) {
    int i, n, clean;
    Char qt;
    const Char *str;
    int xmlmode = f->doctype ? f->doctype->XMLMode : 1;

    CCOMMENT("Attempting to print an Attr value\n");

    str=refvar->value.string;

    /* assume no mixed quotes, i.e. in case of mixed quotes one is
       encoded in an entity */
    if ((!xmlmode) && (n=Strlen(str))) {
      clean=1;
      for (i=0;i<n;i++) {
	if (!is_xml_namechar(str[i], xml_char_map)) {
	  clean=0;
	  break;
	}
      }
    } else {
      /* XMLMode or empty string is dirty by definition */
      clean=0;
    }
    if (clean) {
      ECEE(sFprintf(output," %S=%S",refvar->name,str));
    } else {
      qt=Strchr(str,'\'')?'"':'\'';
      if (xmlmode && (Strchr(str,qt) || Strchr(str,'&') ||
				  Strchr(str,'<'))) {
	register const Char *ptr=str;
	ECEE(sFprintf(output," %S='",refvar->name));
	for (;*ptr;ptr++) {
	  switch (*ptr) {
	  case '\'': ECEE(sFprintf(output,"&#39;")); break;
	  case '&':
	      if(f->type & NSL_write_no_expand) {
		  ECEE(sPutc('&', output)); break;
	      } else {
		  ECEE(sFprintf(output,"&#38;")); break;
	      }
	  case '<': ECEE(sFprintf(output,"&#60;")); break;
	  default:
	    ECEE(sPutc(*ptr,output));
	  }
	}
	ECEE(sPutc('\'',output));
      } else {
	ECEE(sFprintf(output,
		      " %S=%c%S%c",refvar->name, qt,str,qt));
      }
    }
  return 0;
}

static int PrintCanonical(const Char *text, FILE16 *file16)
{
    const Char *pc, *last;

    for(pc = last = text; *pc; pc++)
    {
	if(*pc == '&' || *pc == '<' || *pc == '>' || *pc == '"' ||
	   *pc == 9 || *pc == 10 || *pc == 13)
	{
	    if(pc > last)
	    {
		ECEE(sFprintf(file16, "%.*S", pc - last, last));
	    }
	    switch(*pc)
	    {
	    case '<':
		ECEE(sFprintf(file16, "&lt;"));
		break;
	    case '>':
		ECEE(sFprintf(file16, "&gt;"));
		break;
	    case '&':
		ECEE(sFprintf(file16, "&amp;"));
		break;
	    case '"':
		ECEE(sFprintf(file16, "&quot;"));
		break;
	    case 9:
		ECEE(sFprintf(file16, "&#9;"));
		break;
	    case 10:
		ECEE(sFprintf(file16, "&#10;"));
		break;
	    case 13:
		ECEE(sFprintf(file16, "&#13;"));
		break;
	    }
	    last = pc+1;
	}
    }
	
    if(pc > last)
    {
	ECEE(sFprintf(file16, "%.*S", pc - last, last));
    }

    return 0;
}

/* Print all attributes, including defaulted ones, in sorted canonical form */

static int PrintAllAttrs(NSL_File_I *f, const NSL_Item *item)
{
    const AttributeSummary **a;
    int i, n;

    a = ElementAttributes(item->defn,
			  item->doctype,
			  &n);
    if(n > 0)
    {
	if(!a)
	    return -1;
    }
    else
	return 0;

    qsort((void *)a, n, sizeof(*a), AttrCompare);

    for(i=0; i<n; i++)
    {
	const Char *name = (Char *)a[i] + a[i]->namePtr;
	const NSL_Attr *attr;
	const Char *value;

	attr = FindAttr(item->attr, name);
	if(attr)
	    value = attr->value.string;
	else
	{
	    value = GetAttrDefVal(a[i]);
	    if(value == NSL_Implied_Attribute_Value)
		continue;
	}

	ECEE(sFprintf(f->file16, " %S=\"", name));
	ECEE(PrintCanonical(value, f->file16));
	ECEE(sFprintf(f->file16, "\""));
    }

    ECFE(sfree((AttributeSummary**)a));

    return 0;
}

/* Comparison function for sorting attribute names */

static int AttrCompare(const void *a, const void *b)
{
    const AttributeSummary *aa = *(AttributeSummary **)a,
	                   *bb = *(AttributeSummary **)b;

    return Strcmp((Char *)aa + aa->namePtr, 
		  (Char *)bb + bb->namePtr);
}
