/* This version uses Richard's XML aware parser

   Removed (moved to sgmlfiles.c):

   ParseAttributeString
   PAS1

   */

#include "nsllib.h"
#include "string16.h"
#include "lt-sstring.h"

static Query_Result GetMatchingComponent(NSL_File_I *sgmlfile, const NSL_Query_I *q, NSL_Item **MITEMp, NSL_Bit **MBITp);

NSL_Data *AddTextData(NSL_Item *item, Char *textp, NSL_Data *dat);

/* I don't understand steve's types . . . ht */

NSL_AVType AttrValueType[]={ 
  /*          cdata,        name,       number,    nmtoken, */
  NSL_attr_string,NSL_attr_token,NSL_attr_num,NSL_attr_token,
  /*     nutoken,         entity,     idref,      names, */
  NSL_attr_token,NSL_attr_entity,NSL_attr_refid, NSL_attr_tokens,
  /*    numbers,   nmtokens,      nutokens,       entities, */
  NSL_attr_nums, NSL_attr_tokens, NSL_attr_tokens, NSL_attr_entities,
  /*       idrefs,      id,              notation, nameTokenGroup */
  NSL_attr_refids, NSL_attr_id, NSL_attr_notation, NSL_attr_token};

/* static NSL_Bit BAD_BIT={NSL_bad,NULL,NULL}; */

NSL_Bit* GetNextBit(NSL_File_I *sgmlfile) {
  NSL_Bit *bit;

  /*  if (sgmlfile==NULL) {
    LT_ERROR(NEFSER,"GetNextBit: No NSL_File given as argument\n");
    return &BAD_BIT;
  } */
    
  CCOMMENT("Getting a bit\n");

  bit=NextBit(sgmlfile);
  switch (bit->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
    case NSL_end_bit:
    case NSL_text_bit:
    case NSL_bad:
      return bit;
    case NSL_pi_bit:
    case NSL_comment_bit:
    case NSL_doctype_bit:
      if(sgmlfile->type & NSL_read_all_bits)
	  return bit;
      else
      {
	  ECFN(FreeBit(bit));
	  return GetNextBit(sgmlfile);
      }
    case NSL_eof_bit:
      return NULL;
    default:
      SHOULDNT;
      bit->type=NSL_bad;
      return bit;
  }
}

/* AddCloseContext and AddOpenContext moved here from query.c 
   since this is where they are called */	    

/* AddOpenContext: Extend the context chain. Add item as the first 
   daughter of f->currentbase, add a new NSL_Data into the item, 
   and move f->currentbase to point to this new NSL_Data. */

boolean AddOpenContext( NSL_File_I *f, NSL_Item *item) {
    NSL_Data *dptr;

    dptr=f->currentbase;
    dptr->first=item;
    ECNF(item->data=NewNullNSLData(item->doctype));
    item->in=dptr;
    item->data->in=item;
    dptr->ref=f->cnum;
    item->data->ref=f->cnum=0;
    if (dptr->in)
	dptr->in->type=NSL_non_empty;
    dptr->type=NSL_item_data;
    f->currentbase=item->data;
    return TRUE;
}

/* AddCloseContext: shrink the context chain. Moves f->currentbase up
   by two 'in' pointers. This frees the current bottom NSL_Data, but
   leaves a dangling NSL_Item, which will must be freed explicitly,
   either by the user if the match succeeds, or by us otherwise. */

boolean AddCloseContext( NSL_File_I *f, const Char *tagname ) {
  NSL_Data *dptr, *dpold;

  COMMENT1("CLOSE: %s\n", tagname);

  dptr=f->currentbase;

  if (tagname?(dptr->in?(dptr->in->label!=tagname):TRUE):FALSE) {
    COMMENT("Out of context\n");
    return 1; /* Mismatch --- close does not match current open */
  } else {
    dpold=dptr->in->in;
    f->cnum=dpold->ref+1;
    dpold->first=NULL;		/* cut the downwards chain, so that when
				   the user comes back again all will ready */
    if (dpold->in) {
      dpold->in->type=NSL_inchoate;
    }
    dptr->in->data=NULL;	/* kill the pointer to dptr */
    ECFF(FreeData(dptr, dptr->in->doctype));	/* and free it */
    f->currentbase=dpold;
    COMMENT("CLOSED!!\n");
    return TRUE;
  }
}

static NSL_Item BAD_ITEM={NULL,NULL,NULL,NULL,NULL,0,0,NULL,NSL_bad,NULL,NULL,NULL,NULL};

/* 
 * If this returns _query_win, *MITEMp contains the matching item.
 * If it returns _query_lose, *MBITp contains the bit to print and free.
 */

static Query_Result GetMatchingComponent(NSL_File_I *sgmlfile, const NSL_Query_I *q, NSL_Item **MITEMp, NSL_Bit **MBITp) {
  NSL_Item *MITEM;
  NSL_Bit *MBIT;

  CCOMMENT("Getting a bit\n");
    
  MBIT=NextBit(sgmlfile);
  switch (MBIT->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
      MITEM=MBIT->value.item;
      if (!AddOpenContext(sgmlfile, MITEM)) {
	goto querr;
      }
      if (ExecQueryUp(q, MITEM->in)) {
	if (!AddCloseContext(sgmlfile, NULL)) {
	  goto querr;
	}
	/* this cuts off downward pointer and frees MITEM->data */
	/* so we're 'in' the upward chain, but it doesn't point down to us */
	/* This is to put us in position for the next call */
	MITEM=ItemParse(sgmlfile, MITEM);
	if (MITEM->type==NSL_bad) {
	  goto querr;
	}
	*MITEMp = MITEM;
	return _query_win;
      } else {
	/* Query failed */
	if (MBIT->type==NSL_empty_bit)
	  if (!AddCloseContext(sgmlfile, MITEM->label)) {
	    goto querr;
	  }
	*MBITp = MBIT;
	return _query_lose;
      }
    case NSL_end_bit:
      MITEM=sgmlfile->currentbase->in;
      if (!AddCloseContext(sgmlfile, MBIT->label)) {
	goto querr;
      }
      /*printf("GMC: MITEM = %d %s\n",(int)MITEM, MITEM->label);*/
      /* This is supposed to free items which are to the left of the
         current path to the latest matching item. BUT ??? This means
         GNQI will destroy parent items and hence items returned by
         previous calls? */
      FreeItem(MITEM);
      *MBITp = MBIT;
      return _query_lose;
    case NSL_text_bit:
      *MBITp = MBIT;
      return _query_lose;
    case NSL_pi_bit:
    case NSL_comment_bit:
    case NSL_doctype_bit:
      /* ignored for now ??? probably ok*/
      FreeBit(MBIT);
      return GetMatchingComponent(sgmlfile, q, MITEMp, MBITp);
    case NSL_eof_bit:
      return _query_eof;
    case NSL_bad:
querr:
      FreeBit(MBIT);
      return _query_err;
    default:
      SHOULDNT;
      return _query_lose;
  }
}    

NSL_Item *GetNextQueryItem( NSL_File_I *infile, const NSL_Query_I *q,
			    NSL_File_I *ofile) {
  Query_Result qval;
  NSL_Item *MITEM;
  NSL_Bit *MBIT;

  while ((qval=GetMatchingComponent(infile, q, &MITEM, &MBIT))!=_query_eof) {
    switch (qval) {
    case _query_win:
      return MITEM;
    case _query_lose:
      if (ofile) {
	if (PrintBit(ofile,MBIT)==EOF) {
	  return &BAD_ITEM;
	}
      }
      switch (MBIT->type) {
      case NSL_empty_bit:
      case NSL_end_bit:
      case NSL_text_bit:
	if (!FreeBit(MBIT)) {	/* frees contents only */
	  return &BAD_ITEM;
	}
      default:
	break;
      }
      break;
    case _query_err:
      return &BAD_ITEM;
    default:
      SHOULDNT;
      return &BAD_ITEM;
    }
  }
  return NULL;
}

NSL_Item *GetNextItem(NSL_File_I *sgmlfile) {
  NSL_Bit *bit;

  /*  if (sgmlfile==NULL) {
      LT_ERROR(NEFSER,"GetNextItem: No NSL_File given as argument\n");
      return &BAD_ITEM;
      } */
    
  CCOMMENT("Getting a bit\n");
  bit=NextBit(sgmlfile);

  if (bit) {
    switch (bit->type) {
    case NSL_start_bit:
      return ItemParse(sgmlfile, bit->value.item);
    case NSL_empty_bit:
      sgmlfile->currentItemCharPosn = CurrentBitOffset(sgmlfile);
      return bit->value.item;
    case NSL_pi_bit:
    case NSL_comment_bit:
    case NSL_doctype_bit:
      /* ignored for now ??? should be an error */
      WARN1(NEPARSE,
	    "Warning: GetNextItem ignoring a PI/comment/doctype: %s\n",
	    bit->value.body);
      FreeBit(bit);
      return GetNextItem(sgmlfile);
    case NSL_eof_bit:
      return NULL;
    case NSL_bad:
      return &BAD_ITEM;
    default:
      break;
    }
  }
  SHOULDNT;
  return &BAD_ITEM;
}

/* Given an NSL_Item of type NSL_inchoate, (i.e. one which only refers
  to an sgml start tag) in item, read the sgml file sgmlfile (up to
  the matching end tag) and fill in the contents of this NSL_Item. It
  both modifies the input item and returns it. */

NSL_Item *ItemParse(NSL_File_I *sgmlfile, NSL_Item *item) {
  NSL_Data *datap;
  NSL_Bit *bit;
  int i;
  size_t itemStartCharPosn;

  /*  if (sgmlfile==NULL) {
    LT_ERROR(NEFSER,"ItemParse: No NSL_File given as argument\n");
    return &BAD_ITEM;
  } */

  itemStartCharPosn = CurrentBitOffset(sgmlfile);

  if (item->type==NSL_empty) {
    sgmlfile->currentItemCharPosn = itemStartCharPosn;
    return item;
  }

  datap=NULL;

  for (i=0;;) {
    bit=NextBit(sgmlfile);
    if (bit) {
      switch (bit->type) {
      case NSL_text_bit:		/* Add to data list */
	if (!(datap=AddTextData(item,bit->value.body,datap))) {
	  goto retbad;
	}
	if (bit->flags & NSL_text_isCData) {
	    datap->type=NSL_cdata_data;
	} else if(bit->flags & NSL_text_isERef) {
	    datap->type=NSL_eref_data;
	}
	datap->ref=i++;
	break;
      case NSL_start_bit:		/* parse new sgml */
      case NSL_empty_bit:
	if (datap==NULL) {
	  datap=NewNullNSLData(item->doctype);
	  item->data=datap;
	  item->type=NSL_non_empty;
	}
	else {
	  datap=datap->next=NewNullNSLData(item->doctype);
	}
	if (!datap) {
	  goto retbad;
	}
	datap->type=NSL_item_data;
	datap->ref=i++;
	datap->in=item;
	datap->first=ItemParse(sgmlfile,bit->value.item);
	if (((NSL_Item *)datap->first)->type==NSL_bad) {
	  goto retbad;
	}
	((NSL_Item *)datap->first)->in=datap;
	break;
      case NSL_end_bit:		/* check and pop */
	if (bit->label!=item->label) {
	  LT_ERROR2(NECMNM,
		 "NSL Error -- </%S> closing unexpected.\nExpected </%S>\n",
		 bit->label, item->label);
	  goto retbad;
	}
	else {
	  item->type=NSL_non_empty;
	  sgmlfile->currentItemCharPosn = itemStartCharPosn;
	  /* Take ownership of the ns records */
	  item->nsowned = 1;
	  bit->nsowned = 0;
	  return item;
	}
      case NSL_pi_bit:
	if(sgmlfile->type & NSL_read_all_bits)
	{
	    if (!(datap=AddTextData(item,bit->value.body,datap))) {
		goto retbad;
	    }
	    datap->type = NSL_pi_data;
	}
	else
	    FreeBit(bit);
	break;
      case NSL_comment_bit:
	if(sgmlfile->type & NSL_read_all_bits)
	{
	    if (!(datap=AddTextData(item,bit->value.body,datap))) {
		goto retbad;
	    }
	    datap->type = NSL_comment_data;
	}
	else
	    FreeBit(bit);
	break;
      case NSL_eof_bit:
	LT_ERROR1(NEMKPR,
	       "NSL Error -- EOF (maybe invalid nSGML) inside <%S>\n",
	       item->label);
	goto retbad;
      case NSL_bad:
	goto retbad;
      default:
	SHOULDNT;
	goto retbad;
      }
    } else {
      SHOULDNT;
      goto retbad;
    }
  }
  SHOULDNT;
retbad:
  item->type=NSL_bad;
  sgmlfile->currentItemCharPosn = itemStartCharPosn;
  return item;
}

/* Create a new NSL_Data of type NSL_text_data containing textp */
/* and add as the last data of item. Dat is the last existing   */
/* data contained in item (or NULL)                             */

NSL_Data *AddTextData(NSL_Item *item, Char *textp, NSL_Data *dat) {
  NSL_Data *datap;

  ECNN(datap=NewNullNSLData(item->doctype));
  datap->in=item;

  datap->first=textp;
  datap->type=NSL_text_data;

  CCOMMENT("XD\n");
  if (item->data==NULL) {
      item->data=datap;
      item->type=NSL_non_empty;
    }
  else
    {
      dat->next=datap;
    }
  return datap;
}

boolean SetAttrValue(NSL_Attr *refvar, const Char *valin) {
  /* note does NOT free old value, if any */

  const Char *value;

  CCOMMENT("Matching an Attr value\n");

  if (valin==NULL) {
      refvar->value.string=NULL;
      return TRUE;
    }
  /* value=ParseRCData(valin);	Expand entity references */
  value=valin;

  refvar->value.string=value;
  return TRUE;
}

/* This function takes an NSL_Attr and searches (along its next ptrs ) */
/* for an NSL_Attr with the given name                                 */

NSL_Attr *FindAttr(const NSL_Attr *attr, const Char *name) {
  CCOMMENT("FindAttr\n");
  if( NSL_Global_Names == NSL_use_strings ){
    for (;attr!=NULL;attr=attr->next) {
      if ( Strcasecmp(attr->name,name) == 0){
	CCOMMENT1("Found attribute %s\n",name);
	return (NSL_Attr *)attr;
      }
    }
  } else {
    /* assume unique name */
    for (;attr!=NULL;attr=attr->next) {
      if (attr->name==name) {
	CCOMMENT1("Found attribute %s\n",name);
	return (NSL_Attr *)attr;
      }
    }
  }
  return NULL;
}


NSL_Attr* AttrFromSpec( const AttributeSummary* atsum, const NSL_Doctype_I *doctype) {
  NSL_Attr* attr;
  ECNN(attr=AllocAttr(doctype));
  attr->next=NULL;
  /* need to fill in -- drag if we have to parse defaults each time */
  attr->name=(Char*)atsum + atsum->namePtr;
  attr->valuetype=AttrValueType[(int)atsum->declaredValue];
  attr->deft=atsum->defaultValueType;
  attr->value.string=NULL;
  
  return attr;
}
  
boolean NewAttrVal(NSL_Item *item,const Char *aname,const Char *newval) {
  /* requires unique name */
  NSL_Attr *refvar;
  const AttributeSummary *atsum;

  atsum=FindAttrSpec(item->defn,item->doctype,aname);
  if ( atsum == NULL ){
    LT_ERROR2(NEUNDEF,"Error: attribute %S not defined for element <%S>\n",
		 aname,item->label);
    return FALSE;
  }
  ECNF(refvar=AttrFromSpec(atsum, item->doctype));
  if( refvar->deft == NSL_defval_conref ){
    /* We are assigning an explicit #CONREF attribute, this means that */
    /* The item is of type NSL_empty, so we flip the type of the item */
    /* But we dont free or disconnect the data pointers from this item */
    item->type = NSL_empty;
  }
  refvar->next=item->attr;
  item->attr=refvar;
  return SetAttrValue(refvar,newval);
}

int PutAttrVal(NSL_Item *item,const Char *aname, const Char *newval) {
  /* returns -1 on error, 0 if changed old attr, 1 if made a new one */
  /* requires unique name for new ones */
  NSL_Attr *refvar;
  if ((refvar=FindAttr(item->attr,aname))) {
    if (SetAttrValue(refvar,newval)) {
      return 0;
    } else {
      return -1;
    }
  } else {
    if (NewAttrVal(item,aname,newval)) {
      return 1;
    } else {
      return -1;
    }
  }
}

const EntitySummary *GetEntity(const NSL_Doctype_I *doctype, const Char *key) {
  RHTEntry* entry;

  if (doctype->entities) {
    if ((entry=rsearch(key,Strlen(key),doctype->entities))) {
      return (EntitySummary*)(doctype->entityBase+entry->eval);
    }
  }
  else {
    WARN(NEUNSUP,"Can't get entity summaries for XML file yet\n");
  };
  return NULL;
}

/* should take a callback for SDATA entity processing */
/* expand entity references */
const Char *ParseRCData(const NSL_Doctype_I *doctype,
			const Char *rcdata,
			const Char *(*expandSData)(const NSL_Doctype_I *,
						   const Char *)) {
  Char *expanded, cur;
  const Char *ptr, *entexp;
  int mallocsz=80, currmal, i, j;
  Char ename[MAXSGMLNAMELEN];
  const EntitySummary *entity;

  if(doctype->XMLMode)
  {
      /* This function neither makes sense nor works for XML, because:
       * (a) there are no SDATA entities in XML
       * (b) usually, all entities have already been expanded
       * (c) GetEntity doesn't work for XML.
       *
       * However, some programs (eg sgrpg) call it without regard for
       * whether they are processing nSGML or XML.  So we will make it
       * essentially a no-op when called with an XML doctype (it has to
       * copy the string because it does in the nSGML case).
       */

      ECNN(expanded = Strdup(rcdata));
      return expanded;
  }

  ECNN(expanded=salloc(currmal=mallocsz));

  for (i=0, ptr=rcdata; *ptr!=0; ptr++) {
    if (*ptr=='&') {

      for (j=0, ptr++; (*ptr)!=';'; ptr++, j++) {
	ename[j]=*ptr;
      }
      ename[j]=0;

      if (ename[0]=='#') {
	/* character entity, so inline it */
	cur = 0;
	/* don't use isdigit since that doesn't work for chars > 255 */
	for(j=1; ename[j] >= '0' && ename[j] <= '9'; j++)
	    cur = cur * 10 + (ename[j] - '0');
      }
      else {
	entity=GetEntity(doctype,ename);
	if (entity==NULL) {
	  LT_ERROR1(NEUNDEF,
		 "Reference to undefined entity: %S\n",ename);
	  return NULL;
	}
	else {
	  switch (entity->defType) {
	  case ent_internal:
	    /* should check is SDATA, else error */
	    ECNN(entexp=expandSData(doctype,(const Char*)(entity+1)));

	    for (j=0; entexp[j]!=0; j++) {
	      expanded[i]=entexp[j];
	      if (++i>=currmal-2) {
		expanded=srealloc(expanded, (currmal+=mallocsz));
		ECNN(expanded);
	      }
	    }
	    break;
	  default:
	    /* external */
	    LT_ERROR1(NEUNSUP,"external sdata not implemented %S\n",
			 ename+1);
	    return NULL;
	  }
	}
	continue;
      }
    } else {
      cur=*ptr;
    }
    expanded[i]=cur;
    if (++i>=currmal-2) {
      expanded=srealloc(expanded, (currmal+=mallocsz));
      ECNN(expanded);
    }
  }
  expanded[i]=0;
  return expanded;
}

extern int CurrentItemOffset( NSL_File_I *sf ){
  if (sf->currentItemCharPosn<0) {
    LT_ERROR(NEOFFST,"No item offset yet\n");
  };
  return sf->currentItemCharPosn;
}

/* end of file */
