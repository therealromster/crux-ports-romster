/* 	$Id: sgmllib.c,v 1.88 2003/09/01 17:46:11 ht Exp $	 */

#ifndef lint
static char vcid[] = "$Id: sgmllib.c,v 1.88 2003/09/01 17:46:11 ht Exp $";
#endif /* lint */

#include "nsllib.h"
#include "ctype16.h"
#include "string16.h"
#include "stdio16.h"
#include "lt-umalloc.h"
#include "lt-safe.h"		/* for smunmap() */
#include "xmlparser.h"		/* for FreeDtd() */

/* Functions defined in this file */

static NSL_Item *AllocItem(const NSL_Doctype_I *doctype);
static void ParseClose(void);
static NSL_Data *AllocData(const NSL_Doctype_I *doctype);
NSL_Item *NNI(const NSL_ElementSummary_I *elt,
	      const NSL_Doctype_I *doctype,
	      const Char *name);

boolean _NSL_initialised=FALSE;

/* Deallocate space allocated by ParseInit */

static void ParseClose(void)
{
    deinit_parser();
}

/* Procedure which cleans up after NSLInit */

void NSLClose(void) {
  
  ParseClose();

  _NSL_initialised = FALSE;
}

const char *unionerrlist[NSLNERR+1];
const char *nslerrlist[NSLNERR-LENERR]={
			  "Application-level catastrophe",
			  "Application-level error",
			  "Application-level warning",
			  "NSL-level catastrophe",
			  "Not in doctype",
			  "Invalid attribute value type",
			  "Bad internal cmd argument",
			  "Lost parsing attribute defn",
			  "Bad attribute type",
			  "Missing doctype",
			  "Parser lost",
			  "Unexpected defn tag",
			  "Bad DDB PI",
			  "Badly nested elements",
			  "Not Supported",
			  "Already free",
			  "Memory exhausted",
			  "No doctype for input file",
			  "Required NSL_File arg't not supplied",
			  "m(un)map failed",
			  "Second ddb file",
			  "Ill-formed query",
			  "Multiply defined reference",
                          "IO error: trying to write to an input file",
                          "XML version mismatch",
			  "Parser detected error",
			  "Offset not available",
			  "Pointer argument is NULL",
			  "Character/encoding error",
			  "XML/nSGML mixup"
};

int NSLInitErrorMessages( int error_Threshold ){
  int i;

  LTSTD_errthresh=error_Threshold;
  LTSTD_nerr=NSLNERR;
  for (i=0;i<=LENERR;i++) {
    unionerrlist[i]=LTSTD_errlist[i];
  }
  for (i=LENERR+1;i<=NSLNERR;i++) {
    unionerrlist[i]=nslerrlist[i-(LENERR+1)];
  }
  LTSTD_errlist=unionerrlist;
  return 0;
}

boolean NSLInit(int error_Threshold){
  NSLInitErrorMessages(error_Threshold);
  if (!_NSL_initialised) {
    ECFF(ParseInit());
    _NSL_initialised=TRUE;
  }
  return TRUE;
}

void NSLSetErrorHandler(void (*error_handler)(int))
{
     LTSTD_set_error_handler(error_handler);
}

NSL_Common_Options *NSLGetoptions(int *argcp, char **argv, 
				  const char *opts, void (*usage)(int exitval))
{
    int arg, newargc = 0, argc = *argcp;
    char *opt, *newopt;
    char **newargv;
    NSL_Common_Options *options;

    ECNN(newargv = tsalloc(char *, argc + 1));
    ECNN(options = tsalloc(struct NSL_Common_Options, 1));
    options->doctype = options->aux_doctype = 0;
    options->base_url = "<stdin>";
    options->read_type = NSL_read;
    options->write_type = NSL_write;
    
    newargv[newargc++] = argv[0];

    for(arg = 1; arg < argc; arg++)
    {
	char *thisarg = argv[arg];
 
	/* Just copy any non-option arguments */

	if(thisarg[0] != '-')
	{
	    newargv[newargc++] = thisarg;
	    continue;
	}

	/* Examine options */

	for(opt = newopt = &thisarg[1]; *opt; opt++)
	{
	    if(strchr8(opts, *opt) == 0)
	    {
		/* Copy down options we don't know about */

		if(newopt != opt)
		    *newopt = *opt;
		newopt++;
		continue;
	    }

	    /* Found an option we know about */

	    switch(*opt)
	    {
	    case 'h':
#ifdef VERSION
		fprintf(stderr, "LT XML version: %s\n", VERSION);
#endif
		usage(0);
		break;

	    case 'd':
		if(arg+1 == argc)
		    usage(2);
		ECNN(options->doctype = LoadDoctype(argv[++arg]));
		break;

	    case 'D':
		if(arg+1 == argc)
		    usage(2);
		ECNN(options->aux_doctype = LoadDoctype(argv[++arg]));
		break;

	    case 'e':
		if(options->read_type & NSL_read_validate)
		{
		    LT_ERROR(NSAPPL, "Can't use -V with -e\n");
		    return 0;
		}
		options->read_type = NSL_read|NSL_read_no_expand;
		options->write_type = NSL_write|NSL_write_no_expand;
		break;

	    case 'u':
		if(arg+1 == argc)
		    usage(2);
		options->base_url = argv[++arg];
		break;

	    case 'V':
		if(options->read_type & NSL_read_no_expand)
		{
		    LT_ERROR(NSAPPL, "Can't use -V with -e\n");
		    return 0;
		}
		options->read_type |= NSL_read_validate;
		break;

	    default:
		LT_ERROR(NSAPPL, "Bad option in NSLGetopt\n");
		return 0;
	    }
	}

	/* If there are any options left in this argument, copy to new argv */

	if(newopt > &thisarg[1])
	{
	    *newopt = 0;
	    newargv[newargc++] = thisarg;
	}
    }

    /* Copy back remaining arguments */

    for(arg = 0; arg < newargc; arg++)
	argv[arg] = newargv[arg];
    argv[newargc] = 0;
    *argcp = newargc;
    sfree(newargv);

    return options;
}

NSL_Name_Behaviour NSL_Global_Names = NSL_use_names;

NSL_Name_Behaviour NSLInitNames(NSL_Name_Behaviour name_Behaviour){
  NSL_Name_Behaviour temp = NSL_Global_Names;
  NSL_Global_Names = name_Behaviour;
  return temp;
}

static NSL_Item *AllocItem(const NSL_Doctype_I *doctype) {
  return (NSL_Item *)Usalloc(doctype->itemstack);
}

static NSL_Data *AllocData(const NSL_Doctype_I *doctype) {
  return (NSL_Data *)Usalloc(doctype->datastack);
}

NSL_Attr *AllocAttr(const NSL_Doctype_I *doctype) {
  return (NSL_Attr *)Usalloc(doctype->attrstack);
}

NSL_Q_Attr *AllocQAttr(void) {
  NSL_Q_Attr *qa;
  ECNN(qa=(NSL_Q_Attr *)salloc(sizeof(*qa)));
  /*  qa->type=_qa_text; */
#if CHAR_SIZE == 16
  qa->transbuf = 0;
#endif
  return qa;
}
       
NSL_Item *NNI(const NSL_ElementSummary_I *elt,
	      const NSL_Doctype_I *doctype,
	      const Char *name) {
  NSL_Item *item;

  ECNN(item=AllocItem(doctype));
  item->data=NULL;
  item->type=NSL_inchoate;
  item->in=NULL;
  item->attr=NULL;

  item->defn=elt;
  item->label=name;
  item->prefix=NULL;
  item->llabel=NULL;
  item->nsuri=NULL;
  item->ns_dict=NULL;
  item->nsc=0;
  item->nsowned=0;
  item->doctype=doctype;
  return item;
}

NSL_Item *NewNullNSLItem(const NSL_Doctype_I *doctype, const Char *name,
			 int len) {
  const RHTEntry *entry;
  /* Note the does NOT build a new eltsum in XML mode */

  if (doctype==NULL) {
    LT_ERROR(NWOFND,"Asked to make an item for no doctype\n");
    return NULL;
  }
  entry=rsearch(name, len?len:Strlen(name), doctype->elements);
  if (entry==NULL) {
    LT_ERROR1(NEUNDEF,"Reference to undefined element name: %S\n",
		 name);
    return NULL;
  }
  return NNI((const NSL_ElementSummary_I*)(doctype->permanentBase+entry->eval),
	     doctype,
	     (Char*)doctype->elements+entry->keyptr);
}

NSL_Data *NewNullNSLData(const NSL_Doctype_I *doctype) {
  NSL_Data *data;

  ECNN(data=AllocData(doctype));
  data->type=NSL_undefined;
  data->next=NULL;
  data->first=NULL;
  data->in=NULL;
  return data;
}

NSL_Data *NewTextNSLData(const NSL_Doctype_I *doctype,
			 const Char *text, int len, boolean copy,
			 const NSL_Data *nextptr,boolean insert) {
  /* Note if nextptr is given and insert is TRUE,
     not only is nextptr installed in the new Data,
     but the new Data is installed as in->data. */

  NSL_Data *data;

  ECNN(data=AllocData(doctype));
  data->type=NSL_text_data;
  if (copy) {
      ECNN(data->first=salloc((len?len:(len=Strlen(text)))+1));
      Strncpy(data->first,text,len);
  } else {
    data->first=(void *)text;
  }
  if ((data->next=(NSL_Data *)nextptr)!=NULL) {
    data->in=nextptr->in;
    if (insert) {
      data->in->data=data;
    }
  }
  return data;
}

NSL_Item *NewItemNSLData(const NSL_Doctype_I *doctype,
			 const Char *name, int len,
			 const NSL_Data *nextptr,boolean insert) {
  /* Note if nextptr is given and insert is TRUE,
     not only is nextptr installed in the new Data,
     but the new Data is installed as in->data. */

  NSL_Data *data;

  ECNN(data=AllocData(doctype));
  data->type=NSL_item_data;
  ECNN(data->first=NewNullNSLItem(doctype, name, len));
  ((NSL_Item*)data->first)->in=data;
  if ((data->next=(NSL_Data *)nextptr)!=NULL) {
    data->in=nextptr->in;
    if (insert) {
      data->in->data=data;
    }
  }
  return (NSL_Item*)data->first;
}

#define CPYIN(inp,ptr,start)for (ptr=start;ptr;ptr=ptr->next) ptr->in=inp

NSL_Data *MoveDataTail(NSL_Data *whereTo,NSL_Data *whereFrom) {
  NSL_Data *tmp;
  whereTo->next = whereFrom->next;
  whereFrom->next=NULL;
  CPYIN(whereTo->in,tmp,whereTo->next);
  return whereTo;
}

NSL_Data *InstallDataTail(NSL_Data *whereTo, NSL_Data *newTail) {
  NSL_Data *tmp;
  whereTo->next = newTail;
  CPYIN(whereTo->in,tmp,newTail);
  return whereTo;
}

NSL_Item *InstallData(NSL_Item *item, NSL_Data *data) {
  NSL_Data *tmp;

  item->data=data;
  CPYIN(item,tmp,data);
  if( data){
    item->type = NSL_non_empty;
  } else {
    item->type = NSL_empty;
  }
  return item;
}

boolean FreeQAttr(NSL_Q_Attr *attr,NSL_Name_Behaviour nb) {
  if (attr!=NULL) {
    if( nb == NSL_use_strings ) {
      ECFF(sfree((char*)attr->name));
    }
    switch (attr->comparison) {
    case _qa_comp_not_regexp:
    case _qa_comp_regexp: 
      ECFF(sfree((regexp*)attr->pattern.regexp));
      break;
    default:
      ECFF(sfree((char*)attr->pattern.string));
    }
    ECFF(FreeQAttr((NSL_Q_Attr *)attr->next,nb));
#if CHAR_SIZE == 16
    sfree(attr->transbuf);
#endif
    return sfree(attr);
  }
  return TRUE;
}

static void FreeNSRecords(NamespaceBinding dict, int count)
{
    int i;
    NamespaceBinding parent;

    for(i=0; i<count; i++)
    {
	parent = dict->parent;
	sfree(dict);
	dict = parent;
    }
}

boolean FreeBit(NSL_Bit *bit) {
  if (bit!=NULL) {
    switch (bit->type) {
    case NSL_start_bit:
    case NSL_empty_bit:
      ECFF(FreeItem(bit->value.item));
      break;
    case NSL_text_bit:
    case NSL_pi_bit:
    case NSL_doctype_bit:
    case NSL_comment_bit:
      ECFF(sfree((char*)bit->value.body));
    default:
      break;
    }
    if(bit->nsc > 0 && bit->nsowned)
	FreeNSRecords(bit->ns_dict, bit->nsc);
  }
  return TRUE;
}

void CopyBit(NSL_Bit *dest, const NSL_Bit *source) {
  /* Note this does NOT copy recursively, so freeing both original and copy
     will cause an error */
  memcpy((char*)dest,(char*)source,sizeof(NSL_Bit));
  /* Not quite right; what would happen if we did ItemParse on the copy? XXX */
  dest->nsowned = 0;
}

boolean FreeItem(NSL_Item *item) {
  if (item!=NULL) {
#ifndef NOMEMDEBUG
    if (item->type==NSL_free) {
      WARN(NEFRFI,"Attempt to Free an item which has already been Free'd\n");
      return TRUE;
    }
#endif
    if (item->attr) {
      ECFF(FreeAttr(item->attr, item));
    }
    if (item->data) {
      ECFF(FreeData(item->data, item->doctype));
    }
    if(item->nsc > 0 && item->nsowned)
	FreeNSRecords(item->ns_dict, item->nsc);
#ifndef NOMEMDEBUG
    item->type=NSL_free;
#endif
    return Ufree(item->doctype->itemstack, item);
  }
  return TRUE;
}

boolean FreeData(NSL_Data *data, const NSL_Doctype_I *doctype) {
  if (data!=NULL) {
#ifndef NOMEMDEBUG
    if (data->type==NSL_free_data) {
      WARN(NEFRFI,"Attempt to Free data which has already been Free'd\n");
      return TRUE;
    }
#endif
    if (data->first) {
      switch (data->type) {
      case NSL_item_data:
	ECFF(FreeItem((NSL_Item *) data->first));
	data->first=NULL;
	break;
      case NSL_pi_data:
      case NSL_comment_data:
      case NSL_text_data:
      case NSL_cdata_data:
      case NSL_eref_data:
	ECFF(sfree((char*)data->first));
	data->first=NULL;
	break;
      default:
	SHOULDNT;
	return FALSE;
      }
    }
    if (data->next) {
      ECFF(FreeData(data->next, doctype));
    }
#ifndef NOMEMDEBUG
    data->type=NSL_free_data;
#endif
    return Ufree(doctype->datastack, data);
  }
  return TRUE;
}

boolean FreeAttr(NSL_Attr *attr, const NSL_Item *item) {
  if (attr!=NULL) {
    if (attr->value.string) {
      ECFF(sfree((char*)attr->value.string));
    }
    ECFF(FreeAttr(attr->next, item));
    return Ufree(item->doctype->attrstack, attr);
  }
  return TRUE;
}


/* Free the space occupied by a doctype                   */
/* once you have called this function - then you          */
/* should not use any items, bits, or datas, or NSL files */
/* that refer to this doctype                             */

boolean FreeDdb(const DDBHeader *ddb);

static boolean FreeAttrSum(AttributeSummary *atSum) {
  if (atSum->defaultPtr) {
    ECFF(sfree((char*)(((Char*)atSum)+atSum->defaultPtr)));
  };
  if (atSum->allowedValuesPtr) {
    ECFF(sfree((char*)(((Char*)atSum)+atSum->allowedValuesPtr)));
  };
  return 1;
}

static boolean FreeElementAttrs(RHTEntry* entry,const Char* name,
				void *dtp) {
  
  NSL_Doctype_I *doctype=(NSL_Doctype_I *)dtp;
  const OffboardAttrs *oa;
  NSL_ElementSummary_I *eltPtr;
  ASPtr *asp;
  AttributeSummary *atSum;
  int na,i;
  eltPtr=(NSL_ElementSummary_I*)(doctype->permanentBase+entry->eval);
  if (eltPtr->numAttr<0) {
    /* if numAttr is <0, it's an inverted index offset by -1 and there
       are offboard att sums */
    oa=doctype->offAttrsBase+(-1-eltPtr->numAttr);
    na=oa->oldNumAttr;
    for (asp=oa->asp;asp;asp=asp->next) {
      ECFF(FreeAttrSum((AttributeSummary*)asp->as));
    };
  }
  else {
    na=eltPtr->numAttr;
  };
  if (na>0) {
    atSum=(AttributeSummary*)(eltPtr+1);
    for (i=0;i<na;i++) {
      ECFF(FreeAttrSum(atSum+i));
    };
  };
  return 1;
}

boolean FreeDoctype(NSL_Doctype_I *doctype){
  if( doctype ){
    ECFF(FreeDdb(doctype->ddb));
    ECFF(sfree((char *)doctype->doctypeStatement));
    FreeDtd(doctype->rxp_dtd);

    FreeUmalloc(doctype->itemstack);
    FreeUmalloc(doctype->datastack);
    FreeUmalloc(doctype->attrstack);

    if(doctype->root_entity) /* NB null if doctype came from DoctypeFromDDB */
    {
	/* Don't free strings passed in to OpenString */
	doctype->root_entity->text = 0;
	FreeEntity(doctype->root_entity);
    }
    if (doctype->XMLMode) {
      char *eltBse,*nextEB;
      /* free locally allocated stuff */
      ECFF(sfree((char*)doctype->attrNames));
      /* Map over all element declarations freeing attr strings various  */
      ECFF(rmaphash(FreeElementAttrs,doctype->elements,
		    (void*)doctype));
      /* first cell of elt table may be pointer to older table */
      for (eltBse=(char*)doctype->elementBase;eltBse;eltBse=nextEB) {
	nextEB=*((char**)eltBse);
	ECFF(sfree(eltBse));
      };
      ECFF(sfree((char*)doctype->elements));
      ECFF(sfree((char*)doctype->offAttrsBase));
    };
    /* If we called DoctypeFromDdb, then we allocated doctype->ddbfile,
       and should free it here. However, if the doctype was obtained,
       not from the input file PI, but from the -d command line
       option, then we didnt allocate this and so can't free it
       here. Ha!? */
    /* ECFF(sfree((char *)doctype->ddbfile)); :This was allocated in DoctypeFromDdb */
    ECFF(sfree(doctype));
  }
  return TRUE;
}

/* Free (unmap) the space allocated to the memory mapped DDB file */

boolean FreeDdb(const DDBHeader *ddb){
  if( ddb ){
    if( ddb->ddblength > 0 ){
      return smunmap((caddr_t)ddb,ddb->ddblength);
    } else {
      /* This should not happen with new .ddb files created by 1.4.6
         (Jan 97) but it may happen with 1.4.6 (1996 internal) DDB
         files. */
      LT_ERROR(LEDDB,"DDB file is an out of date version. \
Delete it and run mknsg again.\n");
      return FALSE;
    }
  } else {
    return TRUE;
  }
}

boolean stackGrow(Stack *stack) {
  void* *p;
  size_t len,oldSize;
  len=stack->end-stack->base;
  oldSize=sizeof(void*)*len;
  ECNF(p=salloc(2*oldSize));
  memcpy(p,stack->base,oldSize);
  ECFF(sfree(stack->base));
  stack->base=p;
  stack->current=stack->base+len;
  stack->end=stack->base+(2*len);
  return TRUE;
}

/* =============== */
void ShowItem(NSL_Item *item);
void ShowItemInContext(NSL_Item *item);
static void ShowItemInternal(NSL_Item *item, NSL_Item *markedItem,int depth);
static void ShowChildren(NSL_Item *item, NSL_Item *markedItem, int depth);
static void ShowData(NSL_Data *data, NSL_Item *parent, NSL_Item *markedItem, int depth);

/* Find the root of item and print entire tree from root, marking item
   when we see it */

void ShowItemInContext(NSL_Item *item){
  NSL_Item *root = item;
  /* Find root */
  while( root && root->in && root->in->in ){
    root = root->in->in;
  }
  Printf("\nShowItem item=%d %s root=%d %s\n",
	 (int)item, item->label,
	 (int)root, root->label);
  ShowItemInternal(root,item,0);
}

/* Print entire tree at item */

void ShowItem(NSL_Item *item){
  ShowItemInternal(item,NULL,0);
}

static void ShowItemInternal(NSL_Item *item, NSL_Item *markedItem, int depth){
  int i;

  if( item == markedItem ){
    for(i=0;i<depth;i++){ putchar(' '); }
    Printf("<<<MARKED\n");
  }
  for(i=0;i<depth;i++){ putchar(' '); }
  Printf("ITEM: %s\n",item->label);
  ShowChildren(item,markedItem,depth+2);
  if( item == markedItem ){
    for(i=0;i<depth;i++){ putchar(' '); }
    Printf("MARKED>>>\n");
  }
}

static void ShowChildren(NSL_Item *item, NSL_Item *markedItem, int depth){
  NSL_Data *dptr;
  for( dptr=item->data; dptr; dptr=dptr->next){
    ShowData(dptr,item, markedItem,depth);
  }
}

static void ShowData(NSL_Data *data, NSL_Item *parent, NSL_Item *markedItem, int depth){
  int i;

  if( data->in != parent ){
    for(i=0;i<depth;i++){ putchar(' '); }
    Printf("!!! Dud back pointer\n");
  }
  for(i=0;i<depth;i++){ putchar(' '); }
  switch(data->type) {
  case NSL_text_data:
    Printf("DATA: '%s'\n",(char *)data->first);
    break;
  case NSL_item_data:
    Printf("DATA: (ITEM)\n");
    ShowItemInternal((NSL_Item*)data->first,markedItem,depth);
    break;
  case NSL_pi_data:
    Printf("DATA: (PI) '%s'\n",(char *)data->first);
    break;
  case NSL_cdata_data:
    Printf("DATA: (CDATA) '%s'\n",(char *)data->first);
    break;
  case NSL_eref_data:
    Printf("DATA: (EREF) '%s'\n",(char *)data->first);
    break;
  case NSL_comment_data:
    Printf("DATA: (COMMENT) '%s'\n",(char *)data->first);
    break;
  case NSL_free_data:
    Printf("DATA: (!!! NSL_free_data)\n");
    break;
  case NSL_undefined:
    Printf("DATA: (!!! NSL_undefined)\n");
    break;
  }
}

/* ========================= */

NSL_Item *CopyItem(const NSL_Item *item) {
  NSL_Item *newitem;
  char *ptrold, *ptrnew;
  int n,i;

  n=sizeof(NSL_Item);
  /*printf("CopyItem %s ",item->label);*/
  ECNN(newitem=AllocItem(item->doctype));
  for (ptrold=(char *)item, ptrnew=(char *)newitem, i=0;
       i<n;
       i++, ptrold++, ptrnew++) {
    *ptrnew=*ptrold;
  }
  newitem->in=NULL;
  if (item->attr) {
    ECNN(newitem->attr=CopyAttr(item->attr, newitem));
  }
  else {
    newitem->attr=NULL;
  }
  if (item->data) {
    ECNN(newitem->data=CopyData(item->data, newitem));
  }
  else {
    newitem->data=NULL;
  }
  newitem->nsowned = 0;
  return newitem;
}

NSL_Data *CopyData(const NSL_Data *data, const NSL_Item *item) {
  NSL_Data *datap;

  if (data==NULL) {
    return NULL;
  }

  ECNN(datap=NewNullNSLData(item->doctype));
  datap->ref=data->ref; /* ?? */
  datap->type=data->type;

  if ((void *)data->first) {
    switch (data->type) {
    case NSL_item_data:
      ECNN(datap->first=(void*)CopyItem((NSL_Item *) data->first));
      ((NSL_Item *)datap->first)->in=datap;
      break;
    case NSL_pi_data:
    case NSL_comment_data:
    case NSL_text_data:
    case NSL_cdata_data:
    case NSL_eref_data:
      ECNN(datap->first=Strdup(data->first));
      break;
    default:
      datap->first=NULL;
      break;
    }
  }
  datap->in=(NSL_Item *)item;
  if (data->next) {
    ECNN(datap->next=CopyData(data->next, item));
  }
  return datap;
}
	

NSL_Attr *CopyAttr(const NSL_Attr *attr, const NSL_Item *item) {
  NSL_Attr *attrp;

  CCOMMENT("Copying some Attributes\n");

  if (attr==NULL) {
    return NULL;
  }

  ECNN(attrp=AllocAttr(item->doctype));
  attrp->valuetype=attr->valuetype;
  attrp->deft=attr->deft;
  attrp->name=attr->name;

  ECNN(attrp->value.string=Strdup(attr->value.string));

  /* Recursive copy of the next field */
  attrp->next=CopyAttr(attr->next, item);
  return attrp;
}

const Char *LookupPrefix(const NSL_Item *item, const Char *prefix)
{
    NamespaceBinding n;

    for(n=item->ns_dict; n; n=n->parent)
    {
	if(!prefix)
	{
	    if(!n->prefix)
		return n->namespace ? n->namespace->nsname : 0;
	}
	else
	{
	    if(n->prefix && Strcmp(prefix, n->prefix) == 0)
		return n->namespace ? n->namespace->nsname : 0;
	}
    }
    return 0;
}
