/* Functions salloc,srealloc, sfree, sstrdup for Memory allocation/deallocation */

#include "lt-defs.h"
#include "lt-memory.h"
#include "lt-comment.h"

void *salloc(unsigned x) {
  char *pointer;

  if(x==0) {
    REPORT("Allocating zero bytes \n");
  }
	    
  COMMENT1("Allocating %u bytes\n",x);
  if((pointer=malloc(x))==NULL && x>0) {
    LT_ERROR1(LEMALE,"Memory Allocation Error(%d). Fatal\n",x);
  }
  return pointer;
}

void *srealloc(void *ptr, unsigned x) {
  void *pointer;

  /* This is for old systems like SunOS 4 the don't handle realloc(0) */
  if(!ptr)
      return salloc(x);

  if((pointer=realloc(ptr, x))==NULL) {
    LT_ERROR1(LEMALE,"Reallocation error --- trying to reallocate %d bytes",
	   x);
  }
  return pointer;
}

/* This is never used

#define RCMP(ptr, value, rval) {if(strcmp((ptr), (value))==0) return (rval);}

int syssizeof(char *type) {
    
  if(type[strlen(type)-1]=='*')
    return sizeof(void *);
    
  RCMP(type,"char", sizeof(char));
  RCMP(type,"float", sizeof(float));
  RCMP(type,"int",sizeof(int));
  RCMP(type,"UBYTE",sizeof(unsigned char));
  RCMP(type,"double",sizeof(double));
  RCMP(type,"long int",sizeof(long int));

  return sizeof(void *);
}
*/

boolean sfree(void *ptr) {

  /* This is for old systems like SunOS 4 the don't handle free(0) */
  if(!ptr)
      return TRUE;

#ifdef FREE_VOID 
  /* no return value */
  free(ptr);
  return TRUE;
#else
  if (free(ptr)) {
    return TRUE;
  } else {
    LT_ERROR(LEFREE,"Couldn't free!\n");
    return FALSE;
  }
#endif
}
