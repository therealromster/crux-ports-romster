#include <stdio.h>
#include "lt-comment.h"
#include "lt-memory.h"
#include "string16.h"

#define EOTOK -5

/* Function templates for this file */

int readtok(FILE *filep, char *sepstr, char *result, int maxlen);
char *load_text(FILE* fp);

/*
 * readtok is like strtok, but for files. It reads a token
 * If EOF is encountered before the 
 */
int readtok(FILE *filep, char *sepstr, char *result, int maxlen)
{
    int i, val=0;
    unsigned long septab[8]; /* This must have *at least* 32 bits */

    for(i=0; i<8; i++)
	septab[i]=0;
    for(;*sepstr!=0;sepstr++)
	septab[(int)*sepstr/32]|=1<<((int)*sepstr)%32;
	
	
    *result=0;
    for(i=0; (val!=EOTOK) && (i<maxlen); i++)
    {
	val=getc(filep);
	if(val==EOF)
	{
	    i++;
	    break;
	}
	if(septab[(val>>5)&7] & (1<<(val&31)))
	    val=EOTOK;
	
	result[i]=(char)val;
    }
    result[i-1]=0; 

    for(; val==EOTOK ;)
    {
	val=getc(filep);
	if(val==EOF)
	    break;
	if(septab[(val>>5)&7] & (1<<(val&31)))
	    val=EOTOK;
    }
   
    ungetc((char)val, filep);

    if(val==EOF && *result==0)
	return EOF;
    else return EOTOK;
}


#define STEP_LINES 1024
char *load_text(FILE* fp)
{ 
      long length=0;
      char*  buf;
      char** buffer;
      char*  in_data;
      char* in_data_ptr;
      int num_of_lines;
      int alloc_lines;
      int i;

      alloc_lines=STEP_LINES;
      ECNN(buffer = (char **)salloc(alloc_lines*sizeof(char*)));
      buf    = (char *) salloc(1024*sizeof(char));
      if(buf==NULL) { free(buffer); return NULL;}
  
      length=0;
      num_of_lines=0;
      while(fgets(buf, 1024, fp)!=NULL)
      {
          /*strcat(buf,"\n");*/ 
          length += strlen(buf);
          ECNN(buffer[num_of_lines++] = strdup8(buf));
          if(num_of_lines < alloc_lines-2) continue;
          alloc_lines += STEP_LINES;
          ECNN(buffer=(char **)srealloc((char*)buffer,
					alloc_lines*sizeof(char*)));
      }
      buffer[num_of_lines]=NULL;
   
      ECNN(in_data = (char *)salloc(length+2));
      in_data[0]='\0';
      in_data_ptr = in_data;
      for(i=0; buffer[i] != NULL; i++) 
      {
           char *bb = buffer[i]; 
           while(*bb!='\0')  { *in_data_ptr=*bb; in_data_ptr++;  bb++; } 
           free( buffer[i] ); 
      }  
     *in_data_ptr='\0';

      ECFN(sfree(buffer));
      ECFN(sfree(buf));

      return in_data;
}
