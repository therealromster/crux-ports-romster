/* 	$Id: hash.c,v 1.17 1999/02/17 13:08:44 richard Exp $	 */

#ifndef lint
static char vcid[] = "$Id: hash.c,v 1.17 1999/02/17 13:08:44 richard Exp $";
#endif /* lint */

#include <stdio.h>
#include "lt-defs.h"
#include "string16.h"
#include "lt-hash.h"
#include "lt-memory.h"
#include "lt-comment.h"

#ifndef HASHTABLESIZE
    #define HASHTABLESIZE 3000
#endif

/*---------------------------------------------------------*/
/*----------- INTERNAL INTERFACE DECLARATION --------------*/
const HashList* GetEndOfList(const HashList *list);
const HashList* GetFreeListEl(const HashList *list);
HashList* FindWordInList(const HashList *list, const Char *word, int length);
int CalcHashNum(const HashTab *hash, const Char *word, int length);
HashList* NewNullHashList( void );


/*---------------------------------------------------------*/
/*--------   PUBLIC INTERFACE IMPLEMENTATION -------------*/

/*---------------------------------------------------------*/
HashTab *NewHashStruct( void ) { return NewSizedHashStruct( HASHTABLESIZE ); }

/*---------------------------------------------------------*/
HashTab *NewSizedHashStruct(int n)
{
    int i;
    HashTab *hash;

    ECNN(hash=tsalloc(HashTab,1));
    hash->size=n;
    ECNN(hash->table=tsalloc(HashList *,hash->size));
    for(i=0;i<hash->size;i++) hash->table[i]=NULL;
    hash->n_items=0;

    return hash;
}

HashTab *rehash(HashTab *hash)
{
    HashList **newtable, **oldtable = hash->table, *ptr, *nptr;
    int i, h, oldsize = hash->size, newsize = oldsize * 2;
    
    ECNN(newtable=tsalloc(HashList *, newsize));
    for(i=0;i<newsize;i++) newtable[i]=NULL;
    hash->size = newsize;
    hash->table = newtable;

    h = 0;			/* In case we move an empty item */
    for(i=0; i<oldsize; i++)
	for(ptr=oldtable[i]; ptr; ptr=nptr)
    {
	nptr = ptr->next;
	if(ptr->word)
	    h = CalcHashNum(hash, ptr->word, ptr->length);
	/* else use the same as last time */
	ptr->next = newtable[h];
	newtable[h] = ptr;
    }

    sfree(oldtable);

    return hash;
}

/*---------------------------------------------------------*/
int FreeHashStruct( HashTab *hash )
{
    return FreeHashStructM(hash, 0);
}

/* This version frees the word (key) memory */
int FreeHashStructM( HashTab *hash, boolean free_values )
{
    int i=0;
    const HashList  *next_el;
    HashList  *el;
    while(i < hash->size)
    {
       next_el=hash->table[i];
       while(next_el!=NULL) 
	 {el = (HashList *)next_el;  next_el=el->next;
	  if(free_values) {ECFF(sfree((Char *)el->word));} ECFF(sfree(el));}
       i++;
    }

    ECFF(sfree(hash->table));
    ECFF(sfree(hash));
    return 1;
}

/*---------------------------------------------------------*/ 
void  FreeHashListEl(HashTab *hash,HashList* hle)  
{
    if (hle->word) {
      hash->n_items--;
    };
    hle->word =NULL; hle->length=0;	
}  

/*--------------------------------------------------------*/
/* Assumes a null terminated string */
HashList *FindWordInTable(const HashTab *hash,const Char *word) {
  return FindWordInTableX(hash,word,Strlen(word));
}

/*---------------------------------------------------------*/
HashList* FindWordInTableX(const HashTab *hash, const Char *word, int length)
{
    int k;
    HashList *ptr=NULL;

    ECNN(word);
    k=CalcHashNum(hash, word, length);
    if(hash->table[k]) ptr=FindWordInList(hash->table[k],word,length);   
    return ptr;
}

/* Assumes a null terminated string */
HashList *AddWordToTable(HashTab *hash,const Char *word) {
  return AddWordToTableX(hash,word,Strlen(word));
}

/*---------------------------------------------------------*/
/*
 * Add a word to the hash table. The word's memory is NOT copied, so the
 * word must reside in aquirable memory.
 */
HashList *AddWordToTableX(HashTab *hash, const Char *word, int length)
{
    int i;
    HashList *ptr;

    ECNN(word);
    i=CalcHashNum(hash, word, length);
    if(hash->table[i]!=NULL)
    {
        ptr=(HashList *)GetFreeListEl(hash->table[i]); 
        if(ptr->word!=NULL)   /*----- end of list */
	{
	   ECNN(ptr->next=(void*)NewNullHashList( ));
	   ptr=(HashList *)ptr->next;
	}
    }
    else ECNN(ptr=hash->table[i]=NewNullHashList());
    ptr->word=word;
    ptr->length=length;
    hash->n_items++;
    if(hash->n_items > hash->size)
    {
	ECNN(rehash(hash));
    }

    return ptr;
}

/* This version does copy the memory */

HashList *AddWordToTableXM(HashTab *hash, const Char *word, int length)
{
    Char *t;
    ECNN(t = tsalloc(Char, length));
    memcpy(t, word, length * sizeof(Char));
    return AddWordToTableX(hash, t, length);
}

/* Lookup word in hash, length must be the character length of the word */

HashList *WordEntryInTableX(HashTab *hash,const Char *word,int length) {
  int i;
  HashList *ptr,*list;

  ECNN(word);
  i=CalcHashNum(hash, word, length);
  if(hash->table[i]!=NULL) {
    for(ptr=NULL,list=(HashList*)hash->table[i];
	list;
	list=(HashList*)list->next) {
      if((length==list->length) && !Strncmp(list->word, word, length)) {
	return list;
      };
      ptr=list;
    };
    ECNN(list=NewNullHashList());
    list->word=word;
    list->length=length;
    hash->n_items++;
    ptr->next=list;
    if(hash->n_items > hash->size)
    {
	ECNN(rehash(hash));
    }
    return list;
  }
  else {
    ECNN(ptr=hash->table[i]=NewNullHashList( ));
    ptr->word=word;
    ptr->length=length;
    hash->n_items++;
    if(hash->n_items > hash->size)
    {
	ECNN(rehash(hash));
    }

    return ptr;
  };
}
/*---------------------------------------------------------*/
HashTab *HashNLabels(int n, const Char **list)
{
    int i;
    HashTab *tab;

    ECNN(tab=NewHashStruct());
    for(i=0;i<n;i++) ECNN(AddWordToTable(tab, list[i]));
    return tab;
}

/*---------------------------------------------------------*/
/*--------  INTERNAL INTERFACE IMPLEMENTATION -------------*/


/*---------------------------------------------------------*/
const HashList* GetFreeListEl(const HashList *list)
{
    const HashList* tmp_list;  /* so list can be const */

    for(tmp_list = list; tmp_list->next!=NULL;  tmp_list= tmp_list->next) 
                if( tmp_list->word==NULL ) return tmp_list;  /*-- free el in list */

    return tmp_list;
}

/*---------------------------------------------------------*/
HashList* FindWordInList(const HashList *list, const Char *word, int length)
{
    HashList* tmp_list;  /* so list can be const */
    ECNN(list);
    for(tmp_list = (HashList* )list; tmp_list!=NULL; tmp_list=(HashList* )tmp_list->next)
	if(tmp_list->word && tmp_list->length == length && !Strncmp(tmp_list->word, word, length))  return tmp_list;   
    return (HashList *)NULL;
}

/*---------------------------------------------------------*/
int CalcHashNum(const HashTab *hash, const Char *word, int length)
{
#if 0
    /* For 16-bit chars, this is the worst hash function possible */
    int i;
    unsigned int seed;
    char8 *p = (char8 *)word;

    length *= sizeof(Char);
    for(i=0, seed=p[0]*985626451; i < length; i++)
                           seed *= p[i]*0x00800101; 
    return seed%(hash->size);
#else
    /* This is Chris Torek's hash function, as used in rhash.c */
    unsigned long h = 0;

    for (; length > 0; length--) {
	h = (h << 5) + h + *word++;
    };

    return h % hash->size;
#endif
}

/*---------------------------------------------------------*/
HashList* NewNullHashList( void )
{
    HashList *new;
    ECNN(new=(HashList *)salloc(sizeof(HashList))); 

    new->word=NULL;
    new->next=NULL;
    new->length=0;
    new->index=0;

    return new;
}


/*---------------------------------------------------------*/
const HashList* GetEndOfList(const HashList *list)
{
    const HashList* tmp_list;  /* so list can be const */

    for(tmp_list = list; tmp_list->next!=NULL; tmp_list= tmp_list->next) ;	
    return tmp_list;
}

boolean MapHashLists(HashTab *hash,boolean(*fn)(const HashList*)) {
  int i;
  const HashList *ptr;
  for (i=hash->size-1;i>-1;i--) {
    for (ptr=hash->table[i];ptr;ptr=ptr->next) {
      ECFF(fn(ptr));
    };
  };
  return TRUE;
}

boolean MapHashLists1(HashTab *hash,boolean(*fn)(const HashList*, void*),
		      void *arg) {
  int i;
  const HashList *ptr;
  for (i=hash->size-1;i>-1;i--) {
    for (ptr=hash->table[i];ptr;ptr=ptr->next) {
      ECFF(fn(ptr, arg));
    };
  };
  return TRUE;
}
