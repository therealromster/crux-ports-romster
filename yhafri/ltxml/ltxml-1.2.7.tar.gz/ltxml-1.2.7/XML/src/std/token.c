/* tokenise an XXX ISO LATIN-1 stream to integers, moderately table-driven */

/* XXX this doesn't work for 16-bit chars. */

#include "lt-defs.h"
#if CHAR_SIZE==8
#include <stdio.h>
#include <fcntl.h>
#include "charset.h"
#ifdef macintosh
#include <unistd.h>
#else
#if defined(WIN32) && ! defined(__CYGWIN__)
#include <io.h>
#else
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/mman.h>
#endif
#endif

#include <stdlib.h>
#include "lt-safe.h"
#include "lt-hash.h"
#include "lt-token.h"
#include "lt-comment.h"
#include "string16.h"

/* Function prototypes defined in this file */

unsigned char* fillbuf(int fd);
unsigned char* initbuf(const unsigned char* fixed);
boolean token(const unsigned char* start, const unsigned char* end);
boolean stok(const unsigned char* start, const unsigned char* end);
boolean bktok(const unsigned char* ptr);
int ginf(const char* filename);
int eol(int breakeol);

boolean NewEntry(HashList *entry);

/*    */

int syntax[]={
/* ^@    ^A    ^B    ^C    ^D    ^E    ^F    ^G   */
  BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* ^H    TAB LF  VT  FF  CR  ^N    ^O   */
  BREAK,SEP,EOL,SEP,SEP,EOL,BREAK,BREAK,
/* ^P    ^Q     ^R    ^S    ^T    ^U    ^V    ^W  */
  BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* ^X    ^Y     ^Z    ^[    ^\    ^]    ^^    ^_  */
  BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* 40 SP 41  ! 42  " 43  # 44 $  45 %  46 &  47 ' */
  SEP,   BREAK,BREAK,ENTN ,BREAK,BREAK,ENTO ,BREAK,
/* 50  ( 51  ) 52  * 53  + 54  , 55  - 56  . 57  / */
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* 60  0 61  1 62  2 63  3 64  4 65  5 66  6 67  7 */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 70  8 71  9 72  : 73  ; 74  < 75  = 76  > 77  ? */
   ORD,  ORD,  BREAK,ENTE ,TAGO ,BREAK,BREAK,BREAK,
/* 100 @ 101 A 102 B 103 C 104 D 105 E 106 F 107 G */
   BREAK,ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 110 H 111 I 112 J 113 K 114 L 115 M 116 N 117 O */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 120 P 121 Q 122 R 123 S 124 T 125 U 126 V 127 W */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 130 X 131 Y 132 Z 133 [ 134 \ 135 ] 136 ^ 137 _ */
   ORD,  ORD,  ORD,  BREAK,BREAK,BREAK,BREAK,BREAK,
/* 140 ` 141 a 142 b 143 c 144 d 145 e 146 f 147 g */
   BREAK,ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 150 h 151 i 152 j 153 k 154 l 155 m 156 n 157 o */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 160 p 161 q 162 r 163 s 164 t 165 u 166 v 167 w */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 170 x 171 y 172 z 173 { 174 | 175 } 176 ~ 177 DEL */
   ORD,  ORD,  ORD,  BREAK,BREAK,BREAK,BREAK,BREAK,
/* 200--237 */
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* NBSP, 241--277 all diacritics/special chars */
   SEP,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
   BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,BREAK,
/* 300--317 accented capitals */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 320--326 accented capital, multiplication X */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,BREAK,
/* 330--337 accented capitals, sharf S */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 340--357 accented lower case */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,
/* 360--366 accented lower case, divide sign */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,BREAK,
/* 370--377 accented lower case */
   ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD,  ORD
};

unsigned char downcase[256];

#define BUFSIZE 1024
unsigned char buf[3*BUFSIZE];
unsigned char *nbuf,*bbuf,*lastbyte,*eob,*prevlast,*bufbreak;
int fileempty;
int code,max,*tt;

char btags[100],etags[100],seprChar;
const char *rends=0;
HashTab* hash;
int ntokens,sgmltag,nseps;

unsigned char* fillbuf(int fd) {
  int n;
  unsigned char *ptr;
  if (fileempty) {
    prevlast=lastbyte;
    return 0;
  } else {
    ECEN(n=sread(fd,(char *)nbuf,BUFSIZE));
    if (!n) {
      /* already empty */
      lastbyte=nbuf;
      fileempty=1;
      return nbuf;
    }

    ptr=nbuf;
    nbuf=(nbuf==bbuf)?bufbreak:bbuf;
    if (n!=BUFSIZE) {
      /* eof in there somewhere */
      fileempty=1;
    }
    lastbyte=ptr+n;
    return ptr;
  };
}

unsigned char* initbuf(const unsigned char* fixed) {
  if (fixed) {
    nbuf=bbuf=(unsigned char*)fixed;
    lastbyte=eob=(unsigned char*)fixed+strlen((const char *)fixed);
    fileempty=1;
    return (unsigned char*)fixed;
  } else {
    nbuf=bbuf=&buf[0];
    bufbreak=bbuf+BUFSIZE;
    eob=bbuf+(2*BUFSIZE);
    lastbyte=eob;
    fileempty=0;
    return lastbyte;
  }
}

int eol(int breakeol) {
  return sputw(breakeol,stdout);
}

FILE* dict_file;
int str_file;
unsigned char *str_ptr,*str_base;
int str_index=0;


#ifndef PROT_READ
#define PROT_READ 0
#define PROT_WRITE 1
#endif
#ifndef MAP_PRIVATE
#define MAP_PRIVATE 0
#define MAP_SHARED 1
#endif

boolean InitDict(const char* out_fileroot,
		 const char* prev_fileroot,HashTab* hsh) {
  char str[100];
  int ts_file,tt_file,ec;
  unsigned char *ts=0;
  int ptr,smax=0,ttlen;

  /* #ifdef NO_MAPMEM
    LT_ERROR1(LEFILE,"Memory mapping not supported. file: %s\n",out_fileroot);
    return FALSE;
    #else */

  hash=hsh;
  
  if (prev_fileroot) {
    /* We are starting from a previous table.
       First copy the files if necessary */
    if (out_fileroot) {
      sprintf(str,"cp %s.tt %s.tt",prev_fileroot,out_fileroot);
      if ((ec=system(str))) {
	WARN2(LESYSE,"%s failed %x\n",str,ec);
      }
      sprintf(str,"cp %s.ts %s.ts",prev_fileroot,out_fileroot);
      if ((ec=system(str))) {
	WARN2(LESYSE,"%s failed %x\n",str,ec);
      }
    }
    /* Now load up the hash table */
    sprintf(str,"%s.tt",prev_fileroot);
    ECEF(tt_file=s_open(str,O_RDONLY,0));
    ECEF(ttlen=file_len(tt_file));
    max=(ttlen/4)-1;
    ECNF(tt=smmap(0,ttlen,PROT_READ,MAP_PRIVATE,tt_file,0,str));
    sprintf(str,"%s.ts",out_fileroot?out_fileroot:prev_fileroot);
    ECEF(ts_file=s_open(str,out_fileroot?O_RDWR:O_RDONLY, 0));
    ECEF(smax=file_len(ts_file));
    if (out_fileroot) {
      ECEF(slseek(ts_file,STRBLKSIZE,SEEK_CUR,str));
      write(ts_file,(char *) &ts_file,1); /* in case it was empty */
      ECNF(ts=smmap(0,STRBLKSIZE,PROT_READ | PROT_WRITE,
		   MAP_SHARED,ts_file,0,str));
    } else {
      ECNF(ts=smmap(0,STRBLKSIZE,PROT_READ,MAP_PRIVATE,ts_file,0,str));
    }
    if (out_fileroot) {
      for (ptr=256;ptr<max;ptr++) {
	AddWordToTableX(hash,
			(char8 *)ts+(tt[ptr]),
			tt[ptr+1]-tt[ptr])->index=(void *)ptr;
      }
      AddWordToTableX(hash,(char8 *)ts+(tt[max]),smax-tt[max])->index = 
	  (void *)max;
      code=max;
      ECFF(smunmap((caddr_t) tt,ttlen));
      close(tt_file);
    }
  }
  if (out_fileroot) {
    sprintf(str,"%s.tt",out_fileroot);
    ECNF(dict_file=sfopen(str,"a"));
  }
  if (prev_fileroot) {
    str_base=ts;
    str_ptr=str_base+smax;
    str_index=smax;
    str_file=ts_file;
  } else {
    sprintf(str,"%s.ts",out_fileroot);
    ECEF(str_file=s_open(str,O_RDWR | O_CREAT,0777));
    ECEF(slseek(str_file,STRBLKSIZE,SEEK_CUR,str));
    write(str_file,(char *) &str_file,1); /* in case it was empty */
    ECNF(str_ptr=smmap(0,STRBLKSIZE, PROT_READ | PROT_WRITE,
			       MAP_SHARED, str_file, 0,str));
    str_base=str_ptr;
  /* initialise the dictionary with identity map for single character tokens */
    for (code=0;code<256;code++) {
      *(str_ptr++)=(unsigned char)code;
      str_index++;
      ECEF(sfwrite(&code,4,1,dict_file));
    }
    code--;
  }
  return TRUE;
  /* #endif */
}

boolean FinishDict(int adding) {
  /* #ifdef NO_MAPMEM
  LT_ERROR(LEFILE,"Memory mapping not supported. (FinishDict)\n");
  return FALSE;
  #else */
  ECFF(smunmap((caddr_t) str_base,STRBLKSIZE));
#ifdef HAVE_FTRUNCATE
  /* won't compile on Mac or Borland, no ftruncate */
  if (ftruncate(str_file,str_index)) {
    LT_ERROR1(LEFILE,"Couldn't truncate .ts file: %s",strErr());
    return FALSE;
  }
#else
  WARN(LEFILE,".ts file not truncated, be warned");
#endif
  if (adding && (code>max)) {
    WARN1(LEFILE,"Added %d new token types\n",code-max);
  }
  return TRUE;
  /* #endif */
}


boolean NewEntry(HashList *entry) {
  memcpy(str_ptr,entry->word,entry->length);
  entry->word=(char8 *)str_ptr;
  ECEF(sfwrite(&str_index,4,1,dict_file));
  str_ptr+=entry->length; /* should check for full!!! */
  str_index+=entry->length;
  entry->index=(void *)(++code);
  return TRUE;
}

boolean token(const unsigned char* start, const unsigned char* end) {
  int length;
  HashList *entry;
  if (hash) {
    if (start+1==end) {
      ECEF(sputw((int)*start,stdout));
    }
    else {
      if (end<start) {
	memcpy(eob,bbuf,end-nbuf);
	length=(eob-start)+(end-bbuf);
      }
      else {
	length=end-start;
      };
      if (!(entry=FindWordInTableX(hash,(char8 *)start,length))) {
	entry=AddWordToTableX(hash,(char8 *)start,length);
	ECFF(NewEntry(entry));
      };
      ECEF(sputw((int)entry->index,stdout));
    };
  }
  else {
    if (ntokens && seprChar) {
      ECEF(sputchar(seprChar));
    };
    if (sgmltag) {
      ECEF(sfprintf(stdout,btags,++ntokens));
      if (rends) {
	ECEF(sfprintf(stdout," REND=%s>",rends));
      }
      else {
	ECEF(sputchar('>'));
      };
    }
    if (end<start) {
      /* wrap-around */
      ECEF(sfwrite(start,1,eob-start,stdout));
      if (end>bbuf) {
	ECEF(sfwrite(bbuf,1,end-bbuf,stdout));
      };
    } else {
      ECEF(sfwrite(start,1,end-start,stdout));
    };
    if (sgmltag) {
      ECEF(sfprintf(stdout,etags));
    };
  };
  return TRUE;
}

boolean stok(const unsigned char* start, const unsigned char* end) {
  if (sgmltag) {
    if (ntokens==0) {
      /* first in file/string special */
      rends=nseps?"sep":0;
    }
    else {
      rends=nseps?0:"nosep";
    };
    nseps=0;
  };
  return token(start,end);
}

boolean bktok(const unsigned char* ptr) {
  if (sgmltag) {
    rends=nseps?"sep":0;
    nseps=0;
  };
  return token(ptr,ptr+1);
}

int ginf(const char* filename) {
  int res;
  if (strcmp(filename,"-")) {
    ECEF(res = s_open(filename,O_RDONLY, 0));
    return res;
  } else {
    return 0;			/* stdin -- is this right? */
  }
}

#define NEUTRAL 0
#define TOKEN 1
#define EOLS 2
#define SGML 3
#define ENTSTART 4
#define ENTITY 5

/* If NFILES < 0 then filenames is a pointer to a string */
/*        Otherwise a pointer to a list of file names    */
/* SGMLTG is a string containing the name of an SGML tag */
/*        (with optional attributes)                     */

int tokenise(const unsigned char **filenames,int nfiles,
	     int breakeol,int down,const unsigned char* sgmltg,unsigned char seprChr) {
  int in_file=0,state=EOLS,synt,more=1,fileno=0;
  unsigned char *ptr,*bos=0;
  const unsigned char* filename;

  if (sgmltg) {
    sgmltag=1;
    sprintf(btags,"<%s",sgmltg);
    sprintf(etags,"</%s>",sgmltg);
    /* for end tag, cut after tag in case there are attributes */
    if ((ptr=(unsigned char *)strchr(etags, ' '))) {
      *ptr=(unsigned char)'>';
      *(++ptr)=(unsigned char)'\000';
    }
  } else {
    sgmltag=0;
  }
  nseps=ntokens=0;
  seprChar=seprChr;

  if (nfiles<0) {
    /* hack to allow tokenising a literal string */
    ptr=initbuf(*filenames);
  } else {
    in_file=ginf((const char *)(filename=filenames[fileno++]));
    ptr=initbuf(0);
  };

  do {
    if (ptr<lastbyte ||
	(ptr=fillbuf(in_file))) {
      if (down && (*ptr<256)) {
	  *ptr=downcase[(unsigned char)*ptr];
      }
      synt=(*ptr<256)?syntax[(unsigned char)*ptr]:BREAK;
    } else {
      while ((!ptr) && (fileno<nfiles)) {
	fileempty=0;
	in_file=ginf((const char *)(filename=filenames[fileno++]));
	ptr=fillbuf(in_file);
      }
      if (ptr) {
	if (down && (*ptr<256)) {
	    *ptr=downcase[(unsigned char)*ptr];
	}
	synt=(*ptr<256)?syntax[(unsigned char)*ptr]:BREAK;
	/* if we are in a token in the first buffer, probably need to
	   move it to end to join up */
	if (state==TOKEN && bos<ptr && prevlast!=(bufbreak)) {
	  bos=memcpy(bufbreak-(prevlast-bos),bos,prevlast-bos);
	}
      } else {
	more=0;
	ptr=lastbyte;
	synt=SEP;
      }
    }

  top:
    if (state==TOKEN) {
      switch (synt) {
      case ORD:
	continue;
      case ENTO:
	if (sgmltag) {
	  /* encorporate in current token. . .
	   probably wrong if numeric? */
	  state=ENTSTART;
	  continue;
	}
      default:
	stok(bos,ptr);
	bos=0;
	state=NEUTRAL;
      }
    }
    switch (state) {
    case SGML:
      ECEE(sputchar(*ptr));
      if (synt==EOL) {
	state=EOLS;
      }
      break;
    case ENTSTART:
      switch (synt) {
      case ORD:
      case ENTN:
	state=ENTITY;
	continue;
      }
    case ENTITY:
      switch (synt) {
      case ENTE:
	state=TOKEN;
	continue;
      case ORD:
	continue;
      default:
	/* break or eol or sep -- terminate entity and try again */
	state=TOKEN;
	goto top;
      }
    case EOLS:
      switch (synt) {
      case SEP:
	nseps+=1;
      case EOL:
	/* this is tricky -- no nseps, since we start in EOLS and lots of
	   text sequences in SGML start with \n . . . */
	continue;
      case TAGO:
	if (sgmltag) {
	  ECEE(sputchar(*ptr));
	  state=SGML;
	  continue;
	};
	/* otherwise fall through */
      default:
	state=NEUTRAL;
      }
    case NEUTRAL:
      switch (synt) {
      case SEP:
	nseps+=1;
	break;
      case EOL:
	nseps+=1;
	if (breakeol) {
	  eol(breakeol);
	}
	state=EOLS;
	break;
      case ORD:
	state=TOKEN;
	bos=ptr;
	break;
      case ENTO:
	if (sgmltag) {
	  if (!bos) {
	    bos=ptr;
	  }
	  state=ENTSTART;
	  continue;
	}
	/* otherwise treat as break */
      case TAGO: /* treated as break when not at BOL */
      case BREAK:
	bktok(ptr);
      }
    }
  } while (ptr++ && more);
  return ntokens;
}

int untokenise(const char* filename,int breakeol) {
  FILE* in;
  int wc,nbol=0;
  unsigned char *ptr,*eos;
  ECNE(in = sfopen(filename,"r"));
  while(fread(&wc, sizeof(wc), 1, in) != 0) {
    if (wc==breakeol) {
      ECEE(sputchar('\n'));
      nbol=0;
    }
    else {
      if (nbol) {
      ECEE(sputchar(' '));
      }
      else {
      nbol=1;
      };
      ptr=str_base+tt[wc];
      eos=wc<max?(str_base+tt[wc+1]):str_ptr;
      for (;ptr<eos;ptr++) {
      ECEE(sputchar(*ptr));
      };
    };
  };
  return ferror(in)?EOF:1;
}

int decodeToken(int wc,unsigned char* buf) {
  unsigned char *ptr,*eos;
  int len;
  ptr=str_base+tt[wc];
  eos=wc<max?(str_base+tt[wc+1]):str_ptr;
  len=eos-ptr;
  for (;ptr<eos;ptr++) {
    *(buf++)=*ptr;
  };
  return len;
}
#endif /*CHAR_SIZE==8*/
