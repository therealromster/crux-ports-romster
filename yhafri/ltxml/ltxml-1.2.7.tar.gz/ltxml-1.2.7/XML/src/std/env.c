#ifndef WIN32
#ifndef macintosh
/* Needed for dirent.h */
#include <sys/types.h>
#include <dirent.h>
#endif
#endif

#if defined(WIN32) && ! defined(__CYGWIN__)
#include <direct.h>
#endif

#include <string.h>

#include "lt-defs.h"
#include "lt-comment.h"
#include "lt-memory.h"
#include "lt-env.h"
#include "string16.h"

char **MakePath(char *envpath)
{
    char **path;
    char *dir;
    int i, ndirmalloced;
    int nmalloc=20;

    ECNN(path=tsalloc(char*, (ndirmalloced=nmalloc)));

    if(envpath!=NULL)
    {
	ECNN(envpath=strdup8(envpath));
	for(i=0,dir=strtok(envpath,":"); dir!=NULL; dir=strtok(NULL,":"))
	{
	    path[i]=dir;
	    if(++i>=ndirmalloced)
	    {
		ECNN(path=(char**)srealloc((char*)path, ndirmalloced+=nmalloc));
	    }
	}
	path[i]=NULL;
    }
    else  path[0]=NULL;
    return path;
}


char* getCurDir( void );
		    
char* getCurDir( ) {
#ifdef GETWD
  char *currentdir;
  ECNN(currentdir=salloc(MAXFILENAMELEN+1));
  GETWD(currentdir);
  return currentdir;
#else
  LT_ERROR(LEFILE,"Unable to supply cwd info on this architecture.\n");
  return 0;
#endif
}    

#if defined(__CYGWIN__) || ! defined(WIN32)
char *FindFilename(char *name, char **path)
{
    char *dir, *ptr, *filename;
    int i;
    DIR *directory;
    struct dirent *entry;

    ECNN(filename=salloc(MAXFILENAMELEN+1));

    if((ptr = strchr8(name,'/')) != NULL) { /* relative or absolute path given ? */
      if(ptr == name) {
	strcpy8(filename,name); /* absolute path */
      }
      else {
        ECNN(ptr = getCurDir( ));
        strcpy8(filename,ptr);
        ECFN(sfree(ptr));
        strcat8(filename,"/");
        strcat8(filename,name);
      };
    }
 
    else
    {
	for(i=0, dir=path[0]; dir!=NULL; i++, dir=path[i])
	{
	    directory=opendir(dir);
	    if(directory!=NULL)
	    {
		for(entry=readdir(directory); entry!=NULL; 
		    entry=readdir(directory))
		    if(strcmp8(entry->d_name, name)==0)
		    {
			filename=strcpy8(filename,dir);
			if(filename[strlen8(filename)-1]!='/')
			{
			    filename[strlen8(filename)+1]=0;
			    filename[strlen8(filename)]='/';
			}
			strcat8(filename, name);
			closedir(directory);
			return filename;
		    }
		closedir(directory);
	    }
	}
    }
    return NULL;
}
#endif /* WIN32 */

#include <limits.h>
#ifndef PATH_MAX
#define PATH_MAX 1024
#endif

/*
I hope this never gets called on  the Mac, because if it is called the results
will be nonsense. So I am making it return 0 fast
*/

int get_process_dir(const char *cmd, char** dir, char** name)
{
  char *path;	/* Guaranteed to be long enough + NUL */
  char *buf;
  char *currentdir, *p, *p2;
  #ifdef macintosh
  return 0;
  #endif

  if (! strlen8(cmd)) { *dir=NULL; *name=NULL; return 0; }

  ECNF (buf = salloc(MAXFILENAMELEN+1) );
  ECNF (path= salloc(MAXFILENAMELEN+1) );
 
  path[0] = '\0';
 

  if ((p = strchr8(cmd,'/')) != NULL) {	/* relative or absolute path given ? */
    if (p == cmd)
      strcpy8(path,cmd);		/* absolute path */
    else {
      ECNF (currentdir = getcwd(NULL,PATH_MAX) ) ;
      strcpy8(path,currentdir);
      strcat8(path,"/");

      if (cmd[0] == '.' && cmd[1] == '/')
	strcat8(path,cmd+2);	/* Normalise ./command */
      else
	  strcat8(path,cmd);	/* Can't be bothered removing all ../../.. */
    }
  } else
    /*    search through path until find name */
    for (p=getenv("PATH"); p!=NULL && (p = strchr8(p,':'))!=NULL; ) {
      p++;
      strcpy8(buf,p);
      if ((p2 = strchr8(buf,':')) != NULL)
	*p2='\0';
      strcat8(buf,"/");
      strcat8(buf,cmd);
#ifdef macintosh
      if(1) {
	WARN(NEUNSUP,"need to emulate access call for Macintosh");
	strcpy8(path,buf);
	break;
      }
#else
      if (!access(buf,X_OK)) {
	strcpy8(path,buf);
	break;
      }
#endif
    }

  if (!*path) { *name=NULL; *dir=NULL; return 0; }
 
  else{  /*---------- my finish ----------*/

    int len, pos, i;

    len = strlen8(path);

    for(pos=-1, i=len-1; i>=0; i--) 
         if(path[i]=='/') { pos=i; break; }

    *name = strdup8( path+pos+1);
     path[pos]='\0';
    *dir = strdup8( path);
  }
  free(buf); free(path);
  return 1;
}
 

#ifdef HAVE_POPEN
/* If we don't have popen(), as say on Borland C, then we dont support
   this function. That seems to be enough to keep Andrei happy for now */

FILE* open_abs_names(const char*  fn)
{ 
    FILE* fi;  
    char* cmd;
    char* dir;
    char* filename;
    char* ddd;
    int len, pos;
    int i,j;

    if(strchr8(fn,' ')!=NULL || strchr8(fn,';')!=NULL) return NULL; 

    ECNN(cmd=salloc(MAXFILENAMELEN+1));
    ECNN(dir=salloc(MAXFILENAMELEN+1));
    ECNN(filename=salloc(MAXFILENAMELEN+1));

    if( fn[0]!= '/' ) 
    {   
        ECNN(ddd = getCurDir()); strcpy8(dir, ddd); 
        ECFN(sfree(ddd)); strcat8(dir,"/"); 
    }
    else dir[0]='\0';

    len = strlen8(fn); 
    for(pos=-1, i=len-1; i>=0; i--) 
         if(fn[i]=='/') { pos=i; break; }
           
    if(pos == -1) strcpy8(filename,fn);
    else
    {
        strcpy8(filename, fn+pos+1);
        ECNN(ddd=strdup8(fn)); ddd[pos+1]='\0';
        strcat8(dir, ddd);
        ECFN(sfree(ddd));
    }

    /*-------  filename.gsub("*","\\*");  ---*/
    for(j=0, i=0; filename[i];i++)
    {
       if(filename[i]=='*' || filename[i]=='?')  cmd[j++]='\\';   
       cmd[j++]=filename[i];
    }
    cmd[j]='\0';
    strcpy8(filename,cmd);
          
    if( dir[0] == '\0' ) strcat8(dir,"./");

    strcat8(dir,".");  /* can distinguish between recursive and direct dirs*/

    /*---- find /import/usersB/mikheev/ * -name \*c -type f -print    ---*/
    cmd[0]='\0';
    strcat8(cmd,"find ");   strcat8(cmd, dir); strcat8(cmd," -name ");
    strcat8(cmd, filename); strcat8(cmd, " -type f -print");
    fi = popen((char *)cmd, "r");

    ECFN(sfree(filename)); ECFN(sfree(dir)); ECFN(sfree(cmd));
    return fi;
}

void close_abs_names(FILE* fi) { pclose(fi); }

#endif /* HAVE_POPEN */
 

