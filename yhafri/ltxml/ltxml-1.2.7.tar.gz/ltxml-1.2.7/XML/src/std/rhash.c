#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "lt-defs.h"
#include "string16.h"
#include "lt-memory.h"
#include "lt-rhash.h"
#include "lt-comment.h"

#define AvgKeyLen 20
#define MinNel 64

/* create a relocatable hash table
   nel is number of elements
   keysize the total number of Chars in keys, including null terminators
   */

/* Note we keep copies of the keys.
   Incoming keys are not required to be zero-terminated,
   but internal zeros will lead to undefined results.
   Assume we use full words to store key pointers.
   Use int for values */

int rhash(const Char*,int);
int rchash(const Char*,int);
int keysDiffer(const Char*,int,const Char*);
int keysCaseDiffer(const Char*,int,const Char*);
int ilog2(int);

RHashTableHdr* rcreate(int nel,int keysize) {
  RHashTableHdr* hdr;
  int totsize,realsize,lognel,realnel;
  if (!keysize) {
    keysize=AvgKeyLen*nel;
  };
  if (nel<MinNel) {
    realnel=2*MinNel;
  }
  else {
    lognel=ilog2(nel);
    if (nel==(1 << lognel)) {
      realnel=1 << (1+lognel);
    }
    else {
      realnel=1 << (2+lognel);
    };
  };
  realsize=realnel*(sizeof(RHTEntry));
  totsize=realsize+(keysize*CharSize)+sizeof(RHashTableHdr);
  totsize=((totsize+3)/4)*4; /* word boundary */
  if (!(hdr=calloc(totsize,1))) {
    LT_ERROR1(LEMALE,"couldn't calloc %d",totsize);
    return NULL;
  };
  hdr->mask=realnel-1;
  hdr->nel=realnel;
  hdr->length=totsize;
  hdr->freekey=(realsize+sizeof(RHashTableHdr))/CharSize;
  return hdr;
}

RHTEntry* rinsert(const Char* key,int length,RHashTableHdr* hdr,RHVal value) {
  int probe=(rhash(key,length) & hdr->mask);
  RHTEntry *tbl=(RHTEntry*)(hdr+1),
            *entry=tbl+probe;

  /* note no check for already there */
  
  for (;entry->keyptr;entry--) {
    if (entry==tbl) {
      entry=tbl+(hdr->nel-1);
    };
  };
  /* note no check for no room! */
  entry->eval=value;
  entry->keyptr=hdr->freekey;
  memcpy((char*)(((Char*)hdr)+hdr->freekey),
	 (char*)key,
	 length*CharSize);
  hdr->freekey+=length;
  *(
    ((Char*)hdr)+
    (hdr->freekey)
    )=0;
  hdr->freekey+=1;
  return entry;
}

RHTEntry* rsearch(const Char* key,int length,const RHashTableHdr* hdr) {
  int probe=(rhash(key,length) & hdr->mask);
  RHTEntry *tbl=(RHTEntry*)(hdr+1),
           *entry=tbl+probe,
           *rent;

  if (probe+1==hdr->nel) {
    rent=tbl;
  }
  else {
    rent=entry+1;
  };

  for (;entry->keyptr &&
        keysDiffer(key,length,
		   ((Char*)hdr)+(entry->keyptr));
       entry--) {
    if (entry==rent) {
      /* you lose */
      return 0;
    };
    if (entry==tbl) {
      entry=tbl+(hdr->nel-1);
    };
  };
  if (entry->keyptr) {
    return entry;
  }
  else {
    return 0;
  };
}

#if 0

/* Remove case-insensitive versions because too hard for 16-bit chars */

RHTEntry* rcinsert(const Char* key,int length,RHashTableHdr* hdr,RHVal value) {
  /* case insensitive version */
  int probe=(rchash(key,length) & hdr->mask);
  RHTEntry *tbl=(RHTEntry*)(hdr+1),
            *entry=tbl+probe;

  /* note no check for already there */
  
  for (;entry->keyptr;entry--) {
    if (entry==tbl) {
      entry=tbl+(hdr->nel-1);
    };
  };
  /* note no check for no room! */
  entry->eval=value;
  entry->keyptr=hdr->freekey;
  memcpy((char*)(((Char*)hdr)+hdr->freekey),
	 (char*)key,
	 length*CharSize);
  hdr->freekey+=length;
  *(
    ((Char*)hdr)+
    (hdr->freekey)
    )=0;
  hdr->freekey+=1;
  return entry;
}

RHTEntry* rcsearch(const Char* key,int length,const RHashTableHdr* hdr) {
  /* case insensitive version */
  int probe=(rchash(key,length) & hdr->mask);
  RHTEntry *tbl=(RHTEntry*)(hdr+1),
           *entry=tbl+probe,
           *rent;

  if (probe+1==hdr->nel) {
    rent=tbl;
  }
  else {
    rent=entry+1;
  };

  for (;entry->keyptr &&
        keysCaseDiffer(key,length,
		   ((Char*)hdr)+(entry->keyptr));
       entry--) {
    if (entry==rent) {
      /* you lose */
      return 0;
    };
    if (entry==tbl) {
      entry=tbl+(hdr->nel-1);
    };
  };
  if (entry->keyptr) {
    return entry;
  }
  else {
    return 0;
  };
}

#endif

int rhash(const Char* key,int length) {
  /* from James Clark (jjc@jclark.com) who says "from Chris Torek" */
    /* XXX Reconsider for 16-bit chars? */
  unsigned long h = 0;
  for (; length > 0; length--) {
    h = (h << 5) + h + *key++;
  };
  return h;
}

/* k1 is length bound, k2 is 0 terminated */
int keysDiffer(const Char* k1,int k1l,const Char* k2) {
  while(k1l && *k2 && *k1==*k2) {
    k1++; k2++; k1l--;
  };
  if (k1l) {
    return(*k1!=*k2);
  }
  else {
    return *k2;
  };
}

#if 0

/* Remove case-insensitive versions because too hard for 16-bit chars */

int rchash(const Char* key,int length) {
  /* from James Clark (jjc@jclark.com) who says "from Chris Torek" */
    /* XXX Reconsider for 16-bit chars? */
  /* case insensitive version */
  unsigned long h = 0;
  for (; length > 0; length--) {
    h = (h << 5) + h + (*key++ & CMask);
  };
  return h;
}

/* k1 is length bound, k2 is 0 terminated */
int keysCaseDiffer(const Char* k1,int k1l,const Char* k2) {
  while(k1l && *k2 && (*k1 & CMask)==(*k2 & CMask)) {
    k1++; k2++; k1l--;
  };
  if (k1l) {
    return((*k1 & CMask)!=(*k2 & CMask));
  }
  else {
    return *k2;
  };
}

#endif

boolean rmaphash(boolean(*fn)(RHTEntry*,const Char*,void*),
		 const RHashTableHdr* hdr,void* uptr) {
  RHTEntry *entry=(RHTEntry*)(hdr+1);

  int i,n=hdr->nel;

  for (i=0;i<n;entry++,i++) {
    if (entry->keyptr) {
      if (fn(entry,((Char*)hdr)+(entry->keyptr),uptr)==FALSE) {
	return FALSE;
      };
    };
  };
  return TRUE;
}

int ilog2(int n) {
  /* n better be positive . . . */
  int l = 0, xx = 1;
  while(n > xx) {
    xx <<= 1;
    l++;
  };
  return n==xx?l:l-1;
}
