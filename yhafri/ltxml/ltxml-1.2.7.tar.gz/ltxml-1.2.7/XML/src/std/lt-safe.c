#include <stdio.h>
#ifdef macintosh
#include <unix.h>
#include <unistd.h>
#else
#if defined(WIN32) && ! defined(__CYGWIN__)
#include <io.h>  
#else
#include <sys/types.h>
#endif
#include <sys/stat.h>
#endif
#include <fcntl.h>
#include "lt-defs.h"
#include "string16.h"
#include "lt-comment.h"
#include "lt-safe.h"

#ifdef HAVE_LIBZ
#include "zlib.h"
#endif

#include <errno.h>

/* to avoid applications having to know about errno, or use libg++ */
/* Why aren't we using strerror(errno)????*/
const char *strErr( void ) {
#ifdef macintosh
  return "Macs don't have sys_errlist";
#elif defined(__CYGWIN__)
  return strerror(errno);
#else
  return sys_errlist[errno];
#endif
}

/* Open a filename */

int s_open(const char *path,int flags,int mode) {
  int val;
#ifdef macintosh
  /* then the three argument form of open cannot be used 
     have to settle for ignoring mode. 
   */
  val=(flags&O_CREAT) ?open(path,flags):open(path,flags);
#else
  val=(flags&O_CREAT)?open(path,flags,mode):open(path,flags);
#endif
  if (val==EOF) {
    LT_ERROR2(LEFILE,"Couldn't open file %s: %s\n",
	   path,strErr());
  };
  return val;
}

FILE *sfopen(const char *name,const char *mode) {
  FILE *filep;

  if((filep=fopen(name,mode))==NULL) {
    LT_ERROR2(LEFILE,"Couldn't open file %s: %s\n",
	   name,strErr());
  };
  return filep;
}

FILE *stdsfopen(const char *filename,const char *mode) {
  FILE *filep;
  int length;
#ifndef HAVE_LIBZ    
#ifdef HAVE_POPEN
  char string[MAXFILENAMELEN+20];
#endif
#endif

  if (filename==NULL) {
    LT_ERROR(LENULA,"Call to stdsfopen made without instantiated filename.\n");
    return NULL;
  };
  if (mode==NULL) {
    LT_ERROR(LENULA,"Call to stdsfopen made without instantiated mode.\n");
    return NULL;
  };

  length=strlen8(filename);

  if(strcmp8(filename,"stdin")==0)
    return stdin;
  if(strcmp8(filename,"stdout")==0)
    return stdout;
  if(strcmp8(filename,"stderr")==0)
    return stderr;

#ifndef HAVE_LIBZ    
  if (((length>2) && (!strcmp8(filename+length-2,".Z"))) ||
      ((length>3) && (!strcmp8(filename+length-3,".gz")))) {
#ifdef HAVE_POPEN
    if(mode[0] == 'r') {
      sprintf(string,"gunzip -c %s",filename);
      filep=popen(string, "r");
    } else if (mode[0] == 'w') {
      sprintf(string,"gzip -c > %s", filename);
      filep=popen(string,"w");
    } else {
#endif /* HAVE_POPEN */
      LT_ERROR2(LEFILE,"Couldn't deal with %s (compressed) in mode %s\n",
	     filename,mode);
      return NULL;
#ifdef HAVE_POPEN
    };
    if (!filep) {
      LT_ERROR1(LESYSE,"Couldn't open pipe: %s\n",string);
      return NULL;
    };
#endif /* HAVE_POPEN */
  }
  else 
#endif /* HAVE_LIBZ*/
  if ((!strcmp8(filename,"")) || (!strcmp8(filename,"-"))) {
    if(mode[0] == 'r')
      filep=stdin;
    else if(mode[0] == 'w')
      filep=stdout;
    else {
      LT_ERROR1(LEFILE,"FATAL: std*** implied in illegal mode %s\n",mode);
      return NULL;
    };
  }
  else {
    filep=fopen(filename,mode);
  };

  if(filep==NULL) {
    LT_ERROR2(LEFILE,"Couldn't open file %s: %s\n", filename, strErr());
  };

  return filep;
}

int file_len(int fd) {
  struct stat stat_buf;
  if(fstat(fd, &stat_buf) != -1) {
    return(stat_buf.st_size);
  };
  LT_ERROR1(LEFILE,"Couldn't stat file: %s",strErr());
  return -1;
}

int file_length(const FILE *fd) {
#ifdef HAVE_FILENO
  return file_len(fileno((FILE *)fd));
#else
  LT_ERROR(LEFILE,"fileno not supported by this architecture\n");
  return 0;
#endif
}

off_t slseek(int fd, off_t offset, int whence, const char *filename) {
  off_t val;
  if ((val=lseek(fd, offset, whence))==EOF) {
    LT_ERROR2(LEFILE,"Unable to seek %s: %s",filename,strErr());
  };
  return val;
}

off_t sftell(const FILE *f,const char *filename) {
  off_t val;
  if ((val=ftell((FILE*)f))==EOF) {
    LT_ERROR2(LEFILE,"Unable to ftell %s: %s",filename,strErr());
  };
  return val;
}

off_t sfseek(FILE *f,off_t pos,const char *filename) {
  off_t val;
  if ((val=fseek(f,pos,SEEK_SET))==EOF) {
    LT_ERROR2(LEFILE,"Unable to fseek %s: %s",filename,strErr());
  };
  return val;
}

int sfflush(FILE *filep) {
  if (fflush(filep)==EOF) {
    LT_ERROR1(LEWRTF,"fflush failed: %s\n",strErr());
    return EOF;
  };
  return 0;
}

int sfclose(FILE *filep) {
  if (fclose(filep)==EOF) {
    LT_ERROR1(LEWRTF,"fclose failed: %s\n",strErr());
    return EOF;
  };
  return 0;
}

int stdfclose(FILE *filep) {
  if(filep==stdin || filep==stdout || filep==stderr) {
    return sfflush(filep);
  }
  else {
    return sfclose(filep);
  };
}

FILE *sfdopen(int fd, const char *mode) {
#ifdef HAVE_FDOPEN
  FILE *file;

  if((file=fdopen(fd,(char *)mode))==NULL) {
    /* not clear if fdopen failures set ERRNO */
    LT_ERROR1(LEFILE,"Failed to assign stream to file %d\n",fd);
  };

  return file;
#else
  LT_ERROR(LEFILE,"sfdopen not supported for this architecture %d\n");
  return 0;
#endif
}

int sread(int fd, char *buf, int nbyte) {
  int val;
  if ((val=read(fd,buf,nbyte))==EOF) {
    LT_ERROR1(LERDF,"read failed: %s\n",strErr());
    return EOF;
  }
  else {
    return val;
  };
}

int sputc(char c, FILE *stream) {
  if (putc(c,stream)==EOF) {
    LT_ERROR1(LEWRTF,"putc failed: %s\n",strErr());
    return EOF;
  }
  else {
    return c;
  };
}

int sfputs(const char *s, FILE *stream) {
  int val;
  if ((val=(fputs(s,stream)))==EOF) {
    LT_ERROR1(LEWRTF,"puts failed: %s\n",strErr());
  };
  return val;
}

int sputw(int w, FILE *stream) {
#ifdef HAVE_PUTW
  if (putw(w,stream)) {
#else
  if (fwrite(&w,sizeof(int),1,stream) != 1) {
#endif
    /* putw returns 1 on failure */
    LT_ERROR(LEWRTF,"sputw failed\n");
    return EOF;
  } else {
    return 0;
  }
}

int sfwrite(const void* ptr, int size, int nitems, FILE* stream) {
  int val;

  if ((val=fwrite(ptr, size, nitems, stream))==0 &&
      (size>0) &&
      (nitems>0)) {
    LT_ERROR1(LEWRTF,"sfwrite failed: %s\n",strErr());
    return EOF;
  }
  else {
    return val;
  };
}

int sfprintf(FILE *stream, const char *format, ...) {
  va_list args;
  int retval;

  va_start(args, format);
  retval = vfprintf(stream, format, args);
  va_end(args);
  if(retval == EOF) {
    LT_ERROR1(LEWRTF,"sfprintf failed: %s\n",strErr());
  }
  return retval;
}

int sFprintf(FILE16 *stream, const char *format, ...) {
  va_list args;
  int retval;

  va_start(args, format);
  retval = Vfprintf(stream, format, args);
  va_end(args);
  if(retval == EOF) {
    LT_ERROR1(LEWRTF,"sFprintf failed: %s\n",strErr());
  }
  return retval;
}

int sFflush(FILE16 *filep) {
  if (Fflush(filep)==EOF) {
    LT_ERROR1(LEWRTF,"fflush failed: %s\n",strErr());
    return EOF;
  };
  return 0;
}

/* XXX improve these!!! */

int sPutc(Char c, FILE16 *stream)
{
    Char buf[2];
    buf[0] = c; buf[1] = 0;
    return sFprintf(stream, "%S", buf);
}

int sFputs(const Char *s, FILE16 *stream) 
{
    return sFprintf(stream, "%S", s);
}

