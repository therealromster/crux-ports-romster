/* err.c	-- Henry Thompson Fri Feb  2 1996
 * Simple error handling for NSL code
 */
#include <stdlib.h>
#include "lt-defs.h"
#include "charset.h"
#include "stdio16.h"
#include "lt-err.h"

CharacterEncoding ErrorMessageEncoding = CE_ISO_8859_1;

int LTSTD_errno=0,LTSTD_nerr=LENERR,LTSTD_errthresh=0;

const char *localerrlist[LENERR+1]={"",
			    "Empty argument",
			    "Library-level catastrophe",
			    "Malloc failed",
			    "File error",
			    "Mmap failed",
			    "(U)free failed",
			    "Not a DDB file",
			    "Write failed",
			    "Read failed",
			    "Subproc failed",
			    "Regexp failure",
			    "DDB failure"};
			    
const char **LTSTD_errlist=&(localerrlist[0]);

static void (*LTSTD_error_handler)(int errnum) = 0;

void LTSTD_perror(const char* s) {
  if (s && s[0]) {
    Fprintf(Stderr, "%s: ",s);
  };
  if (LTSTD_errno>-1 && LTSTD_errno<=LTSTD_nerr) {
    Fprintf(Stderr, "%s\n",LTSTD_errlist[LTSTD_errno]);
  }
  else {
    Fprintf(Stderr,
	    "[no message for LTSTD_errno: %d]\n",LTSTD_errno);
  };
}

void LTSTDError(int errn,int severity,const char *floc,int nloc) {
  LTSTD_errno=errn;

  if(LTSTD_error_handler) {
      LTSTD_error_handler(errn);
      return;
  }

  if (severity>LTSTD_errthresh) {
    Fprintf(Stderr, 
	    "Fatal LTSTD error (severity %d) at %s.%d: ",
            severity,floc,nloc);
    LTSTD_perror(NULL);
    exit(errn);
  };
}

void LTSTD_set_error_handler(void (*error_handler)(int))
{
    LTSTD_error_handler = error_handler;
}
