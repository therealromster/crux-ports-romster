#include "lt-umalloc.h"
#include "lt-memory.h"    /* IS part of what umalloc needs internally */
#include "lt-comment.h"

/* Function prototypes for functions defined in this file */

UStack *NewStack( int size, int itemsz );
boolean FreeStacks( UStack *stack );
boolean FreeUmalloc( Umalloc *umalloc );
void NameUmalloc( Umalloc *u, const char* name );
Umalloc *Uinit(int itemsize, int stacksize, int percentincrement);
Umalloc *Ureinit(Umalloc *umalloc);
void *Usalloc(Umalloc *umalloc);
boolean Ufree(Umalloc *umalloc, void *ptr);

/* --- */

UStack *NewStack( int size, int itemsz ) {
  struct UStack *ustack;
  char *ptr;
  int i;

  ECNN(ustack=tsalloc(UStack, 1));
  ustack->itemsize=itemsz;
  ustack->stacksize=size;
  ustack->stackpointer=0;
  ECNN(ustack->stack=(void *)salloc( size*sizeof(void *)));
  ptr=salloc( itemsz*(size+5) );
  if(!ptr) {
    free( ustack->stack );
    free( ustack );
    return NULL;
  }
  ustack->itembase=ptr;
  for(i=0; i< size; i++) {
    ustack->stack[i]=ptr+i*itemsz;
  }
  ustack->next=ustack->prev=NULL;

  return ustack;
}

boolean FreeStacks( UStack *stack ) {
  ECFF(sfree(stack->itembase));
  ECFF(sfree(stack->stack));
  if(stack->next) {
    ECFF(FreeStacks(stack->next));
  }
  ECFF(sfree(stack));
  return TRUE;
}

boolean FreeUmalloc( Umalloc *umalloc ) {
  UStack *us;
  for(us=umalloc->stack; us->prev; us=us->prev)
    /* EMPTY */;
  ECFF(FreeStacks(us));
  return sfree(umalloc);
}

void NameUmalloc( Umalloc *u, const char* name ) {
  u->name=name;
}

Umalloc *Uinit(int itemsize, int stacksize, int percentincrement) {
  Umalloc *umalloc;

  ECNN(umalloc=tsalloc(Umalloc, 1));
  umalloc->itemsize=itemsize;
  umalloc->totalstacksize=stacksize;
  ECNN(umalloc->stack=NewStack( stacksize, itemsize ));
  umalloc->percentincrement=percentincrement;
  umalloc->name="The stack with no name";
  return umalloc;
}

Umalloc *Ureinit(Umalloc *umalloc) {
  UStack *newstack;
  int sz;

  if(umalloc->stack->next) {
      umalloc->stack=umalloc->stack->next;
      return umalloc;
  }

  sz=(int)((float)umalloc->totalstacksize*(float)umalloc->percentincrement/100)+10;
  COMMENT1("Adding another %d elements to the stack ", sz);
  COMMENT1("\"%s\"\n", umalloc->name);
  ECNN(newstack=NewStack( sz, umalloc->itemsize ));
    
  newstack->prev=umalloc->stack;
  umalloc->stack->next=newstack;

  umalloc->stack=newstack;
  umalloc->totalstacksize+=sz;
  return umalloc;
}

void *Usalloc(Umalloc *umalloc) {
  UStack *stk=umalloc->stack;

  stk->stackpointer++;
  if(stk->stackpointer>=stk->stacksize) {
    stk->stackpointer--;
	
    if(Ureinit(umalloc)) {
      stk=umalloc->stack;
    } else {
      umalloc->stack->stackpointer--;
      return NULL;
    }
    stk->stackpointer++;
  }
  return stk->stack[stk->stackpointer-1];
}

boolean Ufree(Umalloc *umalloc, void *ptr) {
  umalloc->stack->stackpointer--;
  if(umalloc->stack->stackpointer<0) {
    umalloc->stack->stackpointer=0;
    umalloc->stack=umalloc->stack->prev;
    if(!umalloc->stack) {
      LT_ERROR(LEFREE,"ERROR --- Ufree failed (stack consistency error)\n");
      return FALSE;
    }
    /* Already done the decrement in Usalloc */
  }
  umalloc->stack->stack[umalloc->stack->stackpointer]=ptr;
  return TRUE;
}
