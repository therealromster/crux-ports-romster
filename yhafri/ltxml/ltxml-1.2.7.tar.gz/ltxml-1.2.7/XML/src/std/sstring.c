#include <string.h>
#include <stdlib.h>
#include "lt-defs.h"
#include "string16.h"
#include "lt-comment.h"
#include "lt-memory.h"
#include "lt-sstring.h"

int var_int_scan(char *string, int *list) {
  char *ptr, *dupstring;
  int n;
    
  ECNE(dupstring=ptr=strdup8(string));
  for(ptr=strtok(ptr, WHITESPACE), n=0; ptr!=NULL; 
      n++, ptr=strtok(NULL,WHITESPACE)) {
    list[n]=atoi(ptr);
  };

  ECFE(sfree(dupstring));
  return n;
}

int var_float_scan(char *string, float *list) {
  char *ptr, *dupstring;
  int n;
    
  ECNE(dupstring=ptr=strdup8(string));
  for(ptr=strtok(ptr, WHITESPACE), n=0; ptr!=NULL;
      n++, ptr=strtok(NULL,WHITESPACE)) {
    list[n]=(float)atof(ptr);
  };

  ECFE(sfree(dupstring));
  return n;
}
int var_string_scan(char *string, char **list) {
  char *ptr, *dupstring;
  int n;
    
  ECNE(dupstring=ptr=strdup8(string));
  for(ptr=strtok(ptr, WHITESPACE), n=0; ptr!=NULL; 
      n++, ptr=strtok(NULL,WHITESPACE)) {
    list[n]=ptr;
  };

  return n;
}

char *var_int_print(int n, char *string, int *list) {
  int i;

  string[0]=0;
  for(i=0;i<n;i++) {
    sprintf(string, " %d", list[i]);
  };

  return string;
}

char *var_float_print(int n, char *string, float *list) {
  int i;

  string[0]=0;
  for(i=0;i<n;i++) {
    sprintf(string, " %f", list[i]);
  };

  return string;
}

char *var_string_print(int n, char *string, char **list) {
  int i;

  string[0]=0;
  for(i=0;i<n;i++) {
    sprintf(string, " %s", list[i]);
  };

  return string;
}

int NumTokens(char *string) {
  char *ptr, *dstring;
  int i=0;

  ECNE(dstring=strdup8(string));
  for(ptr=strtok(dstring,WHITESPACE); ptr!=NULL; ptr=strtok(NULL,WHITESPACE)) {
    i++;
  };
  ECFE(sfree(dstring));
  return i;
}
