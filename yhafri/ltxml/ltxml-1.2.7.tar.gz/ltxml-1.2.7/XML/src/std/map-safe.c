/* Mapping of files into memory */
#include "lt-defs.h"
#include <stdio.h>
#include <fcntl.h>
#ifndef NO_MAPMEM 
#include <sys/stat.h>
#include <sys/mman.h>
#ifndef HAVE_MUNMAP_P
extern int munmap(caddr_t, size_t);
#endif
#else
#define PROT_READ 0
#define MAP_PRIVATE 0
#include "lt-memory.h"
#endif

#include "lt-defs.h"
#include "charset.h"
#include "lt-comment.h"
#include "lt-safe.h"
#include "url.h"

void *smmap(caddr_t addr, size_t len,
	    int prot, int flags, int fd, off_t off, const char *filename) {
  void *pa;

#ifdef  NO_MAPMEM
  /*WARN1(LEMAP,"mmap() not implemented in Macintosh/NT version. \n\
           Couldn't map in %s\n",filename);*/
  /* No Memory mapping - so allocate space and read in */
  int nr;
  ECNN(pa = salloc(len));
  ECEN(nr=read(fd,pa,len));
  if((size_t)nr  != len ){
    LT_ERROR3(LEMAP,"Unexpected read result (%d/%d) in smmap for %s",
	      nr, (int)len, filename);
    return NULL;
  } else {
    return pa;
  }
#else
  pa=mmap(addr,len,prot,flags,fd,off);
  if ((caddr_t)pa!=MAP_FAILED) {
    return pa;
  } else {
    LT_ERROR2(LEMAP,"Couldn't map in %s: %s",filename,strErr());
    return NULL;
  }
#endif
}

void *mmapfile(const char *filename, int *n) {
  int fd;
  void * result;

  /* Current version assumes that filename is, as it says, a filename */

#if defined(WIN32) && ! defined(__CYGWIN__)
  ECEN(fd = s_open(filename,
		   O_RDONLY | _O_BINARY,
		   0));
#else
  ECEN(fd = s_open(filename,
		   O_RDONLY,
		   0));
#endif
  ECEN(*n = file_len(fd));

  /* New version allows this to be a URL 
     But this requires that url_open is moved to STD library

  FILE *stream;
  ECEN(stream = url_open(filename, NULL, "r", NULL));
  ECEN(fd = stream->_file);
  ECEN(*n = file_len(fd));
  */

  result = smmap(NULL, *n, PROT_READ, MAP_PRIVATE, fd, 0,filename);

  close(fd) ; 

  /* NEW 
  fclose(stream);
  */

  /* We dont need to keep the file open once  */
  /* we have mapped it in. In fact we want to */
  /* close it, else we run into problems with */
  /* too many open files                      */
  return result;
}

boolean smunmap(caddr_t addr,int len) {
#ifdef  NO_MAPMEM
  /* WARN1(LEMAP,"smunmap() not implemented in Macintosh/NT version. \n\
           Couldn't unmap in %d\n",(int)addr); */
  sfree((char *) addr);
  return FALSE;
#else
  if (munmap(addr,len)==-1) {
    LT_ERROR1(LEMAP,"Couldn't unmap: %s\n",strErr());
    return FALSE;
  } else {
    return TRUE;
  }
#endif
}





