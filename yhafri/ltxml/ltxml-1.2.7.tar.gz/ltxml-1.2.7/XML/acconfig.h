#ifndef _xml_config_h
#define _xml_config_h

@TOP@

/* duplicates to make autoheader happy */
#undef HAVE_STDARG_H
#undef HAVE_STDLIB_H

#undef HAVE_FILEUTIL_P
#undef HAVE_FILEUTIL2_P
#undef HAVE_SYSTEM_P
#undef HAVE_SYS_ERRLIST_DECL
#undef FREE_VOID
#undef HAVE_FTRUNCATE_P
#undef CHAR_SIZE
#undef HAVE_MUNMAP_P
#undef HAVE_LIBZ

@BOTTOM@

#endif /* xml_config_h */
