#include "nsl.h"
int main(int argc, char **argv){
    NSL_Bit *nslbit;
    NSL_File sf, outf=0;
    NSL_Doctype dct = NULL;
    NSL_FType intype = NSL_read, outtype = NSL_write_normal;

    NSLInit(0);

    sf   = SFFopen(stdin,dct,intype,"&lt;stdin>");
    dct  = DoctypeFromFile(sf);
    outf = SFFopen(stdout, dct, outtype,"&lt;stdout>");
    while( ( nslbit = GetNextBit(sf) )){
	      if (nslbit->type==NSL_bad) {
		  PrintText(outf,(Char *) "!\n!!bad bit!!!\n");
		  return 1;
	      } else {
		  PrintBit(outf,nslbit);
	      }
	  
	  FreeBit(nslbit);
    }

    SFclose(sf);
    SFclose(outf);

    NSLClose();

    return 0;

}
