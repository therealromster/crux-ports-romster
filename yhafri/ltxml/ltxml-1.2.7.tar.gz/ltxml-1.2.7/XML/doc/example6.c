#include "nsl.h" 
int main(int argc, char **argv){
    NSL_Bit *nslbit;
    NSL_File sf, outf=0;
    NSL_Doctype dct = NULL;
    CharacterEncoding enc = CE_unknown;
    NSL_FType intype = NSL_read, outtype = NSL_write_normal;

    NSLInit(0);

    sf   = OpenStream(stdin,dct,intype,enc,"&lt;stdin>");
    dct  = DoctypeFromFile(sf);
    outf = OpenStream(stdout, dct, outtype,enc,"&lt;stdout>");
    while( ( nslbit = GetNextBit(sf) )){
	      if (nslbit->type==NSL_bad) {
		  PrintText(outf,(Char *) "!\n!!bad bit!!!\n");
                  SFrelease(sf,FALSE);
                  SFrelease(outf,TRUE);
		  return 1;
	      } else {
		  PrintBit(outf,nslbit);
	      }
	  
	  FreeBit(nslbit);
    }

    SFrelease(sf,FALSE);
    SFrelease(outf,TRUE);

    return 0;
}
