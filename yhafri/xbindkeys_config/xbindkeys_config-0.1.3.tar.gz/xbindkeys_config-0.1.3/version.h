/* set the current version of xbindkeys_config */

#define XBINDKEYS_CONFIG_VERSION "0.1.3"


/* Set the pat tu xbinkeys program */

#define XBINDKEYS_PATCH "xbindkeys" /* Change this only for debbuging */
