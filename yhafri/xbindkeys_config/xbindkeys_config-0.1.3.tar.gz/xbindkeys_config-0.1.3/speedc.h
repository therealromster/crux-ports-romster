#include <gtk/gtk.h>
#include <stdio.h>


GtkWidget * xbindkeys_config_speed_config(int show);
