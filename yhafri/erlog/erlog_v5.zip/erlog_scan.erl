%% THIS IS A PRE-RELEASE OF LEEX - RELEASED ONLY BECAUSE MANY PEOPLE
%% WANTED IT - THE OFFICIAL RELEASE WILL PROVIDE A DIFFERENT INCOMPATIBLE
%% AND BETTER INTERFACE - BE WARNED
%% PLEASE REPORT ALL BUGS TO THE AUTHOR.

-module(erlog_scan).

-export([string/1,string/2,token/2,token/3,tokens/2,tokens/3]).
-export([format_error/1]).

%% User code. This is placed here to allow extra attributes.

%%% File    : erlog_scan.erl
%%% Author  : Robert Virding
%%% Purpose : Token definitions for Erlog.
%%%
%%% (C)Robert Virding. This stuff is mine, distributed without
%%% warranty "as is" and may not be used commercially without written
%%% permission.

-import(string, [substr/2,substr/3]).

%% base(Chars, Base) -> Integer.
%% Convert a string of Base characters into a number. We know that
%% the strings only contain the correct character.

base(Cs, B) ->
    case base(Cs, B, 0) of
	{N,[]} -> {token,{number,N}};
	{_,_} -> {error,"illegal based number"}
    end.

base([C|Cs], Base, SoFar) when C >= $0, C =< $9, C < Base + $0 ->
    Next = SoFar * Base + (C - $0),
    base(Cs, Base, Next);
base([C|Cs], Base, SoFar) when C >= $a, C =< $f, C < Base + $a - 10 ->
    Next = SoFar * Base + (C - $a + 10),
    base(Cs, Base, Next);
base([C|Cs], Base, SoFar) when C >= $A, C =< $F, C < Base + $A - 10 ->
    Next = SoFar * Base + (C - $A + 10),
    base(Cs, Base, Next);
base([C|Cs], _Base, SoFar) -> {SoFar,[C|Cs]};
base([], _Base, N) -> {N,[]}.

%% chars(InputChars) -> Chars.
%% Convert an input string into the corresponding string
%% characters. We know that the input string is correct.

chars([$\\,$x,C|Cs0]) ->
    case hex_char(C) of
	true ->
	    case base([C|Cs0], 16, 0) of
		{N,[$\\|Cs1]} -> [N|chars(Cs1)];
		_Other -> [escape_char($x)|chars([C|Cs0])]
	    end;
	false -> [escape_char($x)|chars([C|Cs0])]
    end;
chars([$\\,C|Cs0]) when C >= $0, C =< $7 ->
    case base(Cs0, 8, C - $0) of
	{N,[$\\|Cs1]} -> [N|chars(Cs1)];
	_Other -> [escape_char(C)|chars(Cs0)]
    end;
chars([$\\,C|Cs]) -> [escape_char(C)|chars(Cs)];
chars([C|Cs]) -> [C|chars(Cs)];
chars([]) -> [].

hex_char(C) when C >= $0, C =< $9 -> true;
hex_char(C) when C >= $a, C =< $f -> true;
hex_char(C) when C >= $A, C =< $F -> true;
hex_char(_) -> false.

escape_char($n) -> $\n;				%\n = LF
escape_char($r) -> $\r;				%\r = CR
escape_char($t) -> $\t;				%\t = TAB
escape_char($v) -> $\v;				%\v = VT
escape_char($b) -> $\b;				%\b = BS
escape_char($f) -> $\f;				%\f = FF
escape_char($e) -> $\e;				%\e = ESC
escape_char($s) -> $\s;				%\s = SPC
escape_char($d) -> $\d;				%\d = DEL
escape_char(C) -> C.

format_error({illegal,S}) -> ["illegal characters ",io_lib:write_string(S)];
format_error({user,S}) -> S.

string(String) -> string(String, 1).

string(String, Line) -> string(String, Line, String, []).

%% string(InChars, Line, TokenChars, Tokens) ->
%%    {ok,Tokens,Line} | {error,ErrorInfo,Line}.

string([], L, [], Ts) ->			%No partial tokens!
    {ok,yyrev(Ts),L};
string(Ics0, L0, Tcs, Ts) ->
    case yystate(yystate(), Ics0, L0, 0, reject, 0) of
	{A,Alen,Ics1,L1} ->			%Accepting end state
	    string_cont(Ics1, L1, yyaction(A, Alen, Tcs, L1), Ts);
	{A,Alen,Ics1,L1,_S1} ->		%After an accepting state
	    string_cont(Ics1, L1, yyaction(A, Alen, Tcs, L1), Ts);
	{reject,_Alen,Tlen,_Ics1,L1,_S1} ->
	    {error,{L1,?MODULE,{illegal,yypre(Tcs, Tlen+1)}},L1};
	{A,Alen,_Tlen,_Ics1,L1,_S1} ->
	    string_cont(yysuf(Tcs, Alen), L1, yyaction(A, Alen, Tcs, L1), Ts)
    end.

%% string_cont(RestChars, Line, Token, Tokens)
%%  Test for and remove the end token wrapper.

string_cont(Rest, Line, {token,T}, Ts) ->
    string(Rest, Line, Rest, [T|Ts]);
string_cont(Rest, Line, {end_token,T}, Ts) ->
    string(Rest, Line, Rest, [T|Ts]);
string_cont(Rest, Line, skip_token, Ts) ->
    string(Rest, Line, Rest, Ts);
string_cont(_Rest, Line, {error,S}, _Ts) ->
    {error,{Line,?MODULE,{user,S}},Line}.

%% token(Continuation, Chars, Line) ->
%%    {more,Continuation} | {done,ReturnVal,RestChars}.
%% Must be careful when re-entering to append the latest characters to the
%% after characters in an accept.

token(Cont, Chars) -> token(Cont, Chars, 1).

token([], Chars, Line) ->
    token(Chars, Line, yystate(), Chars, 0, reject, 0);
token({Line,State,Tcs,Tlen,Action,Alen}, Chars, _) ->
    token(Chars, Line, State, Tcs ++ Chars, Tlen, Action, Alen).

%% token(InChars, Line, State, TokenChars, TokenLen, AcceptAction, AcceptLen) ->
%%    {more,Continuation} | {done,ReturnVal,RestChars}.

token(Ics0, L0, S0, Tcs, Tlen0, A0, Alen0) ->
    case yystate(S0, Ics0, L0, Tlen0, A0, Alen0) of
	{A1,Alen1,Ics1,L1} ->			%Accepting end state
	    token_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1));
	{A1,Alen1,[],L1,S1} ->			%After an accepting state
	    {more,{L1,S1,Tcs,Alen1,A1,Alen1}};
	{A1,Alen1,Ics1,L1,_S1} ->
	    token_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1));
	{A1,Alen1,Tlen1,[],L1,S1} ->		%After a non-accepting state
	    {more,{L1,S1,Tcs,Tlen1,A1,Alen1}};
	{reject,_Alen1,_Tlen1,eof,L1,_S1} ->
	    {done,{eof,L1},[]};
	{reject,_Alen1,Tlen1,Ics1,L1,_S1} ->
	    {done,{error,{L1,?MODULE,{illegal,yypre(Tcs, Tlen1+1)}},L1},Ics1};
	{A1,Alen1,_Tlen1,_Ics1,L1,_S1} ->
	    token_cont(yysuf(Tcs, Alen1), L1, yyaction(A1, Alen1, Tcs, L1))
    end.

%% tokens_cont(RestChars, Line, Token)
%%  If we have a token or error then return done, else if we have a
%%  skip_token then continue.

token_cont(Rest, Line, {token,T}) ->
    {done,{ok,T,Line},Rest};
token_cont(Rest, Line, {end_token,T}) ->
    {done,{ok,T,Line},Rest};
token_cont(Rest, Line, skip_token) ->
    token(Rest, Line, yystate(), Rest, 0, reject, 0);
token_cont(Rest, Line, {error,S}) ->
    {done,{error,{Line,?MODULE,{user,S}},Line},Rest}.

%% tokens(Continuation, Chars, Line) ->
%%    {more,Continuation} | {done,ReturnVal,RestChars}.
%% Must be careful when re-entering to append the latest characters to the
%% after characters in an accept.

tokens(Cont, Chars) -> tokens(Cont, Chars, 1).

tokens([], Chars, Line) ->
    tokens(Chars, Line, yystate(), Chars, 0, [], reject, 0);
tokens({tokens,Line,State,Tcs,Tlen,Ts,Action,Alen}, Chars, _) ->
    tokens(Chars, Line, State, Tcs ++ Chars, Tlen, Ts, Action, Alen);
tokens({skip_tokens,Line,State,Tcs,Tlen,Error,Action,Alen}, Chars, _) ->
    skip_tokens(Chars, Line, State, Tcs ++ Chars, Tlen, Error, Action, Alen).

%% tokens(InChars, Line, State, TokenChars, TokenLen, Tokens, AcceptAction, AcceptLen) ->
%%    {more,Continuation} | {done,ReturnVal,RestChars}.

tokens(Ics0, L0, S0, Tcs, Tlen0, Ts, A0, Alen0) ->
    case yystate(S0, Ics0, L0, Tlen0, A0, Alen0) of
	{A1,Alen1,Ics1,L1} ->			%Accepting end state
	    tokens_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1), Ts);
	{A1,Alen1,[],L1,S1} ->			%After an accepting state
	    {more,{tokens,L1,S1,Tcs,Alen1,Ts,A1,Alen1}};
	{A1,Alen1,Ics1,L1,_S1} ->
	    tokens_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1), Ts);
	{A1,Alen1,Tlen1,[],L1,S1} ->		%After a non-accepting state
	    {more,{tokens,L1,S1,Tcs,Tlen1,Ts,A1,Alen1}};
	{reject,_Alen1,_Tlen1,eof,L1,_S1} ->
	    {done,if Ts == [] -> {eof,L1};
		     true -> {ok,yyrev(Ts),L1} end,[]};
	{reject,_Alen1,Tlen1,_Ics1,L1,_S1} ->
	    skip_tokens(yysuf(Tcs, Tlen1+1), L1,
			{L1,?MODULE,{illegal,yypre(Tcs, Tlen1+1)}});
	{A1,Alen1,_Tlen1,_Ics1,L1,_S1} ->
	    tokens_cont(yysuf(Tcs, Alen1), L1, yyaction(A1, Alen1, Tcs, L1), Ts)
    end.

%% tokens_cont(RestChars, Line, Token, Tokens)
%%  If we have a end_token or error then return done, else if we have
%%  a token then save it and continue, else if we have a skip_token
%%  just continue.

tokens_cont(Rest, Line, {token,T}, Ts) ->
    tokens(Rest, Line, yystate(), Rest, 0, [T|Ts], reject, 0);
tokens_cont(Rest, Line, {end_token,T}, Ts) ->
    {done,{ok,yyrev(Ts, [T]),Line},Rest};
tokens_cont(Rest, Line, skip_token, Ts) ->
    tokens(Rest, Line, yystate(), Rest, 0, Ts, reject, 0);
tokens_cont(Rest, Line, {error,S}, _Ts) ->
    skip_tokens(Rest, Line, {Line,?MODULE,{user,S}}).

%%skip_tokens(InChars, Line, Error) -> {done,{error,Error,Line},Ics}.
%%  Skip tokens until an end token, junk everything and return the error.

skip_tokens(Ics, Line, Error) ->
    skip_tokens(Ics, Line, yystate(), Ics, 0, Error, reject, 0).

%% skip_tokens(InChars, Line, State, TokenChars, TokenLen, Tokens, AcceptAction, AcceptLen) ->
%%    {more,Continuation} | {done,ReturnVal,RestChars}.

skip_tokens(Ics0, L0, S0, Tcs, Tlen0, Error, A0, Alen0) ->
    case yystate(S0, Ics0, L0, Tlen0, A0, Alen0) of
	{A1,Alen1,Ics1,L1} ->			%Accepting end state
	    skip_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1), Error);
	{A1,Alen1,[],L1,S1} ->			%After an accepting state
	    {more,{skip_tokens,L1,S1,Tcs,Alen1,Error,A1,Alen1}};
	{A1,Alen1,Ics1,L1,_S1} ->
	    skip_cont(Ics1, L1, yyaction(A1, Alen1, Tcs, L1), Error);
	{A1,Alen1,Tlen1,[],L1,S1} ->		%After a non-accepting state
	    {more,{skip_tokens,L1,S1,Tcs,Tlen1,Error,A1,Alen1}};
	{reject,_Alen1,_Tlen1,eof,L1,_S1} ->
	    {done,{error,Error,L1},[]};
	{reject,_Alen1,Tlen1,_Ics1,L1,_S1} ->
	    skip_tokens(yysuf(Tcs, Tlen1), L1, Error);
	{A1,Alen1,_Tlen1,_Ics1,L1,_S1} ->
	    skip_cont(yysuf(Tcs, Alen1), L1, yyaction(A1, Alen1, Tcs, L1), Error)
    end.

%% skip_cont(RestChars, Line, Token, Error)
%%  Skip tokens until we have an end_token or error then reutrn done
%%  with the original rror.

skip_cont(Rest, Line, {token,_T}, Error) ->
    skip_tokens(Rest, Line, yystate(), Rest, 0, Error, reject, 0);
skip_cont(Rest, Line, {end_token,_T}, Error) ->
    {done,{error,Error,Line},Rest};
skip_cont(Rest, Line, {error,_S}, Error) ->
    skip_tokens(Rest, Line, yystate(), Rest, 0, Error, reject, 0);
skip_cont(Rest, Line, skip_token, Error) ->
    skip_tokens(Rest, Line, yystate(), Rest, 0, Error, reject, 0).

yyrev(List) -> lists:reverse(List).
yyrev(List, Tail) -> lists:reverse(List, Tail).
yypre(List, N) -> lists:sublist(List, N).
yysuf(List, N) -> lists:nthtail(N, List).

%% yystate() -> InitialState.
%% yystate(State, InChars, Line, TokenLen, AcceptAction, AcceptLen) ->
%%      {Action, AcceptLength, RestChars, Line} |         Accepting end state
%%      {Action, AcceptLength, RestChars, Line, State} |  Accepting state
%%      {Action, AcceptLength, TokLength, RestChars, Line, State} |
%%      {reject, AcceptLength, TokLength, RestChars, Line, State}.
%% Generated state transition functions. The non-accepting end state
%% return signal either an unrecognised character or end of current
%% input.

yystate() -> 38.

yystate(45, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(30, Ics, Line+1, Tlen+1, 16, Tlen);
yystate(45, [$(|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(39, Ics, Line, Tlen+1, 16, Tlen);
yystate(45, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(45, Ics, Line, Tlen+1, 16, Tlen);
yystate(45, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $' ->
    yystate(45, Ics, Line, Tlen+1, 16, Tlen);
yystate(45, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $), C =< $� ->
    yystate(45, Ics, Line, Tlen+1, 16, Tlen);
yystate(45, Ics, Line, Tlen, _Action, _Alen) ->
    {16,Tlen,Ics,Line,45};
yystate(44, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(40, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, [$.|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(11, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, [$b|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(41, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, [$o|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(29, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, [$x|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(13, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(2, Ics, Line, Tlen+1, 1, Tlen);
yystate(44, Ics, Line, Tlen, _Action, _Alen) ->
    {1,Tlen,Ics,Line,44};
yystate(43, [$+|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(27, Ics, Line, Tlen+1, _Action, _Alen);
yystate(43, [$-|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(27, Ics, Line, Tlen+1, _Action, _Alen);
yystate(43, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(35, Ics, Line, Tlen+1, _Action, _Alen);
yystate(43, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,43};
yystate(42, [$#|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$$|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$&|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$*|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$+|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$:|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$^|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [$~|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $-, C =< $/ ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $<, C =< $@ ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(42, Ics, Line, Tlen, _Action, _Alen) ->
    {9,Tlen,Ics,Line,42};
yystate(41, [$0|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(37, Ics, Line, Tlen+1, _Action, _Alen);
yystate(41, [$1|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(37, Ics, Line, Tlen+1, _Action, _Alen);
yystate(41, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,41};
yystate(40, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(32, Ics, Line, Tlen+1, _Action, _Alen);
yystate(40, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(3, Ics, Line, Tlen+1, _Action, _Alen);
yystate(40, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $[ ->
    yystate(3, Ics, Line, Tlen+1, _Action, _Alen);
yystate(40, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(3, Ics, Line, Tlen+1, _Action, _Alen);
yystate(40, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,40};
yystate(39, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(30, Ics, Line+1, Tlen+1, 13, Tlen);
yystate(39, [$(|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(39, Ics, Line, Tlen+1, 13, Tlen);
yystate(39, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(45, Ics, Line, Tlen+1, 13, Tlen);
yystate(39, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $' ->
    yystate(45, Ics, Line, Tlen+1, 13, Tlen);
yystate(39, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $), C =< $� ->
    yystate(45, Ics, Line, Tlen+1, 13, Tlen);
yystate(39, Ics, Line, Tlen, _Action, _Alen) ->
    {13,Tlen,Ics,Line,39};
yystate(38, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(30, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(38, [$!|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(14, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$#|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$$|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$%|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(45, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$&|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$(|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$)|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$*|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$+|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$,|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$-|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$.|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(20, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$/|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$0|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(44, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$:|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$;|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(10, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$[|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$]|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$^|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$_|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(18, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [$~|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(30, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $\s ->
    yystate(30, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $1, C =< $9 ->
    yystate(2, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $<, C =< $@ ->
    yystate(42, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $Z ->
    yystate(18, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $z ->
    yystate(26, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, [C|Ics], Line, Tlen, _Action, _Alen) when C >= ${, C =< $} ->
    yystate(34, Ics, Line, Tlen+1, _Action, _Alen);
yystate(38, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,38};
yystate(37, [$0|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(37, Ics, Line, Tlen+1, 2, Tlen);
yystate(37, [$1|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(37, Ics, Line, Tlen+1, 2, Tlen);
yystate(37, Ics, Line, Tlen, _Action, _Alen) ->
    {2,Tlen,Ics,Line,37};
yystate(36, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(36, Ics, Line, Tlen+1, 15, Tlen);
yystate(36, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $� ->
    yystate(36, Ics, Line, Tlen+1, 15, Tlen);
yystate(36, Ics, Line, Tlen, _Action, _Alen) ->
    {15,Tlen,Ics,Line,36};
yystate(35, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(35, Ics, Line, Tlen+1, 0, Tlen);
yystate(35, Ics, Line, Tlen, _Action, _Alen) ->
    {0,Tlen,Ics,Line,35};
yystate(34, Ics, Line, Tlen, _Action, _Alen) ->
    {14,Tlen,Ics,Line};
yystate(33, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(33, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(1, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(9, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $! ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $#, C =< $/ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(33, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $:, C =< $@ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(33, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $G, C =< $[ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $` ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(33, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $g, C =< $� ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(33, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,33};
yystate(32, [$x|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(8, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(3, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $/ ->
    yystate(3, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(24, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $8, C =< $w ->
    yystate(3, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $y, C =< $� ->
    yystate(3, Ics, Line, Tlen+1, 5, Tlen);
yystate(32, Ics, Line, Tlen, _Action, _Alen) ->
    {5,Tlen,Ics,Line,32};
yystate(31, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(31, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(23, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(15, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $& ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $(, C =< $[ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(31, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,31};
yystate(30, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(30, Ics, Line+1, Tlen+1, 16, Tlen);
yystate(30, [$%|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(45, Ics, Line, Tlen+1, 16, Tlen);
yystate(30, [$(|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(22, Ics, Line, Tlen+1, 16, Tlen);
yystate(30, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(30, Ics, Line, Tlen+1, 16, Tlen);
yystate(30, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $\s ->
    yystate(30, Ics, Line, Tlen+1, 16, Tlen);
yystate(30, Ics, Line, Tlen, _Action, _Alen) ->
    {16,Tlen,Ics,Line,30};
yystate(29, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(21, Ics, Line, Tlen+1, _Action, _Alen);
yystate(29, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,29};
yystate(28, Ics, Line, Tlen, _Action, _Alen) ->
    {15,Tlen,Ics,Line};
yystate(27, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(35, Ics, Line, Tlen+1, _Action, _Alen);
yystate(27, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,27};
yystate(26, [$_|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(26, Ics, Line, Tlen+1, 6, Tlen);
yystate(26, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(26, Ics, Line, Tlen+1, 6, Tlen);
yystate(26, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $Z ->
    yystate(26, Ics, Line, Tlen+1, 6, Tlen);
yystate(26, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $z ->
    yystate(26, Ics, Line, Tlen+1, 6, Tlen);
yystate(26, Ics, Line, Tlen, _Action, _Alen) ->
    {6,Tlen,Ics,Line,26};
yystate(25, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(25, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(1, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(9, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $! ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $#, C =< $/ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(25, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $8, C =< $[ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(25, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,25};
yystate(24, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(3, Ics, Line, Tlen+1, 5, Tlen);
yystate(24, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(16, Ics, Line, Tlen+1, 5, Tlen);
yystate(24, Ics, Line, Tlen, _Action, _Alen) ->
    {5,Tlen,Ics,Line,24};
yystate(23, Ics, Line, Tlen, _Action, _Alen) ->
    {10,Tlen,Ics,Line};
yystate(22, Ics, Line, Tlen, _Action, _Alen) ->
    {13,Tlen,Ics,Line};
yystate(21, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(21, Ics, Line, Tlen+1, 3, Tlen);
yystate(21, Ics, Line, Tlen, _Action, _Alen) ->
    {3,Tlen,Ics,Line,21};
yystate(20, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(28, Ics, Line+1, Tlen+1, 9, Tlen);
yystate(20, [$#|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$$|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$%|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(36, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$&|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$*|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$+|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$:|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$^|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [$~|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(28, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $\s ->
    yystate(28, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $-, C =< $/ ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $<, C =< $@ ->
    yystate(42, Ics, Line, Tlen+1, 9, Tlen);
yystate(20, Ics, Line, Tlen, _Action, _Alen) ->
    {9,Tlen,Ics,Line,20};
yystate(19, [$E|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(43, Ics, Line, Tlen+1, 0, Tlen);
yystate(19, [$e|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(43, Ics, Line, Tlen+1, 0, Tlen);
yystate(19, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(19, Ics, Line, Tlen+1, 0, Tlen);
yystate(19, Ics, Line, Tlen, _Action, _Alen) ->
    {0,Tlen,Ics,Line,19};
yystate(18, [$_|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(18, Ics, Line, Tlen+1, 11, Tlen);
yystate(18, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(18, Ics, Line, Tlen+1, 11, Tlen);
yystate(18, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $Z ->
    yystate(18, Ics, Line, Tlen+1, 11, Tlen);
yystate(18, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $z ->
    yystate(18, Ics, Line, Tlen+1, 11, Tlen);
yystate(18, Ics, Line, Tlen, _Action, _Alen) ->
    {11,Tlen,Ics,Line,18};
yystate(17, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line+1, Tlen+1, 12, Tlen);
yystate(17, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(1, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(9, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(6, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $! ->
    yystate(6, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $#, C =< $[ ->
    yystate(6, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(6, Ics, Line, Tlen+1, 12, Tlen);
yystate(17, Ics, Line, Tlen, _Action, _Alen) ->
    {12,Tlen,Ics,Line,17};
yystate(16, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(3, Ics, Line, Tlen+1, _Action, _Alen);
yystate(16, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(16, Ics, Line, Tlen+1, _Action, _Alen);
yystate(16, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,16};
yystate(15, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(15, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(7, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(15, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [$x|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(12, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $& ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $(, C =< $/ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(0, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $8, C =< $[ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $w ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $y, C =< $� ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(15, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,15};
yystate(14, Ics, Line, Tlen, _Action, _Alen) ->
    {7,Tlen,Ics,Line};
yystate(13, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(5, Ics, Line, Tlen+1, _Action, _Alen);
yystate(13, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(5, Ics, Line, Tlen+1, _Action, _Alen);
yystate(13, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(5, Ics, Line, Tlen+1, _Action, _Alen);
yystate(13, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,13};
yystate(12, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(12, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(23, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(15, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $& ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $(, C =< $/ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(12, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $:, C =< $@ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(12, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $G, C =< $[ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $` ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(12, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $g, C =< $� ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(12, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,12};
yystate(11, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(19, Ics, Line, Tlen+1, _Action, _Alen);
yystate(11, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,11};
yystate(10, Ics, Line, Tlen, _Action, _Alen) ->
    {8,Tlen,Ics,Line};
yystate(9, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(9, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(17, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(9, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [$x|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(33, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $! ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $#, C =< $/ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(25, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $8, C =< $[ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $w ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $y, C =< $� ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(9, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,9};
yystate(8, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(4, Ics, Line, Tlen+1, 5, Tlen);
yystate(8, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(4, Ics, Line, Tlen+1, 5, Tlen);
yystate(8, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(4, Ics, Line, Tlen+1, 5, Tlen);
yystate(8, Ics, Line, Tlen, _Action, _Alen) ->
    {5,Tlen,Ics,Line,8};
yystate(7, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line+1, Tlen+1, 10, Tlen);
yystate(7, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(23, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(15, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(31, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $& ->
    yystate(31, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $(, C =< $[ ->
    yystate(31, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(31, Ics, Line, Tlen+1, 10, Tlen);
yystate(7, Ics, Line, Tlen, _Action, _Alen) ->
    {10,Tlen,Ics,Line,7};
yystate(6, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(6, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(6, [$"|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(1, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(9, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $! ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $#, C =< $[ ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(6, Ics, Line, Tlen+1, _Action, _Alen);
yystate(6, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,6};
yystate(5, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(5, Ics, Line, Tlen+1, 4, Tlen);
yystate(5, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(5, Ics, Line, Tlen+1, 4, Tlen);
yystate(5, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(5, Ics, Line, Tlen+1, 4, Tlen);
yystate(5, Ics, Line, Tlen, _Action, _Alen) ->
    {4,Tlen,Ics,Line,5};
yystate(4, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(3, Ics, Line, Tlen+1, _Action, _Alen);
yystate(4, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(4, Ics, Line, Tlen+1, _Action, _Alen);
yystate(4, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $A, C =< $F ->
    yystate(4, Ics, Line, Tlen+1, _Action, _Alen);
yystate(4, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $a, C =< $f ->
    yystate(4, Ics, Line, Tlen+1, _Action, _Alen);
yystate(4, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,4};
yystate(3, Ics, Line, Tlen, _Action, _Alen) ->
    {5,Tlen,Ics,Line};
yystate(2, [$.|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(11, Ics, Line, Tlen+1, 1, Tlen);
yystate(2, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $9 ->
    yystate(2, Ics, Line, Tlen+1, 1, Tlen);
yystate(2, Ics, Line, Tlen, _Action, _Alen) ->
    {1,Tlen,Ics,Line,2};
yystate(1, Ics, Line, Tlen, _Action, _Alen) ->
    {12,Tlen,Ics,Line};
yystate(0, [$\n|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(31, Ics, Line+1, Tlen+1, _Action, _Alen);
yystate(0, [$'|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(23, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [$\\|Ics], Line, Tlen, _Action, _Alen) ->
    yystate(15, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\000, C =< $\t ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $\v, C =< $& ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $(, C =< $/ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $0, C =< $7 ->
    yystate(0, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $8, C =< $[ ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, [C|Ics], Line, Tlen, _Action, _Alen) when C >= $], C =< $� ->
    yystate(31, Ics, Line, Tlen+1, _Action, _Alen);
yystate(0, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,0};
yystate(S, Ics, Line, Tlen, Action, Alen) ->
    {Action,Alen,Tlen,Ics,Line,S}.


%% yyaction(Action, TokenLength, TokenChars, TokenLine) ->
%%        {token,Token} | {end_token, Token} | skip_token | {error,String}.
%% Generated action function.

yyaction(0, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{number,list_to_float(TokenChars)}};
yyaction(1, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{number,list_to_integer(TokenChars)}};
yyaction(2, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    base(string:substr(TokenChars,3),2);
yyaction(3, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    base(string:substr(TokenChars,3),8);
yyaction(4, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    base(string:substr(TokenChars,3),16);
yyaction(5, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{number,hd(chars(string:substr(TokenChars,3)))}};
yyaction(6, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{atom,list_to_atom(TokenChars)}};
yyaction(7, _, _, _) ->
    {token,{atom,'!'}};
yyaction(8, _, _, _) ->
    {token,{atom,';'}};
yyaction(9, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{atom,list_to_atom(TokenChars)}};
yyaction(10, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    S = string:substr(TokenChars,2,TokenLen - 2),
    case catch list_to_atom(chars(S)) of
        {'EXIT',_} ->
            {error,"illegal atom " ++ TokenChars};
        Atom ->
            {token,{atom,Atom}}
    end;
yyaction(11, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,{var,list_to_atom(TokenChars)}};
yyaction(12, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    S = string:substr(TokenChars,2,TokenLen - 2),
    {token,{string,chars(S)}};
yyaction(13, _, _, _) ->
    {token,' ('};
yyaction(14, TokenLen, YYtcs, _) ->
    TokenChars = yypre(YYtcs, TokenLen),
    {token,list_to_atom(TokenChars)};
yyaction(15, _, _, _) ->
    {end_token,dot};
yyaction(16, _, _, _) ->
    skip_token;
yyaction(_, _, _, _) -> error.
