%%% File    : erlog_parse.erl
%%% Author  : Robert Virding
%%% Purpose : Erlog parser
%%%
%%% (C)Robert Virding. This stuff is mine, distributed without
%%% warranty "as is" and may not be used commercially without written
%%% permission.
%%%
%%% Parses Erlog tokens into Erlog terms. Based on the Standard prolog
%%% parser and directly coded from the parser description. To handle
%%% back-tracking in the parser we use a continuation style using funs
%%% where each fun handles one step of what follows. This allows
%%% back-tracking. This may not be a specially efficient way of
%%% parsing but it is simple and easy to derive from the
%%% description. No logical variables are necessary here.
%%%
%%% N.B. The current tokeniser doesn't generate whitespace tokens but
%%% we will leave them in anyway just in case we have to roll back to
%%% one that does. Anyway it doesn't cost us anything.

-module(erlog_parse).

-export([term/1,term/2,format_error/1]).
-export([prefix_op/1,infix_op/1,postfix_op/1]).

%% -compile(export_all).

term(Toks) -> term(Toks, 1).

term(Toks, Line) ->
    try
	term(Toks, 1200, fun(Ts, T) -> all_read(Ts, T) end)
    of
	{succeed,Term,[]} -> {ok,Term};
	{fail,Error} -> {error,{Line,?MODULE,Error}}
    catch
	throw: {syntax_error,E} ->    
	    {error,{Line,?MODULE,E}}
    end.

all_read([whitespace|Toks], T) -> all_read(Toks, T);
all_read([dot], T) -> {succeed,T,[]};
all_read([], T) -> {succeed,T,[]};
all_read(Toks, T) -> syntax_fail({operator_expected,Toks,T}).

syntax_error(Error) -> throw({syntax_error,Error}).
syntax_fail(Error) -> {fail,Error}.

format_error({operator_expected,Toks,T}) ->
    io_lib:fwrite("operator expected after ~w", [T]);
format_error({illegal,T}) ->
    io_lib:fwrite("illegal token: ~w", [T]);
format_error(no_term) -> "missing term";
format_error({op_priority,Op}) ->
    io_lib:fwrite("operator priority clash: ~w", [Op]);
format_error({expected,T}) ->
    io_lib:fwrite("~w or operator expected", [T]).

%% term(Tokens, Precedence, Next) -> {succeed,Term,RestTokens} | {fail,Error}.

term([whitespace|Toks], Prec, Next) -> term(Toks, Prec, Next);
term([{number,N}|Toks], Prec, Next) -> rest_term(Toks, N, 0, Prec, Next);
term([{string,S}|Toks], Prec, Next) -> rest_term(Toks, S, 0, Prec, Next);
term([{atom,F},'('|Toks0], Prec, Next) ->
    %% Compound term in functional syntax.
    term(Toks0, 999,
	 fun (Toks1, A) ->
		 arg_list(Toks1, [A],
			  fun (Toks2, Args) ->
				  Term = list_to_tuple([F|Args]),
%				  %% Equivalence of '.'/2 and lists.
% 				  Term = case list_to_tuple([F|Args]) of
% 					     {'.',H,T} -> [H|T];
% 					     Other -> Other
% 					 end,
				  rest_term(Toks2, Term, 0, Prec, Next)
			  end)
	 end);
term([{atom,Op}|Toks0], Prec, Next) ->
    case prefix_op(Op) of
	{yes,OpP,ArgP} when Prec >= OpP ->
	    case term(Toks0, ArgP,
		      fun (Toks1, Arg) ->
			      rest_term(Toks1, {Op,Arg}, OpP, Prec, Next)
		      end) of
		{succeed,Term,Toks2} -> {succeed,Term,Toks2};
		_fail -> rest_term(Toks0, Op, 0, Prec, Next)
	    end;
	{yes,OpP,ArgP} ->
	    syntax_error({op_priority,Op});
	no -> rest_term(Toks0, Op, 0, Prec, Next)
    end;
term([{var,V}|Toks], Prec, Next) -> rest_term(Toks, {V}, 0, Prec, Next);
term(['('|Toks], Prec, Next) ->
    bracket_term(Toks, Prec, Next);
term([' ('|Toks], Prec, Next) ->
    bracket_term(Toks, Prec, Next);
term(['{','}'|Toks], Prec, Next) ->
    term([{atom,'{}'}|Toks], Prec, Next);
term(['{'|Toks0], Prec, Next) ->
    term(Toks0, 1200,
	 fun (Toks1, Term) ->
		 expect(Toks1, '}', Term,
			fun (Toks2, Term) ->
				rest_term(Toks2, {'{}',Term}, 0, Prec, Next)
			end)
	 end);
term(['[',']'|Toks], Prec, Next) -> rest_term(Toks, [], 0, Prec, Next);
term(['['|Toks0], Prec, Next) ->
    term(Toks0, 999,
	 fun (Toks1, E) ->
		 list_elems(Toks1, [E],
			    fun (Toks2, List) ->
				    rest_term(Toks2, List, 0, Prec, Next)
			    end)
	 end);
term([T|Toks], Prec, Next) -> syntax_fail({illegal,T});
term([], Prec, Next) -> syntax_fail(no_term).

%% bracket_term(Tokens, Precedence, Next) ->
%%      {succeed,Term,RestTokens} | {fail,Error}.

bracket_term(Toks0, Prec, Next) ->
    term(Toks0, 1200,
	 fun (Toks1, Term) ->
		 expect(Toks1, ')', Term,
			fun (Toks2, Term) ->
				rest_term(Toks2, Term, 0, Prec, Next)
			end)
	 end).

%% rest_term(Tokens, Term, LeftPrec, Precedence, Next) ->
%%      {succeed,Term,RestTokens} | {fail,Error}.

rest_term([whitespace|Toks], Term, L, P, Next) ->
    rest_term(Toks, Term, L, P, Next);
rest_term([{atom,Op}|Toks0], Term, L, P, Next) ->
    case infix_term(Op, Toks0, Term, L, P, Next) of
	{succeed,NewTerm,Toks1} -> {succeed,NewTerm,Toks1};
	_ifail ->
	    case postfix_term(Op, Toks0, Term, L, P, Next) of
		{succeed,NewTerm,Toks1} -> {succeed,NewTerm,Toks1};
		_pfail ->
		    %% Push back atom and try to go on.
		    Next([{atom,Op}|Toks0], Term)
	    end
    end;
rest_term([','|Toks0], Term, L, P, Next) ->
    %% , is an operator as well as a separator.
    if  P >= 1000, L < 1000 ->
	    term(Toks0, 1000,
		 fun (Toks1, RArg) ->
			 rest_term(Toks1, {',',Term,RArg}, 1000, P, Next)
		 end);
	true -> Next([','|Toks0], Term)
    end;
rest_term(Toks, Term, L, P, Next) ->
    Next(Toks, Term).

infix_term(Op, Toks0, Term, Left, Prec, Next) ->
    case infix_op(Op) of
	{yes,LAP,OpP,RAP} when Prec >= OpP, Left =< LAP ->
	    term(Toks0, RAP,
		 fun (Toks1, Arg2) ->
			 rest_term(Toks1, {Op,Term,Arg2}, OpP, Prec, Next)
		 end);
	_Else -> fail
    end.

postfix_term(Op, Toks0, Term, Left, Prec, Next) ->
    case postfix_op(Op) of
	{yes,ArgP,OpP} when Prec >= OpP, Left =< ArgP ->
	    rest_term(Toks0, {Op,Term}, OpP, Prec, Next);
	_Else -> fail
    end.

%% list_elems(Tokens, RevElems, Next) ->
%%      {succeed,Term,RestTokens} | fail.

list_elems([whitespace|Toks], REs, Next) -> list_elems(Toks, REs, Next);
list_elems([','|Toks0], REs, Next) ->
    term(Toks0, 999,
	 fun (Toks1, E) ->
		 list_elems(Toks1, [E|REs], Next)
	 end);
list_elems(['|'|Toks0], REs, Next) ->
    term(Toks0, 999,
	 fun (Toks1, E) ->
		 expect(Toks1, ']', lists:reverse(REs, E), Next)
	 end);
list_elems(Toks, REs, Next) ->
    expect(Toks, ']', lists:reverse(REs), Next).

%% arg_list(Tokens, RevArgs, Next) -> {succeed,Term,RestTokens} | fail.

arg_list([whitespace|Toks], RAs, Next) -> arg_list(Toks, RAs, Next);
arg_list([','|Toks0], RAs, Next) ->
    term(Toks0, 999,
	 fun (Toks1, Arg) ->
		 arg_list(Toks1, [Arg|RAs], Next)
	 end);
arg_list(Toks, RAs, Next) ->
    expect(Toks, ')', lists:reverse(RAs), Next).

%% expect(Tokens, Token, Term, Next) -> {succeed,RestTokens} | fail.

expect([whitespace|Toks], Tok, Term, Next) -> expect(Toks, Tok, Term, Next);
expect([Tok|Toks], Tok, Term, Next) -> Next(Toks, Term);
expect(_Toks, Tok, _T, _Next) -> syntax_error({expected,Tok}).

%% prefix_op(Op) -> {yes,Prec,ArgPrec} | no.

prefix_op('?-') -> {yes,1200,1199};		%fx 1200
prefix_op(':-') -> {yes,1200,1199};		%fx 1200
prefix_op('\\+') -> {yes,900,900};		%fy 900
prefix_op('+') -> {yes,200,200};		%fy 200
prefix_op('-') -> {yes,200,200};		%fy 200
prefix_op('\\') -> {yes,200,200};		%fy 200
prefix_op(_Op) -> no.				%The rest

%% postfix_op(Op) -> {yes,ArgPrec,Prec} | no.

postfix_op('+') -> {yes,500,500};
postfix_op('*') -> {yes,400,400};
postfix_op(_Op) -> no.

%% infix_op(Op) -> {yes,LeftArgPrec,Prec,RightArgPrec} | no.

infix_op(':-') -> {yes,1199,1200,1199};		%xfx 1200
infix_op('-->') -> {yes,1199,1200,1199};	%xfx 1200
infix_op(';') -> {yes,1099,1100,1100};		%xfy 1100
infix_op('->') -> {yes,1049,1050,1050};		%xfy 1050
infix_op(',') -> {yes,999,1000,1000};		%xfy 1000
infix_op('=') -> {yes,699,700,699};		%xfx 700
infix_op('\\=') -> {yes,699,700,699};		%xfx 700
infix_op('==') -> {yes,699,700,699};		%xfx 700
infix_op('@<') -> {yes,699,700,699};		%xfx 700
infix_op('@=<') -> {yes,699,700,699};		%xfx 700
infix_op('@>') -> {yes,699,700,699};		%xfx 700
infix_op('@>=') -> {yes,699,700,699};		%xfx 700
infix_op('=..') -> {yes,699,700,699};		%xfx 700
infix_op('is') -> {yes,699,700,699};		%xfx 700
infix_op('=:=') -> {yes,699,700,699};		%xfx 700
infix_op('=\\=') -> {yes,699,700,699};		%xfx 700
infix_op('<') -> {yes,699,700,699};		%xfx 700
infix_op('=<') -> {yes,699,700,699};		%xfx 700
infix_op('>') -> {yes,699,700,699};		%xfx 700
infix_op('>=') -> {yes,699,700,699};		%xfx 700
infix_op(':') -> {yes,599,600,600};		%xfy 600
infix_op('+') -> {yes,500,500,499};		%yfx 500
infix_op('-') -> {yes,500,500,499};		%yfx 500
infix_op('/\\') -> {yes,500,500,499};		%yfx 500
infix_op('\\/') -> {yes,500,500,499};		%yfx 500
infix_op('*') -> {yes,400,400,399};		%yfx 400
infix_op('/') -> {yes,400,400,399};		%yfx 400
infix_op('//') -> {yes,400,400,399};		%yfx 400
infix_op('rem') -> {yes,400,400,399};		%yfx 400
infix_op('mod') -> {yes,400,400,399};		%yfx 400
infix_op('<<') -> {yes,400,400,399};		%yfx 400
infix_op('>>') -> {yes,400,400,399};		%yfx 400
infix_op('**') -> {yes,199,200,199};		%xfx 200
infix_op('^') -> {yes,199,200,200};		%xfy 200
infix_op(_Op) -> no.
