-define(URL, "http://rsdn.ru/ws/JanusAT.asmx").
-module(janus).
-export([start/0, get_forum_list/2]).
-include("JanusAT.hrl").

start() ->
	case case soap_registry_server:start() of
		   {ok,_Pid} -> ok;
		   {error, {already_started, _Pid}} -> ok;
		   OtherErr -> OtherErr
		 end of
	  ok -> soap_registry_server:add_xsd(?URL, "JanusAT.xsd");
	  Other -> Other
	end.

get_forum_list(User,Pass) ->
	http:set_options([{cookies, enabled}]),
	case soapclient:invoke(?URL,
						   "\"http://rsdn.ru/Janus/GetForumList\"",
						   #'p:GetForumList'{'forumRequest'=#'p:ForumRequest'{userName=User, password=Pass}}) of
		{ok, Reply} -> Reply;
		{error, Error} -> {error, Error}
	end.
